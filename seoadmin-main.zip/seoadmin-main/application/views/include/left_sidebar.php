  <?php
    $PAGE_ROOT1=$this->uri->segment(1);
    $PAGE_ROOT2=$this->uri->segment(2);
    $PAGE_ROOT3=$this->uri->segment(3);
    $PAGE_ROOT4=$this->uri->segment(4);
    $PAGE_MOB='';
    $strArr=explode("_",$PAGE_ROOT3);
    if($strArr!='' && isset($strArr) && $PAGE_ROOT3!='mobile_default'){
      $PAGE_MOB=$strArr[0];
    }
    $PAGE_DTH='';
    $strArr=explode("_",$PAGE_ROOT3);
    if($strArr!='' && isset($strArr) && $PAGE_ROOT3!='dth_default'){
      $PAGE_DTH=$strArr[0];
    }
    $PAGE_INSURANCE='';
    $strArr=explode("_",$PAGE_ROOT3);
    if($strArr!='' && isset($strArr) && $PAGE_ROOT3!='insurance_default'){
      $PAGE_INSURANCE=$strArr[0];
    }
    $PAGE_DATACARD='';
    $strArr=explode("_",$PAGE_ROOT3);
    if($strArr!='' && isset($strArr) && $PAGE_ROOT3!='datacard_default'){
      $PAGE_DATACARD=$strArr[0];
    }
    $PAGE_LANDLINE='';
    $strArr=explode("_",$PAGE_ROOT3);
    if($strArr!='' && isset($strArr) && $PAGE_ROOT3!='landline_default'){
      $PAGE_LANDLINE=$strArr[0];
    }
    $PAGE_BROADBAND='';
    $strArr=explode("_",$PAGE_ROOT3);
    if($strArr!='' && isset($strArr) && $PAGE_ROOT3!='broadband_default'){
      $PAGE_BROADBAND=$strArr[0];
    }
    $PAGE_ELECTRICITY='';
    $strArr=explode("_",$PAGE_ROOT3);
    if($strArr!='' && isset($strArr) && $PAGE_ROOT3!='electricity_default'){
      $PAGE_ELECTRICITY=$strArr[0];
    }
    $PAGE_WATER='';
    $strArr=explode("_",$PAGE_ROOT3);
    if($strArr!='' && isset($strArr) && $PAGE_ROOT3!='water_default'){
      $PAGE_WATER=$strArr[0];
    }
    $PAGE_GAS='';
    $strArr=explode("_",$PAGE_ROOT3);
    if($strArr!='' && isset($strArr) && $PAGE_ROOT3!='gas_default'){
      $PAGE_GAS=$strArr[0];
    }
    $egov_all_ok=false;
    if($PAGE_ROOT3=='passport' || $PAGE_ROOT3=='driving_license' || $PAGE_ROOT3=='pan_card' || $PAGE_ROOT3=='fresh_passport_application' || $PAGE_ROOT3=='voter' || $PAGE_ROOT3=='birth_certificate'|| $PAGE_ROOT3=='death_certificate' || $PAGE_ROOT3=='marriage_certificate' || $PAGE_ROOT3=='rti' || $PAGE_ROOT3=='consumer_complaint' || $PAGE_ROOT3=='newspaper_advertisement' || $PAGE_ROOT3=='police_verification' || $PAGE_ROOT3=='notary'){

    	$egov_all_ok=true;
    }

    $finance_all_ok=false;
    if($PAGE_ROOT3=='pvt_limited_company' || $PAGE_ROOT3=='llp_incorporation' || $PAGE_ROOT3=='one_person_company_incorporation' || $PAGE_ROOT3=='msme_and_ssi_registration' || $PAGE_ROOT3=='partnership_firm_incorporation' || $PAGE_ROOT3=='tan_registration'|| $PAGE_ROOT3=='gst' || $PAGE_ROOT3=='fresh_gst_application' || $PAGE_ROOT3=='itr_filing' || $PAGE_ROOT3=='gst_return_filing' || $PAGE_ROOT3=='tds_tcs_return_filing' || $PAGE_ROOT3=='business_itr_filing' || $PAGE_ROOT3=='bulk_return_filing' || $PAGE_ROOT3=='revised_return_filing' || $PAGE_ROOT3=='respond_to_tax_notice' || $PAGE_ROOT3=='trademark_registration' || $PAGE_ROOT3=='trademark_assignment' || $PAGE_ROOT3=='trademark_objection' || $PAGE_ROOT3=='copyright_registration' || $PAGE_ROOT3=='patent_registration' || $PAGE_ROOT3=='roc_compliances' || $PAGE_ROOT3=='llp_annual_filing' || $PAGE_ROOT3=='company_annual_filing' || $PAGE_ROOT3=='maintenance_of_minutes_statutory_register' || $PAGE_ROOT3=='business_plan_preparation' || $PAGE_ROOT3=='accounting_bookkeeping' || $PAGE_ROOT3=='allotment_of_shares' || $PAGE_ROOT3=='change_in_directors' || $PAGE_ROOT3=='change_in_partners' || $PAGE_ROOT3=='change_registered_office' || $PAGE_ROOT3=='change_in_authorized_share_capital' || $PAGE_ROOT3=='proprietorship_to_private_ltd' || $PAGE_ROOT3=='partnership_firm_to_llp' || $PAGE_ROOT3=='private_limited_company_to_llp' || $PAGE_ROOT3=='closing_llp' || $PAGE_ROOT3=='closing_private_limited_company' || $PAGE_ROOT3=='fssai_licence' || $PAGE_ROOT3=='fssai_registration' || $PAGE_ROOT3=='iso_registration' || $PAGE_ROOT3=='digital_signature' || $PAGE_ROOT3=='esi_registration'  || $PAGE_ROOT3=='provident_fund_registration' || $PAGE_ROOT3=='trade_license' || $PAGE_ROOT3=='shop_establishment_certificate' ){
    	$finance_all_ok=true;
    }

    $other_all_ok=false;
    if($PAGE_ROOT3=='about_us' || $PAGE_ROOT3=='terms_conditions' || $PAGE_ROOT3=='privacy_policy' || $PAGE_ROOT3=='disclaimer'){
    	$other_all_ok=true;
    }
    

     $franchisee_all_ok=false;
    if($PAGE_ROOT3=='recharge_fenquiry' || $PAGE_ROOT3=='pan_fenquiry' || $PAGE_ROOT3=='gst_fenquiry' || $PAGE_ROOT3=='finance_fenquiry' || $PAGE_ROOT3=='dsc_fenquiry' || $PAGE_ROOT3=='aeps_fenquiry' || $PAGE_ROOT3=='home_fenquiry' || $PAGE_ROOT3=='dmt_fenquiry' || $PAGE_ROOT3=='billpayment_fenquiry'){
    	$franchisee_all_ok=true;
    }

    $vcatg='';
   $temp_vcatg=explode('_', $PAGE_ROOT3);
   if(isset($temp_vcatg[1]) && !empty($temp_vcatg[1])){
     $vcatg=strtolower($temp_vcatg[1]);
   }

   $rcatg='';
   $temp_rcatg=explode('-', $PAGE_ROOT3);
   if(isset($temp_rcatg[0]) && !empty($temp_rcatg[0])){
     $rcatg=strtolower($temp_rcatg[0]);
   }

  
    
  ?>



  <!-- Left side column. contains the logo and sidebar -->

  <aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->

    <section class="sidebar">

      <!-- Sidebar user panel -->

      <div class="user-panel">

        <div class="pull-left image">

          <img src="<?php echo base_url(); ?>dist/img/default123.jpg" class="img-circle profile_pic" alt="User Image">

        </div>

        <div class="pull-left info">

          <p><?php echo $this->session->userdata('ADMIN_USER_NAME'); ?></p>

          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>

        </div>

      </div>

  

      <!-- sidebar menu: : style can be found in sidebar.less -->

      <ul class="sidebar-menu" data-widget="tree">

        <li class="header">MAIN NAVIGATION</li>

         <li class="<?php if($PAGE_ROOT1=='admin' && $PAGE_ROOT2=='dashboard' ) { echo "active"; } ?>">
          <a href="<?php echo base_url(); ?>admin/dashboard"><i class="fa fa-dashboard"></i> Dashboard </a>
        </li>

        <li class="<?php if(($PAGE_ROOT1=='home') ||  ($PAGE_ROOT1=='home' && $PAGE_ROOT2=='homedefault')) { echo "active"; } ?>">
          <a href="<?php echo base_url(); ?>home/"><i class="fa fa-group"></i> <span>Home</span></a>
        </li>


        <li class="<?php if($PAGE_ROOT1=='travel' || ($PAGE_ROOT1=='travel' && $PAGE_ROOT2=='tdefault')) { echo "active menu-open"; } ?> treeview">
          <a href="travel">
            <i class="fa fa-plane" aria-hidden="true"></i> <span>Travel</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php if(($PAGE_ROOT1=='travel' && $PAGE_ROOT2=='tdefault' && $PAGE_ROOT3=='travel_default')) { echo "active"; } ?>" data-id="travel_default"><a href="<?php echo base_url(); ?>travel/tdefault"><i class="fa fa-circle-o" ></i>Default</a></li>
            <li class="<?php if(($PAGE_ROOT1=='travel' && $PAGE_ROOT2=='tdefault' && $PAGE_ROOT3=='flight') || ($PAGE_ROOT1=='travel' && $PAGE_ROOT2=='tdefault' && $PAGE_ROOT3=='flight_result') || ($PAGE_ROOT1=='travel' && $PAGE_ROOT2=='tdefault' && $PAGE_ROOT3=='flight_result_round') || ($PAGE_ROOT1=='travel' && $PAGE_ROOT2=='tdefault' && $PAGE_ROOT3=='flight_result_round_domestic') || ($PAGE_ROOT1=='travel' && $PAGE_ROOT2=='flight')) { echo "active"; } ?>" data-id="flight"><a href="<?php echo base_url(); ?>travel/flight"><i class="fa fa-circle-o" ></i>Flight</a></li>
            <li class="<?php if(($PAGE_ROOT1=='travel' && $PAGE_ROOT2=='tdefault' && $PAGE_ROOT3=='bus') || ($PAGE_ROOT1=='travel' && $PAGE_ROOT2=='bus')) { echo "active"; } ?>" data-id="bus"><a href="<?php echo base_url(); ?>travel/bus"><i class="fa fa-circle-o" ></i> Bus </a></li>
            <li class="<?php if(($PAGE_ROOT1=='travel' && $PAGE_ROOT2=='tdefault' && $PAGE_ROOT3=='hotel') || ($PAGE_ROOT1=='travel' && $PAGE_ROOT2=='hotel')) { echo "active"; } ?>" data-id="hotel"><a href="<?php echo base_url(); ?>travel/hotel"><i class="fa fa-circle-o" ></i> Hotel</a></li> 
            <li class="<?php if(($PAGE_ROOT1=='travel' && $PAGE_ROOT2=='tdefault' && $PAGE_ROOT3=='holiday') || ($PAGE_ROOT1=='travel' && $PAGE_ROOT2=='holiday')) { echo "active"; } ?>" data-id="holiday"><a href="<?php echo base_url(); ?>travel/holiday"><i class="fa fa-circle-o" ></i> Holiday </a></li>
          </ul>
        </li>


        <li class="<?php if($PAGE_ROOT1=='recharge') { echo "active menu-open"; } ?> treeview">
          <a href="recharge"> 
            <i class="fa fa-plane" aria-hidden="true"></i> <span>Recharge</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu recharge_list">                       
            <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='mobile_prepaid_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='mobile_postpaid_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='mobile_prepaid') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='mobile_postpaid') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='mobile_prepaid') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='mobile_postpaid')) { echo "active"; } ?> treeview">

              <a href="#">

                <i class="fa fa-group"></i> <span>Mobile</span>

                <span class="pull-right-container">

                  <i class="fa fa-angle-left pull-right"></i>

                </span>

              </a>

              <ul class="treeview-menu mob_list">
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='mobile_prepaid_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $PAGE_ROOT3=='mobile_prepaid-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/mobile_prepaid_default"><i class="fa fa-circle-o"></i>Mobile Prepaid Default</a></li>
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='mobile_postpaid_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $PAGE_ROOT3=='mobile_postpaid-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/mobile_postpaid_default"><i class="fa fa-circle-o"></i>Mobile Postpaid Default</a></li>
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='mobile_prepaid') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='mobile_prepaid')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/mobile_prepaid"><i class="fa fa-circle-o"></i>Mobile PrePaid</a></li>
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='mobile_postpaid') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='mobile_postpaid')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/mobile_postpaid"><i class="fa fa-circle-o"></i>Mobile PostPaid</a></li>
              </ul>
        </li>
     
        <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='dth_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='dth') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='dth')) { echo "active"; } ?> treeview">

              <a href="#">

                <i class="fa fa-group"></i> <span>DTH</span>

                <span class="pull-right-container">

                  <i class="fa fa-angle-left pull-right"></i>

                </span>

              </a>

              <ul class="treeview-menu dth_list">
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='dth_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $PAGE_ROOT3=='dth-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/dth_default"><i class="fa fa-circle-o"></i>Default</a></li>
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='dth') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='dth' && $PAGE_ROOT3!='dth-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/dth"><i class="fa fa-circle-o"></i>Dth Operators</a></li>
              </ul>
        </li>

         <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='datacard_prepaid_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='datacard_postpaid_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='datacard_prepaid') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='datacard_postpaid') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='datacard_prepaid') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='datacard_postpaid')) { echo "active"; } ?> treeview">

              <a href="#">

                <i class="fa fa-group"></i> <span>Datcard</span>

                <span class="pull-right-container">

                  <i class="fa fa-angle-left pull-right"></i>

                </span>

              </a>

              <ul class="treeview-menu mob_list">
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='datacard_prepaid_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $PAGE_ROOT3=='datacard_prepaid-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/datacard_prepaid_default"><i class="fa fa-circle-o"></i>Datacard Prepaid Default</a></li>
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='datacard_postpaid_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $PAGE_ROOT3=='datacard_postpaid-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/datacard_postpaid_default"><i class="fa fa-circle-o"></i>Datacard Postpaid Default</a></li>
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='datacard_prepaid') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='datacard_prepaid' && $PAGE_ROOT3!='datacard_prepaid-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/datacard_prepaid"><i class="fa fa-circle-o"></i>Datacard PrePaid</a></li>
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='datacard_postpaid') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='datacard_postpaid' && $PAGE_ROOT3!='datacard_postpaid-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/datacard_postpaid"><i class="fa fa-circle-o"></i>Datacard PostPaid</a></li>
              </ul>
        </li>

        <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='landline_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='landline') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='landline')) { echo "active"; } ?> treeview">

              <a href="#">

                <i class="fa fa-group"></i> <span>Landline</span>

                <span class="pull-right-container">

                  <i class="fa fa-angle-left pull-right"></i>

                </span>

              </a>

              <ul class="treeview-menu landline_list">
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='landline_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $PAGE_ROOT3=='landline-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/landline_default"><i class="fa fa-circle-o"></i>Default</a></li>
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='landline') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='landline' && $PAGE_ROOT3!='landline-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/landline"><i class="fa fa-circle-o"></i>Landline Operators</a></li>
              </ul>
        </li>

         <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='broadband_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='broadband') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='broadband')) { echo "active"; } ?> treeview">

              <a href="#">

                <i class="fa fa-group"></i> <span>Broadband</span>

                <span class="pull-right-container">

                  <i class="fa fa-angle-left pull-right"></i>

                </span>

              </a>

              <ul class="treeview-menu broadband_list">
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='broadband_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $PAGE_ROOT3=='broadband-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/broadband_default"><i class="fa fa-circle-o"></i>Default</a></li>
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='broadband') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='broadband' && $PAGE_ROOT3!='broadband-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/broadband"><i class="fa fa-circle-o"></i>Broadband Operators</a></li>
              </ul>
        </li>

         <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='insurance_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='insurance') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='insurance')) { echo "active"; } ?> treeview">

              <a href="#">

                <i class="fa fa-group"></i> <span>Insurance</span>

                <span class="pull-right-container">

                  <i class="fa fa-angle-left pull-right"></i>

                </span>

              </a>

              <ul class="treeview-menu insurance_list">
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='insurance_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $PAGE_ROOT3=='insurance-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/insurance_default"><i class="fa fa-circle-o"></i>Default</a></li>
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='insurance') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='insurance' && $PAGE_ROOT3!='insurance-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/insurance"><i class="fa fa-circle-o"></i>Insurance Operators</a></li>
              </ul>
        </li>        

        <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='electricity_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='electricity_board') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='electricity_board') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $PAGE_ROOT3=='electricity-default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='electricity_circle') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='electricity_circle')) { echo "active"; } ?> treeview">

              <a href="#">

                <i class="fa fa-group"></i> <span>Electricity</span>

                <span class="pull-right-container">

                  <i class="fa fa-angle-left pull-right"></i>

                </span>

              </a>

              <ul class="treeview-menu electricity_list">
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='electricity_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $PAGE_ROOT3=='electricity-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/electricity_default"><i class="fa fa-circle-o"></i>Default</a></li>
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='electricity_board') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='electricity_board' && $PAGE_ROOT3!='electricity-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/electricity_board"><i class="fa fa-circle-o"></i>Electricity Operators</a></li>
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='electricity_circle') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='electricity_circle' && $PAGE_ROOT3!='recharge')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/electricity_circle"><i class="fa fa-circle-o"></i>Electricity Circle</a></li>
              </ul>
        </li>

        <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='water_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='water') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='water')) { echo "active"; } ?> treeview">

              <a href="#">

                <i class="fa fa-group"></i> <span>Water</span>

                <span class="pull-right-container">

                  <i class="fa fa-angle-left pull-right"></i>

                </span>

              </a>

              <ul class="treeview-menu water_list">
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='water_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $PAGE_ROOT3=='water-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/water_default"><i class="fa fa-circle-o"></i>Default</a></li>
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='water') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='water' && $PAGE_ROOT3!='water-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/water"><i class="fa fa-circle-o"></i>Water Operators</a></li>
              </ul>
        </li>  

        <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='gas_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='gas') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='gas')) { echo "active"; } ?> treeview">

              <a href="#">

                <i class="fa fa-group"></i> <span>Gas</span>

                <span class="pull-right-container">

                  <i class="fa fa-angle-left pull-right"></i>

                </span>

              </a>

              <ul class="treeview-menu gas_list">
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='gas_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $PAGE_ROOT3=='gas-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/gas_default"><i class="fa fa-circle-o"></i>Default</a></li>
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='gas') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='gas' && $PAGE_ROOT3!='gas-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/gas"><i class="fa fa-circle-o"></i>Gas Operators</a></li>
              </ul>
        </li>

        <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='fastag_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='fastag') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='fastag')) { echo "active"; } ?> treeview">

              <a href="#">

                <i class="fa fa-group"></i> <span>Fastag</span>

                <span class="pull-right-container">

                  <i class="fa fa-angle-left pull-right"></i>

                </span>

              </a>

              <ul class="treeview-menu fastag_list">
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='fastag_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $PAGE_ROOT3=='fastag-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/fastag_default"><i class="fa fa-circle-o"></i>Default</a></li>
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='fastag') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='fastag' && $PAGE_ROOT3!='fastag-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/fastag"><i class="fa fa-circle-o"></i>Fastag Operators</a></li>
              </ul>
        </li>

        <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='credit_card_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='credit_card') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='credit_card')) { echo "active"; } ?> treeview">

              <a href="#">

                <i class="fa fa-group"></i> <span>Credit Card</span>

                <span class="pull-right-container">

                  <i class="fa fa-angle-left pull-right"></i>

                </span>

              </a>

              <ul class="treeview-menu credit_card_list">
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='credit_card_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $PAGE_ROOT3=='credit_card-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/credit_card_default"><i class="fa fa-circle-o"></i>Default</a></li>
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='credit_card') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='credit_card' && $PAGE_ROOT3!='credit_card-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/credit_card"><i class="fa fa-circle-o"></i>Credit Card Operators</a></li>
              </ul>
        </li>

        <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='hospital_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='hospital') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='hospital')) { echo "active"; } ?> treeview">

              <a href="#">

                <i class="fa fa-group"></i> <span>Hospital</span>

                <span class="pull-right-container">

                  <i class="fa fa-angle-left pull-right"></i>

                </span>

              </a>

              <ul class="treeview-menu hospital_list">
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='hospital_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $PAGE_ROOT3=='hospital-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/hospital_default"><i class="fa fa-circle-o"></i>Default</a></li>
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='hospital') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='hospital' && $PAGE_ROOT3!='hospital-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/hospital"><i class="fa fa-circle-o"></i>Hospital Operators</a></li>
              </ul>
        </li>

        <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='lpg_gas_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='lpg_gas') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='lpg_gas')) { echo "active"; } ?> treeview">

              <a href="#">

                <i class="fa fa-group"></i> <span>LPG Gas</span>

                <span class="pull-right-container">

                  <i class="fa fa-angle-left pull-right"></i>

                </span>

              </a>

              <ul class="treeview-menu lpg_gas_list">
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='lpg_gas_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $PAGE_ROOT3=='lpg_gas-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/lpg_gas_default"><i class="fa fa-circle-o"></i>Default</a></li>
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='lpg_gas') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='lpg_gas' && $PAGE_ROOT3!='lpg_gas-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/lpg_gas"><i class="fa fa-circle-o"></i>LPG Gas Operators</a></li>
              </ul>
        </li> 

         <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='loan_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='loan') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='loan')) { echo "active"; } ?> treeview">

              <a href="#">

                <i class="fa fa-group"></i> <span>Loan</span>

                <span class="pull-right-container">

                  <i class="fa fa-angle-left pull-right"></i>

                </span>

              </a>

              <ul class="treeview-menu loan_list">
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='loan_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $PAGE_ROOT3=='loan-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/loan_default"><i class="fa fa-circle-o"></i>Default</a></li>
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='loan') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='loan' && $PAGE_ROOT3!='loan-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/loan"><i class="fa fa-circle-o"></i>Loan Operators</a></li>
              </ul>
        </li>

        <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='housing_society_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='housing_society') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='housing_society')) { echo "active"; } ?> treeview">

              <a href="#">

                <i class="fa fa-group"></i> <span>Housing Society</span>

                <span class="pull-right-container">

                  <i class="fa fa-angle-left pull-right"></i>

                </span>

              </a>

              <ul class="treeview-menu housing_society_list">
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='housing_society_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $PAGE_ROOT3=='housing_society-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/housing_society_default"><i class="fa fa-circle-o"></i>Default</a></li>
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='housing_society') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='housing_society' && $PAGE_ROOT3!='housing_society-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/housing_society"><i class="fa fa-circle-o"></i>Housing Society Operators</a></li>
              </ul>
        </li>

        <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='subscription_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='subscription') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='subscription')) { echo "active"; } ?> treeview">

              <a href="#">

                <i class="fa fa-group"></i> <span>Subscription</span>

                <span class="pull-right-container">

                  <i class="fa fa-angle-left pull-right"></i>

                </span>

              </a>

              <ul class="treeview-menu subscription_list">
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='subscription_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $PAGE_ROOT3=='subscription-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/subscription_default"><i class="fa fa-circle-o"></i>Default</a></li>
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='subscription') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='subscription' && $PAGE_ROOT3!='subscription-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/subscription"><i class="fa fa-circle-o"></i>Subscription Operators</a></li>
              </ul>
        </li>

        <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='cable_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='cable') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='cable')) { echo "active"; } ?> treeview">

              <a href="#">

                <i class="fa fa-group"></i> <span>Cable</span>

                <span class="pull-right-container">

                  <i class="fa fa-angle-left pull-right"></i>

                </span>

              </a>

              <ul class="treeview-menu cable_list">
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='cable_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $PAGE_ROOT3=='cable-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/cable_default"><i class="fa fa-circle-o"></i>Default</a></li>
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='cable') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='cable' && $PAGE_ROOT3!='cable-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/cable"><i class="fa fa-circle-o"></i>Cable Operators</a></li>
              </ul>
        </li>

        <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='entertainment_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='entertainment') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='entertainment')) { echo "active"; } ?> treeview">

              <a href="#">

                <i class="fa fa-group"></i> <span>Entertainment</span>

                <span class="pull-right-container">

                  <i class="fa fa-angle-left pull-right"></i>

                </span>

              </a>

              <ul class="treeview-menu entertainment_list">
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='entertainment_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $PAGE_ROOT3=='entertainment-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/entertainment_default"><i class="fa fa-circle-o"></i>Default</a></li>
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='entertainment') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='entertainment' && $PAGE_ROOT3!='entertainment-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/entertainment"><i class="fa fa-circle-o"></i>Entertainment Operators</a></li>
              </ul>
        </li>

        <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='travel_sub_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='travel_sub') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='travel_sub')) { echo "active"; } ?> treeview">

              <a href="#">

                <i class="fa fa-group"></i> <span>Travel Sub</span>

                <span class="pull-right-container">

                  <i class="fa fa-angle-left pull-right"></i>

                </span>

              </a>

              <ul class="treeview-menu travel_sub_list">
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='travel_sub_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $PAGE_ROOT3=='travel_sub-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/travel_sub_default"><i class="fa fa-circle-o"></i>Default</a></li>
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='travel_sub') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='travel_sub' && $PAGE_ROOT3!='travel_sub-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/travel_sub"><i class="fa fa-circle-o"></i>Travel Sub Operators</a></li>
              </ul>
        </li>

        <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='municipal_taxes_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='municipal_taxes') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='municipal_taxes')) { echo "active"; } ?> treeview">

              <a href="#">

                <i class="fa fa-group"></i> <span>Municipal Taxes</span>

                <span class="pull-right-container">

                  <i class="fa fa-angle-left pull-right"></i>

                </span>

              </a>

              <ul class="treeview-menu municipal_taxes_list">
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='municipal_taxes_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $PAGE_ROOT3=='municipal_taxes-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/municipal_taxes_default"><i class="fa fa-circle-o"></i>Default</a></li>
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='municipal_taxes') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='municipal_taxes' && $PAGE_ROOT3!='municipal_taxes-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/municipal_taxes"><i class="fa fa-circle-o"></i>Municipal Taxes Operators</a></li>
              </ul>
        </li>
        
        <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='municipal_services_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='municipal_services') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='municipal_services')) { echo "active"; } ?> treeview">

              <a href="#">

                <i class="fa fa-group"></i> <span>Municipal Services</span>

                <span class="pull-right-container">

                  <i class="fa fa-angle-left pull-right"></i>

                </span>

              </a>

              <ul class="treeview-menu municipal_services_list">
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='municipal_services_default') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $PAGE_ROOT3=='municipal_services-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/municipal_services_default"><i class="fa fa-circle-o"></i>Default</a></li>
                <li class="<?php if(($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='cmn_rech_catg' && $PAGE_ROOT3=='municipal_services') || ($PAGE_ROOT1=='recharge' && $PAGE_ROOT2=='rdefault' && $rcatg=='municipal_services' && $PAGE_ROOT3!='municipal_services-default')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>recharge/cmn_rech_catg/municipal_services"><i class="fa fa-circle-o"></i>Municipal Services Operators</a></li>
              </ul>
        </li>
        
        
        
        
        education
</ul>
</li>




        <li class="<?php if(($PAGE_ROOT1=='egov' && $PAGE_ROOT2=='egovdefault') || ($PAGE_ROOT1=='egov' && $PAGE_ROOT2=='egov_all_services')) { echo "active"; } ?> treeview">

          <a href="#">

            <i class="fa fa-share"></i> <span>E-Gov</span>

            <span class="pull-right-container">

              <i class="fa fa-angle-left pull-right"></i>

            </span>

          </a>

          <ul class="treeview-menu egov_list">
            <li class="<?php if(($PAGE_ROOT1=='egov' && $PAGE_ROOT2=='egovdefault' && $egov_all_ok==false)) { echo "active"; } ?>"><a href="<?php echo base_url();?>egov/egovdefault"><i class="fa fa-group"></i>Default</a></li>
            <li class="<?php if(($PAGE_ROOT1=='egov' && $PAGE_ROOT2=='egov_all_services') || ($PAGE_ROOT1=='egov' && $PAGE_ROOT2=='egovdefault' && $egov_all_ok==true)) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>egov/egov_all_services"><i class="fa fa-circle-o"></i>All Services</a></li>
          </ul>

        </li>



        <li class="<?php if(($PAGE_ROOT1=='finance' && $PAGE_ROOT2=='financedefault') || ($PAGE_ROOT1=='finance' && $PAGE_ROOT2=='finance_all_services')) { echo "active"; } ?> treeview">

          <a href="#">

            <i class="fa fa-share"></i> <span>Finance</span>

            <span class="pull-right-container">

              <i class="fa fa-angle-left pull-right"></i>

            </span>

          </a>

          <ul class="treeview-menu finance_list">
            <li class="<?php if(($PAGE_ROOT1=='finance' && $PAGE_ROOT2=='financedefault' && $finance_all_ok==false)) { echo "active"; } ?>"><a href="<?php echo base_url();?>finance/financedefault"><i class="fa fa-group"></i>Default</a></li>
            <li class="<?php if(($PAGE_ROOT1=='finance' && $PAGE_ROOT2=='finance_all_services') || ($PAGE_ROOT1=='finance' && $PAGE_ROOT2=='financedefault' && $finance_all_ok==true)) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>finance/finance_all_services"><i class="fa fa-circle-o"></i> All Services</a></li>
          </ul>

      </li>


 <li class="<?php if(($PAGE_ROOT1=='other' && $PAGE_ROOT2=='othrdefault') || ($PAGE_ROOT1=='other' && $PAGE_ROOT2=='about_us') || ($PAGE_ROOT1=='other' && $PAGE_ROOT2=='terms_conditions') || ($PAGE_ROOT1=='other' && $PAGE_ROOT2=='privacy_policy') || ($PAGE_ROOT1=='other' && $PAGE_ROOT2=='disclaimer') || ($PAGE_ROOT1=='other' && $PAGE_ROOT2=='contact')) { echo "active"; } ?> treeview">

          <a href="#">

            <i class="fa fa-share"></i> <span>Others</span>

            <span class="pull-right-container">

              <i class="fa fa-angle-left pull-right"></i>

            </span>

          </a>

          <ul class="treeview-menu egov_list">
            <li class="<?php if(($PAGE_ROOT1=='other' && $PAGE_ROOT2=='othrdefault' && $other_all_ok==false)) { echo "active"; } ?>"><a href="<?php echo base_url();?>other/othrdefault"><i class="fa fa-group"></i>Default</a></li>
            <li class="<?php if(($PAGE_ROOT1=='other' && $PAGE_ROOT2=='about_us') || ($PAGE_ROOT1=='other' && $PAGE_ROOT2=='othrdefault' && $PAGE_ROOT3=='about_us')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>other/about_us"><i class="fa fa-circle-o"></i>About Us</a></li>
            <li class="<?php if(($PAGE_ROOT1=='other' && $PAGE_ROOT2=='terms_conditions') || ($PAGE_ROOT1=='other' && $PAGE_ROOT2=='othrdefault' && $PAGE_ROOT3=='terms_conditions')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>other/terms_conditions"><i class="fa fa-circle-o"></i>Terms Conditions</a></li>
            <li class="<?php if(($PAGE_ROOT1=='other' && $PAGE_ROOT2=='privacy_policy') || ($PAGE_ROOT1=='other' && $PAGE_ROOT2=='othrdefault' && $PAGE_ROOT3=='privacy_policy')) { echo "active"; } ?>"><a href="<?php echo base_url(); ?>other/privacy_policy"><i class="fa fa-circle-o"></i>Privacy Policy</a></li>
            <li class="<?php if(($PAGE_ROOT1=='other' && $PAGE_ROOT2=='disclaimer') || ($PAGE_ROOT1=='other' && $PAGE_ROOT2=='othrdefault' && $PAGE_ROOT3=='disclaimer')) { echo "active"; } ?>" ><a href="<?php echo base_url(); ?>other/disclaimer"><i class="fa fa-circle-o"></i>Disclaimer</a></li>
            <li class="<?php if(($PAGE_ROOT1=='other' && $PAGE_ROOT2=='contact') || ($PAGE_ROOT1=='other' && $PAGE_ROOT2=='othrdefault' && $PAGE_ROOT3=='contact')) { echo "active"; } ?>" ><a href="<?php echo base_url(); ?>other/contact"><i class="fa fa-circle-o"></i>Contact</a></li>
          </ul>

        </li>


		<li class="<?php if(($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='franchiseedefault') || ($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='recharge_fenquiry') || ($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='billpayment_fenquiry') || ($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='pan_fenquiry') || ($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='aeps_fenquiry') || ($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='dsc_fenquiry') || ($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='gst_fenquiry') || ($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='microatm_fenquiry') || ($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='home_fenquiry') || ($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='about_us') || ($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='customer_care') || ($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='privacy_policy') || ($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='terms')) { echo "active"; } ?> treeview">

          <a href="#">

            <i class="fa fa-share"></i> <span>Franchisee</span>

            <span class="pull-right-container">

              <i class="fa fa-angle-left pull-right"></i>

            </span>

          </a>

          <ul class="treeview-menu egov_list">
            <li class="<?php if(($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='franchiseedefault' && $franchisee_all_ok==false)) { echo "active"; } ?>"><a href="<?php echo base_url();?>franchisee/franchiseedefault"><i class="fa fa-group"></i>Default</a></li>

            <li class="<?php if(($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='home_fenquiry') || ($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='franchiseedefault' && $PAGE_ROOT3=='home_fenquiry')) { echo "active"; } ?>" ><a href="<?php echo base_url(); ?>franchisee/home_fenquiry"><i class="fa fa-circle-o"></i>Home</a></li>

             <li class="<?php if(($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='recharge_fenquiry') || ($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='franchiseedefault' && $PAGE_ROOT3=='recharge_fenquiry')) { echo "active"; } ?>" ><a href="<?php echo base_url(); ?>franchisee/recharge_fenquiry"><i class="fa fa-circle-o"></i>Recharge</a></li>

            <li class="<?php if(($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='billpayment_fenquiry') || ($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='franchiseedefault' && $PAGE_ROOT3=='billpayment_fenquiry')) { echo "active"; } ?>" ><a href="<?php echo base_url(); ?>franchisee/billpayment_fenquiry"><i class="fa fa-circle-o"></i>Bill Payment</a></li>

            <li class="<?php if(($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='pan_fenquiry') || ($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='franchiseedefault' && $PAGE_ROOT3=='pan_fenquiry')) { echo "active"; } ?>" ><a href="<?php echo base_url(); ?>franchisee/pan_fenquiry"><i class="fa fa-circle-o"></i>PAN</a></li>

            <li class="<?php if(($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='aeps_fenquiry') || ($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='franchiseedefault' && $PAGE_ROOT3=='aeps_fenquiry')) { echo "active"; } ?>" ><a href="<?php echo base_url(); ?>franchisee/aeps_fenquiry"><i class="fa fa-circle-o"></i>AEPS</a></li>

            <li class="<?php if(($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='dsc_fenquiry') || ($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='franchiseedefault' && $PAGE_ROOT3=='dsc_fenquiry')) { echo "active"; } ?>" ><a href="<?php echo base_url(); ?>franchisee/dsc_fenquiry"><i class="fa fa-circle-o"></i>DSC</a></li>

            <li class="<?php if(($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='gst_fenquiry') || ($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='franchiseedefault' && $PAGE_ROOT3=='gst_fenquiry')) { echo "active"; } ?>" ><a href="<?php echo base_url(); ?>franchisee/gst_fenquiry"><i class="fa fa-circle-o"></i>GST</a></li>

            <li class="<?php if(($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='microatm_fenquiry') || ($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='franchiseedefault' && $PAGE_ROOT3=='microatm_fenquiry')) { echo "active"; } ?>" ><a href="<?php echo base_url(); ?>franchisee/microatm_fenquiry"><i class="fa fa-circle-o"></i>Micro ATM</a></li>

            <li class="<?php if(($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='money_transfer_fenquiry') || ($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='franchiseedefault' && $PAGE_ROOT3=='money_transfer_fenquiry')) { echo "active"; } ?>" ><a href="<?php echo base_url(); ?>franchisee/money_transfer_fenquiry"><i class="fa fa-circle-o"></i>Money Transfer</a></li>

            <li class="<?php if(($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='passport_fenquiry') || ($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='franchiseedefault' && $PAGE_ROOT3=='passport_fenquiry')) { echo "active"; } ?>" ><a href="<?php echo base_url(); ?>franchisee/passport_fenquiry"><i class="fa fa-circle-o"></i>Passport</a></li>

            <li class="<?php if(($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='about_us') || ($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='franchiseedefault' && $PAGE_ROOT3=='about_us')) { echo "active"; } ?>" ><a href="<?php echo base_url(); ?>franchisee/about_us"><i class="fa fa-circle-o"></i>About Us</a></li>

            <li class="<?php if(($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='customer_care') || ($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='franchiseedefault' && $PAGE_ROOT3=='customer_care')) { echo "active"; } ?>" ><a href="<?php echo base_url(); ?>franchisee/customer_care"><i class="fa fa-circle-o"></i>Customer Care</a></li>

            <li class="<?php if(($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='privacy_policy') || ($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='franchiseedefault' && $PAGE_ROOT3=='privacy_policy')) { echo "active"; } ?>" ><a href="<?php echo base_url(); ?>franchisee/privacy_policy"><i class="fa fa-circle-o"></i>Privacy Policy</a></li>

            <li class="<?php if(($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='terms') || ($PAGE_ROOT1=='franchisee' && $PAGE_ROOT2=='franchiseedefault' && $PAGE_ROOT3=='terms')) { echo "active"; } ?>" ><a href="<?php echo base_url(); ?>franchisee/terms"><i class="fa fa-circle-o"></i>Terms Of Use</a></li>            
            
          </ul>

        </li>

        <!-- BEGIN:: VOUCHOR SECTION -->
        <li class="<?php if(($PAGE_ROOT1=='voucher' && $PAGE_ROOT2=='cmn_voch_catg') || ($PAGE_ROOT1=='voucher' && $PAGE_ROOT2=='voucherdefault')) { echo "active"; } ?> treeview">

          <a href="#">

            <i class="fa fa-share"></i> <span>Voucher</span>

            <span class="pull-right-container">

              <i class="fa fa-angle-left pull-right"></i>

            </span>

          </a>

          <ul class="treeview-menu egov_list">
            <li class="<?php if(($PAGE_ROOT1=='voucher' && $PAGE_ROOT2=='cmn_voch_catg' && $PAGE_ROOT3=='default') || ($PAGE_ROOT1=='voucher' && $PAGE_ROOT2=='voucherdefault' && $PAGE_ROOT3=='voucher_default')) { echo "active"; } ?>"><a href="<?php echo base_url();?>voucher/cmn_voch_catg/default"><i class="fa fa-group"></i>Default</a></li>

            <li class="<?php if(($PAGE_ROOT1=='voucher' && $PAGE_ROOT2=='cmn_voch_catg' && $PAGE_ROOT3=='fashion') || ($PAGE_ROOT1=='voucher' && $PAGE_ROOT2=='voucherdefault' && $vcatg=='fashion')) { echo "active"; } ?>" ><a href="<?php echo base_url();?>voucher/cmn_voch_catg/fashion"><i class="fa fa-circle-o"></i>Fashion</a></li>            

            <li class="<?php if(($PAGE_ROOT1=='voucher' && $PAGE_ROOT2=='cmn_voch_catg' && $PAGE_ROOT3=='others') || ($PAGE_ROOT1=='voucher' && $PAGE_ROOT2=='voucherdefault' && $vcatg=='others')) { echo "active"; } ?>" ><a href="<?php echo base_url();?>voucher/cmn_voch_catg/others"><i class="fa fa-circle-o"></i>others</a></li>

            <li class="<?php if(($PAGE_ROOT1=='voucher' && $PAGE_ROOT2=='cmn_voch_catg' && $PAGE_ROOT3=='travel') || ($PAGE_ROOT1=='voucher' && $PAGE_ROOT2=='voucherdefault' && $vcatg=='travel')) { echo "active"; } ?>" ><a href="<?php echo base_url();?>voucher/cmn_voch_catg/travel"><i class="fa fa-circle-o"></i>travel</a></li>

            <li class="<?php if(($PAGE_ROOT1=='voucher' && $PAGE_ROOT2=='cmn_voch_catg' && $PAGE_ROOT3=='entertainment') || ($PAGE_ROOT1=='voucher' && $PAGE_ROOT2=='voucherdefault' && $vcatg=='entertainment')) { echo "active"; } ?>" ><a href="<?php echo base_url();?>voucher/cmn_voch_catg/entertainment"><i class="fa fa-circle-o"></i>entertainment</a></li>

            <li class="<?php if(($PAGE_ROOT1=='voucher' && $PAGE_ROOT2=='cmn_voch_catg' && $PAGE_ROOT3=='food') || ($PAGE_ROOT1=='voucher' && $PAGE_ROOT2=='voucherdefault' && $vcatg=='food')) { echo "active"; } ?>" ><a href="<?php echo base_url();?>voucher/cmn_voch_catg/food"><i class="fa fa-circle-o"></i>food</a></li>

            <li class="<?php if(($PAGE_ROOT1=='voucher' && $PAGE_ROOT2=='cmn_voch_catg' && $PAGE_ROOT3=='electronics') || ($PAGE_ROOT1=='voucher' && $PAGE_ROOT2=='voucherdefault' && $vcatg=='electronics')) { echo "active"; } ?>" ><a href="<?php echo base_url();?>voucher/cmn_voch_catg/electronics"><i class="fa fa-circle-o"></i>electronics</a></li>                        
            
          </ul>

        </li>
        <!-- END:: VOUCHOR SECTION -->
		
	<!-- START:: QUESTION SECTION -->	 

    <li class="<?php if($PAGE_ROOT1=='travel' || ($PAGE_ROOT1=='travel' && $PAGE_ROOT2=='tdefault')) { echo "active menu-open"; } ?> treeview">
          <a href="travel">
            <i class="fa fa-plane" aria-hidden="true"></i> <span>Question</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php if(($PAGE_ROOT1=='travel' && $PAGE_ROOT2=='tdefault' && $PAGE_ROOT3=='travel_default')) { echo "active"; } ?>" data-id="travel_default"><a href="<?php echo base_url(); ?>question/qdefault"><i class="fa fa-circle-o" ></i>Add Question</a></li>
            <li class="<?php if(($PAGE_ROOT1=='travel' && $PAGE_ROOT2=='tdefault' && $PAGE_ROOT3=='flight') || ($PAGE_ROOT1=='travel' && $PAGE_ROOT2=='tdefault' && $PAGE_ROOT3=='flight_result') || ($PAGE_ROOT1=='travel' && $PAGE_ROOT2=='tdefault' && $PAGE_ROOT3=='flight_result_round') || ($PAGE_ROOT1=='travel' && $PAGE_ROOT2=='tdefault' && $PAGE_ROOT3=='flight_result_round_domestic') || ($PAGE_ROOT1=='travel' && $PAGE_ROOT2=='flight')) { echo "active"; } ?>" data-id="flight"><a href="<?php echo base_url(); ?>travel/flight"><i class="fa fa-circle-o" ></i>Flight</a></li>
            <li class="<?php if(($PAGE_ROOT1=='travel' && $PAGE_ROOT2=='tdefault' && $PAGE_ROOT3=='bus') || ($PAGE_ROOT1=='travel' && $PAGE_ROOT2=='bus')) { echo "active"; } ?>" data-id="bus"><a href="<?php echo base_url(); ?>travel/bus"><i class="fa fa-circle-o" ></i> Bus </a></li>
            <li class="<?php if(($PAGE_ROOT1=='travel' && $PAGE_ROOT2=='tdefault' && $PAGE_ROOT3=='hotel') || ($PAGE_ROOT1=='travel' && $PAGE_ROOT2=='hotel')) { echo "active"; } ?>" data-id="hotel"><a href="<?php echo base_url(); ?>travel/hotel"><i class="fa fa-circle-o" ></i> Hotel</a></li> 
            <li class="<?php if(($PAGE_ROOT1=='travel' && $PAGE_ROOT2=='tdefault' && $PAGE_ROOT3=='holiday') || ($PAGE_ROOT1=='travel' && $PAGE_ROOT2=='holiday')) { echo "active"; } ?>" data-id="holiday"><a href="<?php echo base_url(); ?>travel/holiday"><i class="fa fa-circle-o" ></i> Holiday </a></li>
          </ul>
        </li>

<!-- END:: QUESTION SECTION -->

    </ul>

  </section>

  <!-- /.sidebar -->

</aside>