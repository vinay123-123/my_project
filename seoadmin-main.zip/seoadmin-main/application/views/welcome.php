<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
  <?php $this->load->view('include/head'); ?>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php $this->load->view('include/header'); ?>
  
  <!-- Left side column. contains the logo and sidebar -->
 <?php $this->load->view('include/left_sidebar'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-md-6 col-xs-12 col-md-offset-3 dashboard">
        	<div class="head_text_parent">
        		<div class="head_text"><h1>Welcome To Inditab</h1></div>
        		<div class="sub_head_text">SEO Admin - Support</div>
        	</div>
        </div>
      </div>
      <!-- /.row --> 

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <!-- Begin:: Footer -->
<?php $this->load->view('include/footer'); ?>
<!--/. End:: Footer -->

  
</div>
<!-- ./wrapper -->

<?php $this->load->view('include/foot'); ?>
</body>

</html>
