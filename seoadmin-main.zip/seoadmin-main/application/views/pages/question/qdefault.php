<?php 
//print_r($_SESSION);// $this->session->userdata('ADMIN_LOGGEDIN');
if($this->session->userdata('SEO_ADMIN_LOGGEDIN')!=1){
    header('Location:' .BASEURL.ADMIN_BASE_URL."login"); 
}
date_default_timezone_set(DEFAULT_TIME_ZONE);

// print_r($SeoDetails);

$page_name='';
$titlew='';
$h1_tag='';
$meta_title='';
$meta_description='';
$meta_description2='';
$meta_description3='';
$meta_keywords='';
$meta_robots='';
$meta_copyright='';
$og_site_name='';
$og_title='';
$og_image='';
$og_description='';
$og_description2='';
$og_description3='';
$og_url='';
$og_type='';
$canonical='';
$loc='';
$lastmod='';
$changefreq='';
$priority='';
$anchor_rel='';
$extra_fields='';
$schema_data='';
$current_segment='';
$current_segment=$this->uri->segment(3);
$rgtoption=$this->uri->segment(2);



if(isset($SeoDetails) && !empty($SeoDetails)){

  $page_name=$SeoDetails['page_name'];
  $service_name=$SeoDetails['service_name'];
  $titlew=$SeoDetails['title'];
  $h1_tag=$SeoDetails['h1_tag'];
  $meta_title=$SeoDetails['meta_title'];
  $meta_description=$SeoDetails['meta_description'];
  $meta_description2=$SeoDetails['meta_description2'];
  $meta_description3=$SeoDetails['meta_description3'];
  $meta_keywords=$SeoDetails['meta_keywords'];
  $meta_robots=$SeoDetails['meta_robots'];
  $meta_copyright=$SeoDetails['meta_copyright'];
  $og_site_name=$SeoDetails['og_site_name'];
  $og_title=$SeoDetails['og_title'];
  $og_image=$SeoDetails['og_image'];
  $og_description=$SeoDetails['og_description'];
  $og_description2=$SeoDetails['og_description2'];
  $og_description3=$SeoDetails['og_description3'];
  $og_url=$SeoDetails['og_url'];
  $og_type=$SeoDetails['og_type'];
  $canonical=$SeoDetails['canonical'];
  $loc=$SeoDetails['loc'];
  $lastmod=$SeoDetails['lastmod'];
  $changefreq=$SeoDetails['changefreq'];
  $priority=$SeoDetails['priority'];
  $anchor_rel=$SeoDetails['anchor_rel'];
  if(isset($SeoDetails['extra_fields']) && $SeoDetails['extra_fields']!="") { $extra_fields=$SeoDetails['extra_fields']; } else { $extra_fields=''; }

if(isset($SeoDetails['schema_data']) && $SeoDetails['schema_data']!="") { $schema_data=$SeoDetails['schema_data']; } else { $schema_data=''; }
}
?>
<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
  <?php $this->load->view('include/head'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="loader_upload_overlay" id="loader_upload_overlay" style="display:none;">
    <div class="loader_upload_handle">
        <div class="loader_upload_preload">
            <img src="<?php=base_url();?>dist/img/loader.gif" alt="Please wait" title="Please wait"/>
        </div>
        <div class="upload_waiting_txt">Please wait. Kindly donot press refresh or back button</div>
    </div>
</div>
<div class="wrapper">

  <?php $this->load->view('include/header'); ?>
  
  <!-- Left side column. contains the logo and sidebar -->
 <?php $this->load->view('include/left_sidebar'); ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <section class="content-header">
      <div class="row">
       <div class="col-xs-20 col-md-12 col-xs-12">
        <div class="top-heading">
         <h1><?php if(isset($page_name) && $page_name!=""){echo strtoupper($page_name);}else{ echo strtoupper("Question Form"); } ?></h1>
          <ol class="breadcrumb">
                        <li><a href="#"><i class="fa fa-dashboard"></i><?php if(isset($service_name) && !empty($service_name)){echo ucwords($service_name);}else{echo "Travel";}?></a></li>
                        <li><a href="#"><?php if(isset($page_name) && !empty($page_name)){echo ucwords($page_name);}else{ echo "Travel Form"; } ?></a></li>
                        
                    </ol>
       </div>

        <div class="alert alert-success seo_div alert-dismissable" style="display: none;">
            
                <i class="fa fa-check"></i>

                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
           
                
                <span class="success_txt"></span>

        </div>
       <!--#################################### SEO Form Start ####################################-->
       <div class="panel panel-default">
         <div class="new-body panel-body">
          <div class="panel-heading"><?php if(isset($service_name) && !empty($service_name)){echo ucwords($service_name);}else{echo "Travel";}?> - <?php if(isset($page_name) && !empty($page_name)){echo ucwords($page_name);} ?> SEO Form</div>
                 <div class="seo_parent">
                  <form class="form-horizontal" name="tarvel_default_seoform" id="tarvel_default_seoform" action="" method="POST">
                   <div class="seo_inner">
                    <div id="seoform_section">
                     <div class="row">
                      <div class="col-md-12 page_section">
                  
                    </div> 
                   <?php //print_r($levels);die; ?>

                 </div>
                 <table class="markup table table-bordered width-50 myTable">
                <tbody>
                 <tr>
                  <td>Question</td>
                  <td>
                    
                   <input type="text" class="form-control" id="qname" name="qname" placeholder="Please enter Question">
                   <div id="error_qname" class="error_code"><span></span></div>
                 </td>
                  </tr>
                  <tr>
                    <td>Choices</td>
                     <td>
                  <textarea rows="4" cols="50" class="form-control" placeholder="Please enter coma(,) saprated choices" id="choice" name="choice"></textarea>
                   <div id="error_choice" class="error_code"><span></span></div>
                 </td>
                    </tr>
                  <tr>
                    <td>End Date</td>
                     <td>
                        <input type="text" class="form-control" id="edate" name="edate" placeholder="Please enter end date duration in number">
                        <div id="error_enddate" class="error_code"><span></span></div>
                     </td>
                  </tr>
               

                      </tbody>
                    </table>
                    <table class="markup table table-bordered width-50 myTable">
                      
                    <tbody>
                          
						 <tr>
                        <td>Levels</td>
                         <td>
                          <select class="form-control" name="level" id="level">
                              <option value=""> Select Level</option>
                             <?php foreach($levels as $levels): ?>
							 <option value="<?php echo $levels['id']; ?>"><?php echo $levels['level']; ?></option>
                          <?php endforeach ?>

                            </select>
                   <div id="error_level" class="error_code"><span></span></div>
                 </td>
                        </tr>
						
                        <td>Correct Answer</td>
                         <td>
                   <input type="text" class="form-control" id="correct_ans" name="correct_ans" placeholder="please enter correct answer from choice.">
                   <div id="error_correct_ans" class="error_code"><span></span></div>
                 </td>
                        </tr>
                        
                    
                     
                        </tbody>
                      </table>
                        <div class="row box-footer" style="margin: 0;">

          <div class="pull-right seo_update_btn">
    
          <button type="submit" class="btn btn-primary" id="ag_submit" name="ag_submit">Submit</button>
       
          </div>

      </div>
                      
                    </div>
                    


           </div>
         </form>
      
         </div>
       </div>
     </div></section>
  </div>
  <!-- /.content-wrapper -->


 <!-- Begin:: Footer -->
<?php $this->load->view('include/footer'); ?>
<!--/. End:: Footer -->

  
  
</div>
<!-- ./wrapper -->
<?php $this->load->view('include/foot'); ?>
<script>
  $("form#tarvel_default_seoform").submit(function(e) {

    e.preventDefault(); 


    var formData = new FormData(this);
    var errorflag=0;
   // var nospecial = /['"]/gi;
     //var meta_description_nospecial=/['"]/gi;
    var qname=$('#qname').val();
  var choice=$('#choice').val();
  var edate=$('#edate').val();
  var level=$('#level').val();
  var correct_ans=$('#correct_ans').val();
  
  
  
    if(qname==''){
        
      $("#qname").addClass('inpt_error');
      $('#error_qname span').html('Please Enter Question');
      errorflag=1;
    }else{
      $("#qname").removeClass(' inpt_error ');
    $('#error_qname span').html('');
    }

    if(choice ==''){
        
      $("#choice").addClass('inpt_error');
      $('#error_choice span').html('Please Enter Choices');
      errorflag=1;
    }else{
      $("#choice").removeClass(' inpt_error ');
    $('#error_choice span').html('');
    }
	
    if(edate==''){
        
      $("#edate").addClass('inpt_error');
      $('#error_enddate span').html('Please Enter End Date');
      errorflag=1;
    }else{
      $("#edate").removeClass(' inpt_error ');
    $('#error_enddate span').html('');
    }
	
    if(level==''){
        
      $("#level").addClass('inpt_error');
      $('#error_level span').html('Please Select Level');
      errorflag=1;
    }else{
      $("#level").removeClass(' inpt_error ');
    $('#error_level span').html('');
    }
	
    if(correct_ans==''){
        
      $("#correct_ans").addClass('inpt_error');
      $('#error_correct_ans span').html('Please Enter Correct answer');
      errorflag=1;
    }else{
      $("#correct_ans").removeClass(' inpt_error ');
    $('#error_correct_ans span').html('');
    }

    
	
	
	
    // alert(Base_URL+"tarvel/tdefault/seo_update");
    if(errorflag==0)
  {
    $('.loader_upload_overlay').show();
     $.ajax({        

          url:Base_URL+"question/seo_update",

          type: 'POST',

          data: formData,

          //timeout: 60000, //Set your timeout value in milliseconds or 0 for unlimited

          cache: false,

          contentType: false,

          processData: false,

          success: function (data) {
            
			console.log(data);
            $('.loader_upload_overlay').hide();
            //console.log(data);
            data=data.trim();
            var obj = JSON.parse(data);
            

            if(obj.status==200)
            {
              $('.alert-success.seo_div span.success_txt').addClass('noerror');
              $('.alert-success.seo_div span.success_txt').removeClass('error');
              $('.alert-success.seo_div span.success_txt').html(obj.message);
              
              $('.alert-success.seo_div').show();
              $("html, body").animate({ scrollTop: 0 }, "slow");

            }else if(data==400){
              $('.alert-success.seo_div span.success_txt').addClass('error');
              $('.alert-success.seo_div span.success_txt').removeClass('noerror');
              $('.alert-success.seo_div span.success_txt').html(obj.message);

              $('.alert-success.seo_div').show();
              $("html, body").animate({ scrollTop: 0 }, "slow");
              // $('.alert-success.success_div').hide();
              // $('.alert-success.success_div span').html('');
              // $('.alert-success.agent_div').hide();
              

            }

          }

        }); 

      }

});

function resetSEOForm()
{
    
    var titlew=$('#titlew').val('');
    var h1_tag=$('#h1_tag').val('');
  var meta_title=$('#meta_title').val('');
  var meta_description=$('#meta_description').val('');
  var meta_description2=$('#meta_description2').val('');
  var meta_description3=$('#meta_description3').val('');
  var meta_keywords=$('#meta_keywords').val('');
  var meta_robots=$('#meta_robots').val('');
  var meta_copyright=$('#meta_copyright').val('');
  var og_site_name=$('#og_site_name').val('');
  var og_title=$('#og_title').val('');
  var og_image=$('#og_image').val('');
  var og_description=$('#og_description').val('');
  var og_description2=$('#og_description2').val('');
  var og_description3=$('#og_description3').val('');
  var og_url=$('#og_url').val('');
  var og_type=$('#og_type').val('');
  var canonical=$('#canonical').val('');
  var loc=$('#loc').val('');
  var lastmod=$('#lastmod').val('');
  var changefreq=$('#changefreq').val('');
  var priority=$('#priority').val('');
  var schema_data=$("#schema_data").val('');
}

$( document ).ready(function() {
  $( "#reset" ).on('click',function() {
    // alert('hii');
      resetSEOForm();

    });

    $("#lastmod").keyup(function(){
                if ($(this).val().length == 2){
                    $(this).val($(this).val() + "-");
                }else if ($(this).val().length == 5){
                    $(this).val($(this).val() + "-");
                }else if($(this).val().length > 10){
                  var pprt=$(this).val().substr(0, 10);
                  $(this).val(pprt);
                }
            });

    $('#page_name').on('change', function() {
 
   window.location.href=Base_URL+'travel/tdefault/'+this.value+'/'+$('#service_name').val();
     
});
});
</script>
</body>
</html>
