<?php 
//print_r($_SESSION);// $this->session->userdata('ADMIN_LOGGEDIN');
if($this->session->userdata('SEO_ADMIN_LOGGEDIN')!=1){
    header('Location:' .BASEURL.ADMIN_BASE_URL."login"); 
}
date_default_timezone_set(DEFAULT_TIME_ZONE);

// print_r($SeoDetails);

$page_name='';
$titlew='';
$h1_tag='';
$meta_title='';
$meta_description='';
$meta_description2='';
$meta_description3='';
$meta_keywords='';
$meta_robots='';
$meta_copyright='';
$og_site_name='';
$og_title='';
$og_image='';
$og_description='';
$og_description2='';
$og_description3='';
$og_url='';
$og_type='';
$canonical='';
$loc='';
$lastmod='';
$changefreq='';
$priority='';
$anchor_rel='';
$current_segment='';
$current_segment=$this->uri->segment(3);
$rgtoption=$this->uri->segment(2);



if(isset($SeoDetails) && !empty($SeoDetails)){

  $page_name=$SeoDetails['page_name'];
  $service_name=$SeoDetails['service_name'];
  $titlew=$SeoDetails['title'];
  $h1_tag=$SeoDetails['h1_tag'];
  $meta_title=$SeoDetails['meta_title'];
  $meta_description=$SeoDetails['meta_description'];
  $meta_description2=$SeoDetails['meta_description2'];
  $meta_description3=$SeoDetails['meta_description3'];
  $meta_keywords=$SeoDetails['meta_keywords'];
  $meta_robots=$SeoDetails['meta_robots'];
  $meta_copyright=$SeoDetails['meta_copyright'];
  $og_site_name=$SeoDetails['og_site_name'];
  $og_title=$SeoDetails['og_title'];
  $og_image=$SeoDetails['og_image'];
  $og_description=$SeoDetails['og_description'];
  $og_description2=$SeoDetails['og_description2'];
  $og_description3=$SeoDetails['og_description3'];
  $og_url=$SeoDetails['og_url'];
  $og_type=$SeoDetails['og_type'];
  $canonical=$SeoDetails['canonical'];
  $loc=$SeoDetails['loc'];
  $lastmod=$SeoDetails['lastmod'];
  $changefreq=$SeoDetails['changefreq'];
  $priority=$SeoDetails['priority'];
  $anchor_rel=$SeoDetails['anchor_rel'];

  if(isset($SeoDetails['faqs_rowInfo']) && $SeoDetails['faqs_rowInfo']!="") { $faqs_rowInfo=$SeoDetails['faqs_rowInfo']; } else { $faqs_rowInfo=''; }

if(isset($SeoDetails['faqs_mychk_field']) && $SeoDetails['faqs_mychk_field']!="") { $faqs_mychk_field=$SeoDetails['faqs_mychk_field']; } else { $faqs_mychk_field=''; }

if(isset($SeoDetails['agents_feedback_rowInfo']) && $SeoDetails['agents_feedback_rowInfo']!="") { $agents_feedback_rowInfo=$SeoDetails['agents_feedback_rowInfo']; } else { $agents_feedback_rowInfo=''; }

if(isset($SeoDetails['agents_feedback_mychk_field']) && $SeoDetails['agents_feedback_mychk_field']!="") { $agents_feedback_mychk_field=$SeoDetails['agents_feedback_mychk_field']; } else { $agents_feedback_mychk_field=''; }

  if(isset($SeoDetails['extra_fields']) && $SeoDetails['extra_fields']!="") { $extra_fields=$SeoDetails['extra_fields']; } else { $extra_fields=''; }

if(isset($SeoDetails['schema_data']) && $SeoDetails['schema_data']!="") { $schema_data=$SeoDetails['schema_data']; } else { $schema_data=''; } 
}
?>
<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
  <?php $this->load->view('include/head'); ?>
<style type="text/css">
    .recharge_full_detail_parent{clear: both;}
  </style>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="loader_upload_overlay" id="loader_upload_overlay" style="display:none;">
    <div class="loader_upload_handle">
        <div class="loader_upload_preload">
            <img src="<?=base_url();?>dist/img/loader.gif" alt="Please wait" title="Please wait"/>
        </div>
        <div class="upload_waiting_txt">Please wait. Kindly donot press refresh or back button</div>
    </div>
</div>
<div class="wrapper">

  <?php $this->load->view('include/header'); ?>
  
  <!-- Left side column. contains the logo and sidebar -->
 <?php $this->load->view('include/left_sidebar'); ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <section class="content-header">
      <div class="row">
       <div class="col-xs-20 col-md-12 col-xs-12">
        <div class="top-heading">
         <h1><? if(isset($page_name) && $page_name!=""){echo strtoupper($page_name);}else{ echo strtoupper("Franchisee Form"); } ?></h1>
          <ol class="breadcrumb">
                        <li><a href="#"><i class="fa fa-dashboard"></i><? if(isset($service_name) && !empty($service_name)){echo ucwords($service_name);}else{echo "Franchisee";}?></a></li>
                        <li><a href="#"><? if(isset($page_name) && !empty($page_name)){echo ucwords($page_name);}else{ echo "Franchisee Form"; } ?></a></li>
                        
                    </ol>
       </div>

        <div class="alert alert-success seo_div alert-dismissable" style="display: none;">
            
                <i class="fa fa-check"></i>

                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
           
                
                <span class="success_txt"></span>

        </div>
       <!--#################################### SEO Form Start ####################################-->
       <div class="panel panel-default">
         <div class="new-body panel-body">
          <div class="panel-heading"><? if(isset($service_name) && !empty($service_name)){echo ucwords($service_name);}else{echo "Franchisee";}?> - <? if(isset($page_name) && !empty($page_name)){echo ucwords($page_name);} ?> SEO Form</div>
                 <div class="seo_parent">
                  <form class="form-horizontal" name="other_default_seoform" id="other_default_seoform" action="" method="POST">
                   <div class="seo_inner">
                    <div id="seoform_section">
                     <div class="row">
                      <div class="col-md-12 page_section">
                       <div class="row my_row">
                           <div class="col-md-3 col-sm-12">
                            
                          </div>
                          <div class="col-md-2 col-sm-12">
                            <label>
                              Select Page
                            </label>
                          </div>
                          <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              
                              <option value>---- Select Page ----</option> 
                             

                              <option  value="franchisee_default" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='franchisee_default'){ echo 'selected';}}else{if(strtolower($current_segment)=='franchisee_default'){ echo 'selected';}}?>>Default</option>                               
                               
                               <option  value="home_fenquiry" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='home_fenquiry'){ echo 'selected';}}else{if(strtolower($current_segment)=='home_fenquiry'){ echo 'selected';}}?>>Home</option>
      
                              <option  value="recharge_fenquiry" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='recharge_fenquiry'){ echo 'selected';}}else{if(strtolower($current_segment)=='recharge_fenquiry'){ echo 'selected';}}?>>Recharge</option>

                              
                                                            
                              <option  value="billpayment_fenquiry" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='billpayment_fenquiry'){ echo 'selected';}}else{ if(strtolower($current_segment)=='billpayment_fenquiry'){echo 'selected';}}?>>Bill Payment</option>


                              <option  value="pan_fenquiry" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='pan_fenquiry'){ echo 'selected';}}else{ if(strtolower($current_segment)=='pan_fenquiry'){ echo 'selected';}}?>>Pan</option>

                              <option  value="money_transfer_fenquiry" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='money_transfer_fenquiry'){ echo 'selected';}}else{ if(strtolower($current_segment)=='money_transfer_fenquiry'){ echo 'selected';}}?>>Money Transfer</option>

                                <option  value="aeps_fenquiry" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='aeps_fenquiry'){ echo 'selected';}}else{if(strtolower($current_segment)=='aeps_fenquiry'){echo 'selected';}}?> >AEPS</option>

                                <option  value="dsc_fenquiry" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='dsc_fenquiry'){ echo 'selected';}}else{if(strtolower($current_segment)=='dsc_fenquiry'){echo 'selected';}}?> >DSC</option>

                                <option  value="gst_fenquiry" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='gst_fenquiry'){ echo 'selected';}}else{if(strtolower($current_segment)=='gst_fenquiry'){echo 'selected';}}?> >GST</option>

                                <option  value="passport_fenquiry" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='passport_fenquiry'){ echo 'selected';}}else{ if(strtolower($current_segment)=='passport_fenquiry'){ echo 'selected';}}?>>Passport</option>

                                <option  value="microatm_fenquiry" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='microatm_fenquiry'){ echo 'selected';}}else{if(strtolower($current_segment)=='microatm_fenquiry'){echo 'selected';}}?> >Micro ATM</option>

                                <option  value="about_us" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='about_us'){ echo 'selected';}}else{if(strtolower($current_segment)=='about_us'){echo 'selected';}}?> >About Us</option>

                                <option  value="customer_care" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='customer_care'){ echo 'selected';}}else{if(strtolower($current_segment)=='customer_care'){echo 'selected';}}?> >Customer Care</option>

                                <option  value="privacy_policy" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='privacy_policy'){ echo 'selected';}}else{if(strtolower($current_segment)=='privacy_policy'){echo 'selected';}}?> >Privacy Policy</option>

                                <option  value="terms" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='terms'){ echo 'selected';}}else{if(strtolower($current_segment)=='terms'){echo 'selected';}}?> >Terms</option>

                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>   
                          <div class="col-md-3 col-sm-12">
                            
                          </div>
                      </div>
                    </div> 
                   

                 </div>
                 <table class="markup table table-bordered width-50 myTable">
                <tbody>
                 <tr>
                  <td>Service Name</td>
                  <td>
                    
                   <input type="text" class="form-control" id="service_name" name="service_name" <? if(isset($service_name) && !empty($service_name)) {  ?> value="<?=$SeoDetails['service_name'];?>" <? } else { ?> value="franchisee" <? } ?>  readonly="">
                   <div id="error_service_name" class="error_code"><span></span></div>
                 </td>
                  </tr>
                  <tr>
                    <td>Title</td>
                     <td>
                      <textarea rows="4" cols="50" class="form-control" id="titlew" name="titlew"><? if(isset($titlew) && !empty($titlew)) {  echo $SeoDetails['title'];  } else{ echo ""; } ?></textarea>
                   <div id="error_titlew" class="error_code"><span></span></div>
                 </td>
                    </tr>
                    <tr>
                    <td>H1 Tag</td>
                     <td>
              <input type="text" class="form-control" id="h1_tag" name="h1_tag"  value="<? if(isset($h1_tag) && !empty($h1_tag)) {  echo $SeoDetails['h1_tag'];  } else{ echo ""; } ?>" >
              <div id="error_h1_tag" class="error_code"><span></span></div>
           </td>
                </tr> 
                    <tr>
                      <td>Meta Title</td>
                      <td>
                        <textarea rows="4" cols="50" class="form-control" id="meta_title" name="meta_title"><? if(isset($meta_title) && !empty($meta_title)) {  echo $SeoDetails['meta_title'];  } else{ echo ""; } ?></textarea>
                   
                   <div id="error_meta_title" class="error_code"><span></span></div>
                 </td>
                      </tr>
                      <tr>
                        <td>Meta Description1</td>
                         <td>
                          <textarea rows="4" cols="50" class="form-control" id="meta_description" name="meta_description"><? if(isset($meta_description) && !empty($meta_description)) {  echo $SeoDetails['meta_description'];  } else{ echo ""; } ?> </textarea>
                  
                   <div id="error_meta_description" class="error_code"><span></span></div>
                 </td>
                        </tr>

                        <tr>
                        <td>Meta Description2</td>
                         <td>
                          <textarea rows="4" cols="50" class="form-control" id="meta_description2" name="meta_description2"><? if(isset($meta_description2) && !empty($meta_description2)) {  echo $SeoDetails['meta_description2'];  } else{ echo ""; } ?> </textarea>
                  
                   <div id="error_meta_description2" class="error_code"><span></span></div>
                 </td>
                        </tr>


                        <tr>
                        <td>Meta Description3</td>
                         <td>
                          <textarea rows="4" cols="50" class="form-control" id="meta_description3" name="meta_description3"><? if(isset($meta_description3) && !empty($meta_description3)) {  echo $SeoDetails['meta_description3'];  } else{ echo ""; } ?> </textarea>
                  
                   <div id="error_meta_description3" class="error_code"><span></span></div>
                 </td>
                        </tr>

                         <tr>
                        <td>Meta Keywords</td>
                         <td>
                          <textarea rows="4" cols="50" class="form-control" id="meta_keywords" name="meta_keywords"><? if(isset($meta_keywords) && !empty($meta_keywords)) {  echo $SeoDetails['meta_keywords'];  } else{ echo ""; } ?></textarea>
                   
                   <div id="error_meta_keywords" class="error_code"><span></span></div>
                 </td>
                        </tr>

                         <tr>
                        <td>Meta Robots</td>
                         <td>
                   <input type="text" class="form-control" id="meta_robots" name="meta_robots" <? if(isset($meta_robots) && !empty($meta_robots)) {  ?> value="<?=$SeoDetails['meta_robots'];?>" <? } else{ ?> value="" <? } ?>>
                   <div id="error_meta_robots" class="error_code"><span></span></div>
                 </td>
                        </tr>

                         <tr>
                        <td>Meta Copyright</td>
                         <td>
                   <input type="text" class="form-control" id="meta_copyright" name="meta_copyright" <? if(isset($meta_copyright) && !empty($meta_copyright)) {  ?> value="<?=$SeoDetails['meta_copyright'];?>" <? } else{ ?> value="" <? } ?>>
                   <div id="error_meta_copyright" class="error_code"><span></span></div>
                 </td>
                        </tr>

                         <tr>
                        <td>Og Site Name</td>
                         <td>
                   <input type="text" class="form-control" id="og_site_name" name="og_site_name" <? if(isset($og_site_name) && !empty($og_site_name)) {  ?> value="<?=$SeoDetails['og_site_name'];?>" <? } else{ ?> value="" <? } ?>>
                   <div id="error_og_site_name" class="error_code"><span></span></div>
                 </td>
                        </tr>

                         <tr>
                        <td>Og Title</td>
                         <td>
                          <textarea rows="4" cols="50" class="form-control" id="og_title" name="og_title"><? if(isset($og_title) && !empty($og_title)) {  echo $SeoDetails['og_title'];  } else{ echo ""; } ?></textarea>
                   
                   <div id="error_og_title" class="error_code"><span></span></div>
                 </td>
                        </tr>
                         <tr>
                        <td>Additional Fields</td>
                         <td>
           <textarea rows="4" cols="50" class="form-control" name="extra_fields" id="extra_fields"><?  if(isset($SeoDetails['extra_fields']) && $SeoDetails['extra_fields']!='') { echo $SeoDetails['extra_fields']; }  ?></textarea>
                   <div id="error_extra_fields" class="error_code"><span></span></div>
                 </td>
                        </tr>
                      </tbody>
                    </table>
                    <table class="markup table table-bordered width-50 myTable">
                      
                    <tbody>
                     <tr>
                        <td>Og Image</td>
                         <td>
                   <input type="text" class="form-control" id="og_image" name="og_image" <? if(isset($og_image) && !empty($og_image)) {  ?> value="<?=$SeoDetails['og_image'];?>" <? } else{ ?> value="" <? } ?>>
                   <div id="error_og_image" class="error_code"><span></span></div>
                 </td>
                        </tr>
                      <tr>
                        <td>Og Description1</td>
                         <td>
                          <textarea rows="4" cols="50" class="form-control" id="og_description" name="og_description"><? if(isset($og_description) && !empty($og_description)) {  echo $SeoDetails['og_description'];  } else{ echo ""; } ?></textarea>
                   
                   <div id="error_og_description" class="error_code"><span></span></div>
                 </td>
                        </tr>

                        <tr>
                        <td>Og Description2</td>
                         <td>
                          <textarea rows="4" cols="50" class="form-control" id="og_description2" name="og_description2"><? if(isset($og_description2) && !empty($og_description2)) {  echo $SeoDetails['og_description2'];  } else{ echo ""; } ?></textarea>
                   
                   <div id="error_og_description2" class="error_code"><span></span></div>
                 </td>
                        </tr>

                        <tr>
                        <td>Og Description3</td>
                         <td>
                          <textarea rows="4" cols="50" class="form-control" id="og_description3" name="og_description3"><? if(isset($og_description3) && !empty($og_description3)) {  echo $SeoDetails['og_description3'];  } else{ echo ""; } ?></textarea>
                   
                   <div id="error_og_description3" class="error_code"><span></span></div>
                 </td>
                        </tr>
                        <tr>
                        <td>Og URL</td>
                         <td>
                   <input type="text" class="form-control" id="og_url" name="og_url" <? if(isset($og_url) && !empty($og_url)) {  ?> value="<?=$SeoDetails['og_url'];?>" <? } else{ ?> value="" <? } ?>>
                   <div id="error_og_url" class="error_code"><span></span></div>
                 </td>
                        </tr>
                        <tr>
                        <td>Og Type</td>
                         <td>
                   <input type="text" class="form-control" id="og_type" name="og_type" <? if(isset($og_type) && !empty($og_type)) {  ?> value="<?=$SeoDetails['og_type'];?>" <? } else{ ?> value="" <? } ?>>
                   <div id="error_og_type" class="error_code"><span></span></div>
                 </td>
                        </tr>
                        <tr>
                        <td>Canonical</td>
                         <td>
                   <input type="text" class="form-control" id="canonical" name="canonical" <? if(isset($canonical) && !empty($canonical)) {  ?> value="<?=$SeoDetails['canonical'];?>" <? } else{ ?> value="" <? } ?>>
                   <div id="error_canonical" class="error_code"><span></span></div>
                 </td>
                        </tr>
                        <tr>
                        <td>LOC</td>
                         <td>
                   <input type="text" class="form-control" id="loc" name="loc" <? if(isset($loc) && !empty($loc)) {  ?> value="<?=$SeoDetails['loc'];?>" <? } else{ ?> value="" <? } ?>>
                   <div id="error_loc" class="error_code"><span></span></div>
                 </td>
                        </tr>

                         <tr>
                        <td>Last Modified</td>
                         <td>
                  <input type="text" class="form-control" id="lastmod" name="lastmod" autocomplete="off" placeholder="dd-mm-yyyy" maxlength="10"  onkeydown="validate_number(event);" onkeyup="validate_number(event);" <? if(isset($lastmod) && !empty($lastmod) && $lastmod!='0000-00-00') {  ?> value="<?=date("d-m-Y", strtotime($SeoDetails['lastmod']))?>" <? } else{ ?> value="<?=date("d-m-Y");?>" <?php } ?>>
                   <div id="error_lastmod" class="error_code"><span></span></div>
                 </td>
                        </tr>

                         <tr>
                        <td>Change Frequently</td>
                         <td>
                          <select class="form-control" name="changefreq" id="changefreq">
                              <option value="">---- Select Page ----</option>
                              <option <? if(isset($changefreq) && !empty($changefreq)) { if(strtolower($changefreq)=='always'){ echo 'selected';}} ?> value="always">Always</option>
                              <option <? if(isset($changefreq) && !empty($changefreq)) { if(strtolower($changefreq)=='hourly'){ echo 'selected';}} ?> value="hourly">Hourly</option>
                              <option <? if(isset($changefreq) && !empty($changefreq)) { if(strtolower($changefreq)=='daily'){ echo 'selected';}} ?> value="daily">Daily</option>
                              <option <? if(isset($changefreq) && !empty($changefreq)) { if(strtolower($changefreq)=='weekly'){ echo 'selected';}} ?> value="weekly">Weekly</option>
                              <option <? if(isset($changefreq) && !empty($changefreq)) { if(strtolower($changefreq)=='monthly'){ echo 'selected';}} ?> value="monthly">Monthly</option>
                              <option <? if(isset($changefreq) && !empty($changefreq)) { if(strtolower($changefreq)=='yearly'){ echo 'selected';}} ?> value="yearly">Yearly</option>
                              <option <? if(isset($changefreq) && !empty($changefreq)) { if(strtolower($changefreq)=='never'){ echo 'selected';}} ?> value="never">Never</option>

                            </select>
                   <div id="error_changefreq" class="error_code"><span></span></div>
                 </td>
                        </tr>
                        <tr>
                        <td>Priority</td>
                         <td>
                   <input type="text" class="form-control" id="priority" name="priority" <? if(isset($priority) && !empty($priority)) {  ?> value="<?=$SeoDetails['priority'];?>" <? } else{ ?> value="" <? } ?>>
                   <div id="error_priority" class="error_code"><span></span></div>
                 </td>
                        </tr>
                        
                          <tr>
                        <td>Anchor Relation</td>
                         <td>
                   <input type="text" class="form-control" id="anchor_rel" name="anchor_rel" <? if(isset($anchor_rel) && !empty($anchor_rel)) {  ?> value="<?=$SeoDetails['anchor_rel'];?>" <? } else{ ?> value="" <? } ?>>
                   <div id="error_anchor_rel" class="error_code"><span></span></div>
                 </td>
                        </tr>

                         <tr>
                        <td>Schema</td>
                         <td>
                          <textarea rows="4" cols="50" class="form-control" id="schema_data" name="schema_data"><? if(isset($schema_data) && !empty($schema_data)) {  echo stripslashes($SeoDetails['schema_data']);  } else{ echo ""; } ?></textarea>
                   <div id="error_schema_data" class="error_code"><span></span></div>
                 </td>
                        </tr>
                        </tbody>
                      </table>

                       <?php /* **************** Begin:: Franchisee FAQ Full Details Section **************** */ ?>

                      <div class="recharge_full_detail_parent">
                        <div class="recharge_full_detail_inner">
                          <div class="heading_box"><h2>To add a faq section set Click on Add Button</h2></div>
                          <h6>Check the box if you don't want to set data for FAQ Section <INPUT type="checkbox" id="mychk" name="mychk"  <? $mychk_field_new=''; if(isset($faqs_mychk_field) && !empty($faqs_mychk_field)) {   $mychk_field_new=trim($SeoDetails['faqs_mychk_field']); if($mychk_field_new=='true'){ ?> value="<?=$SeoDetails['faqs_mychk_field'];?>" checked=checked <? }else{ ?> value="false" <? } }else {  ?> value="false"  <?php $mychk_field_new=" ";  } ?> /></h6>
                          <TABLE id="dataTable"  border="1" class="markup table table-bordered width-100" style="margin-top: 15px;clear: both;">
                            <div class="input_fields_wrap">
                    <button class="add_field_button btn btn-primary">Add More Rows</button>
                    <div class="dynamic_fields" id="dynamic_fields"> 
                      <tbody>
                    <?php  $mychk_field_new=''; if(isset($faqs_mychk_field) && !empty($faqs_mychk_field)) {   $mychk_field_new= trim($SeoDetails['faqs_mychk_field']); } else {  $mychk_field_new=" ";  } ?>

                    <?php  $rowInfoArray=array(); $rowInfo_new=array(); if(isset($faqs_rowInfo) && !empty($faqs_rowInfo)){$rowInfo_new=json_decode($faqs_rowInfo,true);} 

                    if(isset($rowInfo_new) && !empty($rowInfo_new)) { $rowInfoArray=$rowInfo_new; } else {  $rowInfoArray=array(); $rowInfo_new=array(); } ?>
                   

                   <?php if($mychk_field_new=='false'){ 
                      $counter=0;
                      if(isset($rowInfoArray) && !empty($rowInfoArray)){ ?>
            
                      <?php foreach($rowInfoArray as $rowval){  ?>
                          
                            <tr>
                      
                      <td>
                              <select class="form-control" id="rech_htag_<?php echo $counter; ?>" name="rowInfo[<?php echo $counter; ?>][rech_htag]" ><option value="">Select H Tag</option><option value="h1" <?php if(isset($rowInfoArray[$counter]['rech_htag']) && $rowInfoArray[$counter]['rech_htag']=='h1'){ echo "selected"; } ?> >H1</option><option value="h2" <?php if(isset($rowInfoArray[$counter]['rech_htag']) && $rowInfoArray[$counter]['rech_htag']=='h2'){ echo "selected"; } ?> >H2</option><option value="h3" <?php if(isset($rowInfoArray[$counter]['rech_htag']) && $rowInfoArray[$counter]['rech_htag']=='h3'){ echo "selected"; } ?> >H3</option><option value="h4" <?php if(isset($rowInfoArray[$counter]['rech_htag']) && $rowInfoArray[$counter]['rech_htag']=='h4'){ echo "selected"; } ?> >H4</option><option value="h5" <?php if(isset($rowInfoArray[$counter]['rech_htag']) && $rowInfoArray[$counter]['rech_htag']=='h5'){ echo "selected"; } ?> >H5</option><option value="h6" <?php if(isset($rowInfoArray[$counter]['rech_htag']) && $rowInfoArray[$counter]['rech_htag']=='h6'){ echo "selected"; } ?> >H6</option></select><div id="error_rech_htag_<?php echo $counter; ?>" class="error_code"><span></span></div>
                                      <input type="text" class="form-control" id="rech_title_<?php echo $counter; ?>" name="rowInfo[<?php echo $counter; ?>][rech_title]" placeholder="Title" <?php if(isset($rowInfoArray[$counter]['rech_title']) && $rowInfoArray[$counter]['rech_title']!=''){ ?> value="<?=$rowInfoArray[$counter]['rech_title']?>" <?php }else{ ?> value="" <? } ?>>
                          <div id="error_rech_title_<?php echo $counter; ?>" class="error_code"><span></span></div>
                      </td>
                       <td>
                        <textarea class="ckeditor" id="rech_desc_<?php echo $counter; ?>" name="rowInfo[<?php echo $counter; ?>][rech_desc]" placeholder="Description" rows="10" cols="80">
                          <?php if(isset($rowInfoArray[$counter]['rech_desc']) && $rowInfoArray[$counter]['rech_desc']!=''){ echo stripslashes($rowInfoArray[$counter]['rech_desc']); }else{  } ?></textarea>
                                      <div id="error_rech_desc_<?php echo $counter; ?>" class="error_code"><span></span></div>
                      </td>
                      <td colspan="3"><button class="remove_field btn btn-danger" >Remove</button></td>
                    </tr>
                    
                        <?php $counter++;   } ?>
                        
                        <?php   }
                        
                        }
                       ?>
                    
                    </tbody>  
                    </div>
                 
                </div>
              </TABLE>
                        </div>
                      </div>
                      <?php /* **************** End:: Franchisee FAQ Full Details Section **************** */ ?>

                      <?php /* **************** Begin:: Franchisee Agents Feedback Full Details Section **************** */ ?>

                      <div class="recharge_full_detail_parent">
                        <div class="recharge_full_detail_inner">
                          <div class="heading_box"><h2>To add a Agents Feedback section set Click on Add Button</h2></div>
                          <h6>Check the box if you don't want to set data for Agents Feedback Section <INPUT type="checkbox" id="agents_feedback_mychk" name="agents_feedback_mychk"  <? $mychk_field_new=''; if(isset($agents_feedback_mychk_field) && !empty($agents_feedback_mychk_field)) {   $mychk_field_new=trim($SeoDetails['agents_feedback_mychk_field']); if($mychk_field_new=='true'){ ?> value="<?=$SeoDetails['agents_feedback_mychk_field'];?>" checked=checked <? }else{ ?> value="false" <? } }else {  ?> value="false"  <?php $mychk_field_new=" ";  } ?> /></h6>
                          <TABLE id="dataTable_feedback"  border="1" class="markup table table-bordered width-100" style="margin-top: 15px;clear: both;">
                            <div class="input_fields_wrap_feedback">
                    <button class="add_field_button_feedback btn btn-primary">Add More Rows</button>
                    <div class="dynamic_fields" id="dynamic_fields"> 
                      <tbody>
                    <?php  $mychk_field_new1=''; if(isset($agents_feedback_mychk_field) && !empty($agents_feedback_mychk_field)) {   $mychk_field_new1= trim($SeoDetails['agents_feedback_mychk_field']); } else {  $mychk_field_new1=" ";  } ?>

                    <?php  $rowInfoArray1=array(); $rowInfo_new1=array(); if(isset($agents_feedback_rowInfo) && !empty($agents_feedback_rowInfo)){ $rowInfo_new1=json_decode($agents_feedback_rowInfo,true); }

                    if(isset($rowInfo_new1) && !empty($rowInfo_new1)) { $rowInfoArray1=$rowInfo_new1; } else {  $rowInfoArray1=array(); $rowInfo_new1=array(); } ?>
                   

                   <?php if($mychk_field_new1=='false'){ 
                      $counterr=0;
                      if(isset($rowInfoArray1) && !empty($rowInfoArray1)){ ?>
            
                      <?php foreach($rowInfoArray1 as $rowval){  ?>
                          
                            <tr>
                      
                      <td>
                              
                          <input type="text" class="form-control" id="rech_name_<?php echo $counterr; ?>" name="rowInfo_feedback[<?php echo $counterr; ?>][rech_name]" placeholder="Title" <?php if(isset($rowInfoArray1[$counterr]['rech_name']) && $rowInfoArray1[$counterr]['rech_name']!=''){ ?> value="<?=$rowInfoArray1[$counterr]['rech_name']?>" <?php }else{ ?> value="" <? } ?>>
                          <div id="error_rech_name_<?php echo $counterr; ?>" class="error_code"><span></span></div>

                           <input type="text" class="form-control" id="rech_profile_<?php echo $counterr; ?>" name="rowInfo_feedback[<?php echo $counterr; ?>][rech_profile]" placeholder="Profile" <?php if(isset($rowInfoArray1[$counterr]['rech_profile']) && $rowInfoArray1[$counterr]['rech_profile']!=''){ ?> value="<?=$rowInfoArray1[$counterr]['rech_profile']?>" <?php }else{ ?> value="" <? } ?>>
                          <div id="error_rech_profile_<?php echo $counterr; ?>" class="error_code"><span></span></div>

                           <input type="hidden" class="form-control" id="rech_imagepath_<?php echo $counterr; ?>" name="rowInfo_feedback[<?php echo $counterr; ?>][rech_imagepath]" placeholder="Image path" <?php if(isset($rowInfoArray1[$counterr]['rech_imagepath']) && $rowInfoArray1[$counterr]['rech_imagepath']!=''){ ?> value="<?=$rowInfoArray1[$counterr]['rech_imagepath']?>" <?php }else{ ?> value="" <? } ?>>
                          <div id="error_rech_imagepath_<?php echo $counterr; ?>" class="error_code"><span></span></div>

                           <input type="text" class="form-control" id="rech_extra1_<?php echo $counterr; ?>" name="rowInfo_feedback[<?php echo $counterr; ?>][rech_extra1]" placeholder="Extra Field 1" <?php if(isset($rowInfoArray1[$counterr]['rech_extra1']) && $rowInfoArray1[$counterr]['rech_extra1']!=''){ ?> value="<?=$rowInfoArray1[$counterr]['rech_extra1']?>" <?php }else{ ?> value="" <? } ?>>
                          <div id="error_rech_extra1_<?php echo $counterr; ?>" class="error_code"><span></span></div>

                           <input type="text" class="form-control" id="rech_extra2_<?php echo $counterr; ?>" name="rowInfo_feedback[<?php echo $counterr; ?>][rech_extra2]" placeholder="Extra Field 2" <?php if(isset($rowInfoArray1[$counterr]['rech_extra2']) && $rowInfoArray1[$counterr]['rech_extra2']!=''){ ?> value="<?=$rowInfoArray1[$counterr]['rech_extra2']?>" <?php }else{ ?> value="" <? } ?>>
                          <div id="error_rech_extra2_<?php echo $counterr; ?>" class="error_code"><span></span></div>
                      </td>
                       <td>
                        <textarea class="ckeditor" id="rech_content_<?php echo $counterr; ?>" name="rowInfo_feedback[<?php echo $counterr; ?>][rech_content]" placeholder="Description" rows="10" cols="80">
                          <?php if(isset($rowInfoArray1[$counterr]['rech_content']) && $rowInfoArray1[$counterr]['rech_content']!=''){ echo stripslashes($rowInfoArray1[$counterr]['rech_content']); }else{  } ?></textarea>
                                      <div id="error_rech_content_<?php echo $counterr; ?>" class="error_code"><span></span></div>
                      </td>
                      <td colspan="3"><button class="remove_field_feedback btn btn-danger" >Remove</button></td>
                    </tr>
                    
                        <?php $counterr++;   } ?>
                        
                        <?php   }
                        
                        }
                       ?>
                    
                    </tbody>  
                    </div>
                 
                </div>
              </TABLE>
                        </div>
                      </div>
                      <?php /* **************** End:: Franchisee Agents Feedback Full Details Section **************** */ ?>

                        <div class="row box-footer" style="margin: 0;">

          <div class="pull-right seo_update_btn">

  
           
          <button type="submit" class="btn btn-primary" id="ag_submit" name="ag_submit">Update</button>
       

            <button type="reset" class="btn btn-danger" id="reset">Reset </button> 

      

          </div>

      </div>
                      
                    </div>
                    


           </div>
         </form>

         <!-- div class="summary">
          <h1 class="panel-heading">Summary</h1>
           <div class="summary_inner col-md-12">
            
             <ul class="list_summary col-md-6">
               <li><span>Title : </span>It contain primary keyword and brand name, length under 100 chars.It is the very first HTML element that specifies your web page for search engines and to visitors. </li>
               <li><span>Meta Title : </span>It contain a sub title of your web page.</li>
               <li><span>Meta Description : </span>A Meta Description is an HTML element that summarizes your web page. Search engines typically show the Meta description in search results below your Title tag.</li>
               <li><span>Meta Keywords : </span>The meta keywords tag is where you put all of the keywords you use in your site. Eg:- content=”SEO, Hacker, Google, Search, etc”.It must include location / country, Place your main keywords in headlines, subheadings and anchor texts.</li>
               <li><span>Meta Robots : </span>The Robots Meta tag is an HTML tag that provides instructions to web crawlers on whether to index or noindex a web page.</li>
               <li><span>Meta Copyright : </span>Meta Copyright contain name of the owner. Eg:- content="name of owner" </li>
               <li><span>Og Site Name : </span>Open Graph Meta tags are designed to promote integration between Facebook, LinkedIn, Google and the website URLs that you shared on these platforms. Eg:- content=”SITE NAME” </li>
               <li><span>Og Title : </span>Eg:- content=”TITLE OF YOUR POST OR PAGE”</li>
               <li><span>Og Image : </span>Eg:- content=”LINK TO THE IMAGE FILE”</li>
             </ul>
             <ul class="list_summary col-md-6">
               <li><span>Og Description : </span>Eg:- content=”DESCRIPTION OF PAGE CONTENT”</li>
               <li><span>Og URL : </span>Eg:- content=”PERMALINK”</li>
               <li><span>Og Type : </span>Eg:- content=”article” </li>
               <li><span>Canonical : </span>By implementing the Canonical tag in the code, we are telling search engines that this URL is the main page and avoid indexing other duplicate page URLs.Eg: http://example.com/</li>
               <li><span>LOC : </span>URL of the page. This URL must begin with the protocol (such as http) and end with a trailing slash, if your web server requires it. This value must be less than 2,048 characters.</li>
               <li><span>Last Modified : </span>The date of last modification of the file.</li>
               <li><span>Change Frequently : </span>How frequently the page is likely to change.</li>
               <li><span>Priority : </span>The priority of this URL relative to other URLs on your site. Valid values range from 0.0 to 1.0.The default priority of a page is 0.5</li>
             </ul>
             
           </div>
         </div -->
         </div>
       </div>
     </div></section>
  </div>
  <!-- /.content-wrapper -->


 <!-- Begin:: Footer -->
<?php $this->load->view('include/footer'); ?>
<!--/. End:: Footer -->

  
  
</div>
<!-- ./wrapper -->
<?php $this->load->view('include/foot'); ?>
<script type="text/javascript" src="<?php echo base_url(); ?>ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>ckeditor/adapters/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>ckeditor/plugins/colorbutton/plugin.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>ckeditor/plugins/panelbutton/plugin.js"></script>

<script type="text/javascript">
   $(function(){
    $('#mychk').click(function() {
        if($(this).is(':checked')){
         var mychk_val= $('#mychk').val('true');
            $('.input_fields_wrap,#dataTable').hide();
        }
        else{
           var mychk_val= $('#mychk').val('false');
          $('.input_fields_wrap,#dataTable').show();
        }
            
    });
});

   $(function(){
    $('#agents_feedback_mychk').click(function() {
        if($(this).is(':checked')){
         var agents_feedback_mychk_val= $('#agents_feedback_mychk').val('true');
            $('.input_fields_wrap_feedback,#dataTable_feedback').hide();
        }else{
           var agents_feedback_mychk_val= $('#agents_feedback_mychk').val('false');
          $('.input_fields_wrap_feedback,#dataTable_feedback').show();
        }
            
    });
});

    
    $(document).ready(function() {
        var max_fields      = 5000; //maximum input boxes allowed
        var wrapper         = $("#dataTable >tbody"); //Fields wrapper
        var add_button      = $(".add_field_button"); //Add button ID     

          
        var x = $('#dataTable >tbody >tr').length; //initlal text box count
       // alert(x);
        var mychk_val= $('#mychk').val();
        if(mychk_val=='false'){
          $('.input_fields_wrap,#dataTable').show();
          
          
              $(add_button).click(function(e){ //on add input button click
                e.preventDefault();
                if(x < max_fields){ //max input box allowed
                     //text box increment
                    var chkId = 'chk_' +x;
                    var rech_htagId = 'rech_htag_' +x;
                    var rech_titleId = 'rech_title_' +x;
                    var rech_descId = 'rech_desc_' +x;
                    
                    var rech_htag='';
                    var rech_title='';
                    var rech_desc=''; 
                    

                    $(wrapper).append(' <tr><td><select class="form-control" id="'+rech_htagId+'"  name="rowInfo['+x+'][rech_htag]" ><option value="">Select H Tag</option><option value="h1">H1</option><option value="h2">H2</option><option value="h3">H3</option><option value="h4">H4</option><option value="h5">H5</option><option value="h6">H6</option></select><div id="error_rech_htag_'+x+'" class="error_code"><span></span></div><input type="text" class="form-control" id="'+rech_titleId+'"  name="rowInfo['+x+'][rech_title]" placeholder="Title"  value="'+rech_title+'"><div id="error_rech_title_'+x+'" class="error_code"><span></span></div></td><td><textarea class="ckeditor" id="'+rech_descId+'" name="rowInfo['+x+'][rech_desc]" placeholder="Description" rows="10" cols="80" value="'+rech_desc+'"></textarea><div id="error_rech_desc_'+x+'" class="error_code"><span></span></div></td><td><button class="remove_field btn btn-danger" >Remove</button></td></tr>');//add input box

                  
                   CKEDITOR.replace(rech_descId, { height:200 });
                   // var content = CKEDITOR.instances.rech_descId.getData();
                   // alert(content);
                    
                    x++;
                }
            });
            
            $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
                e.preventDefault(); var test = $(this).parents("tr").remove();x--;
            })

        }else{
          //alert(mychk_val);

            if(x < max_fields){ //max input box allowed
                     //text box increment
                    var chkId = 'chk_' +x;
                    var rech_titleId = 'rech_title_' +x;
                    var rech_descId = 'rech_desc_' +x;
                    $('#rech_title_'+x).val('');
                    $('#rech_desc_'+x).val('');
                    
                    x++;
                }
          $('.input_fields_wrap,#dataTable').hide();
        }
        
    });

    /* *************************** BEGIN:: AGENTS FEEDBACK ****************************/
    
        $(document).ready(function() {
        var max_fields      = 5000; //maximum input boxes allowed
        var wrapper         = $("#dataTable_feedback >tbody"); //Fields wrapper
        var add_button      = $(".add_field_button_feedback"); //Add button ID     

          
        var x = $('#dataTable_feedback >tbody >tr').length; //initlal text box count
       // alert(x);
        var mychk_val= $('#agents_feedback_mychk').val();
        if(mychk_val=='false'){
          $('.input_fields_wrap_feedback,#dataTable_feedback').show();
          
          
              $(add_button).click(function(e){ //on add input button click
                e.preventDefault();
                if(x < max_fields){ //max input box allowed
                     //text box increment
                    var chkId = 'chk_' +x;
                    var rech_nameId = 'rech_name_' +x;
                    var rech_profileId = 'rech_profile_' +x;
                    var rech_contentId = 'rech_content_' +x;
                    var rech_imagepathId = 'rech_imagepath_' +x;
                    var rech_extra1Id = 'rech_extra1_' +x;
                    var rech_extra2Id = 'rech_extra2_' +x;
                    
                    var rech_name='';
                    var rech_profile='';
                    var rech_content=''; 
                    var rech_imagepath='<?=base_url();?>dist/img/default.jpg';
                    var rech_extra1=''; 
                    var rech_extra2='';  
                    

                    $(wrapper).append(' <tr><td><input type="text" class="form-control" id="'+rech_nameId+'"  name="rowInfo_feedback['+x+'][rech_name]" placeholder="Name"  value="'+rech_name+'"><div id="error_rech_name_'+x+'" class="error_code"><span></span></div><input type="text" class="form-control" id="'+rech_profileId+'"  name="rowInfo_feedback['+x+'][rech_profile]" placeholder="Profile"  value="'+rech_profile+'"><div id="error_rech_profile_'+x+'" class="error_code"><span></span></div><input type="hidden" class="form-control" id="'+rech_imagepathId+'"  name="rowInfo_feedback['+x+'][rech_imagepath]" placeholder="Image Path"  value="'+rech_imagepath+'"><div id="error_rech_imagepath_'+x+'" class="error_code"><span></span></div><input type="text" class="form-control" id="'+rech_extra1Id+'"  name="rowInfo_feedback['+x+'][rech_extra1]" placeholder="Extra Field 1"  value="'+rech_extra1+'"><div id="error_rech_extra1_'+x+'" class="error_code"><span></span></div><input type="text" class="form-control" id="'+rech_extra2Id+'"  name="rowInfo_feedback['+x+'][rech_extra2]" placeholder="Extra Field 2"  value="'+rech_extra2+'"><div id="error_rech_extra2_'+x+'" class="error_code"><span></span></div></td><td><textarea class="ckeditor" id="'+rech_contentId+'" name="rowInfo_feedback['+x+'][rech_content]" placeholder="Content" rows="10" cols="80" value="'+rech_content+'"></textarea><div id="error_rech_content_'+x+'" class="error_code"><span></span></div></td><td><button class="remove_field_feedback btn btn-danger" >Remove</button></td></tr>');//add input box

                  
                   CKEDITOR.replace(rech_contentId, { height:200 });
                   
                    
                    x++;
                }
            });
            
            $(wrapper).on("click",".remove_field_feedback", function(e){ //user click on remove text
                e.preventDefault(); var test = $(this).parents("tr").remove();x--;
            })

        }else{
          //alert(mychk_val);

            if(x < max_fields){ //max input box allowed
                     //text box increment
                    var chkId = 'chk_' +x;
                    var rech_nameId = 'rech_name_' +x;
                    var rech_profileId = 'rech_profile_' +x;
                    var rech_contentId = 'rech_content_' +x;
                    var rech_imagepathId = 'rech_imagepath_' +x;
                    var rech_extra1Id = 'rech_extra1_' +x;
                    var rech_extra2Id = 'rech_extra2_' +x;

                    $('#rech_name_'+x).val('');
                    $('#rech_profile_'+x).val('');
                    $('#rech_content_'+x).val('');
                    $('#rech_imagepath_'+x).val('');
                    $('#rech_extra1_'+x).val('');
                    $('#rech_extra2_'+x).val('');

                    
                    x++;
                }
          $('.input_fields_wrap_feedback,#dataTable_feedback').hide();
        }
        
    });
    /* *************************** END:: AGENTS FEEDBACK ******************************/
</script>
<script>
  $("form#other_default_seoform").submit(function(e) {

    e.preventDefault();
    var formData = new FormData(this);
    var errorflag=0;
    //va nospecial=/^[^*|\":<>[\]{}`\\()';@&$]+$/;
    var nospecial = /['"]/gi;
     var meta_description_nospecial=/['"]/gi;
    var page_name=$('#page_name').val();
    var service_name=$('#service_name').val();
  var titlew=$('#titlew').val();
  var h1_tag=$('#h1_tag').val();
  var meta_title=$('#meta_title').val();
  var meta_description=$('#meta_description').val();
  var meta_description2=$('#meta_description2').val();
  var meta_description3=$('#meta_description3').val();
  var meta_keywords=$('#meta_keywords').val();
  var meta_robots=$('#meta_robots').val();
  var meta_copyright=$('#meta_copyright').val();
  var og_site_name=$('#og_site_name').val();
  var og_title=$('#og_title').val();
  var og_image=$('#og_image').val();
  var og_description=$('#og_description').val();
  var og_description2=$('#og_description2').val();
  var og_description3=$('#og_description3').val();
  var og_url=$('#og_url').val();
  var og_type=$('#og_type').val();
  var canonical=$('#canonical').val();
  var loc=$('#loc').val();
  var lastmod=$('#lastmod').val();
  var changefreq=$('#changefreq').val();
  var priority=$('#priority').val();
var anchor_rel=$('#anchor_rel').val();
var schema_data=$('#schema_data').val();

var x = $('#dataTable >tbody >tr').length;

var i=0;
var data='';
var rech_title='';
for(i=0; i<x;i++){
  
  var rech_descId = 'rech_desc_'+i;
  
  data = CKEDITOR.instances['rech_desc_'+i].getData();
  
  rech_htag=$('#rech_htag_'+i).val();
  if(rech_htag=='')
  {       
      $('#rech_htag_'+i).addClass(' inpt_error ');
      $('#error_rech_htag_'+i+ ' span').html('Please select H tag');
      errorflag=1;
    }
  else
  {
      $('#rech_htag_'+i).removeClass(' inpt_error ');
    $('#error_rech_htag_'+i+ ' span').html('');
    }
    
  rech_title=$('#rech_title_'+i).val(); 
  if(rech_title==''){
        
      $('#rech_title_'+i).addClass(' inpt_error ');
      $('#error_rech_title_'+i+ ' span').html('Please enter Title');
      errorflag=1;
    }else{
      $('#rech_title_'+i).removeClass(' inpt_error ');
    $('#error_rech_title_'+i+ ' span').html('');
    }

   if(data==''){
        
      $('#rech_desc_'+i).addClass(' inpt_error ');
      $('#error_rech_desc_'+i+ ' span').html('Please enter Description');
      errorflag=1;
    }else{
      $('#rech_desc_'+i).removeClass(' inpt_error ');
    $('#error_rech_desc_'+i+ ' span').html('');
    var field_name='rowInfo['+i+'][rech_desc]';
    //formData.append(field_name, data);
    formData.append(field_name, CKEDITOR.instances['rech_desc_'+i].getData());
    } 

}

/* BEGIN:: AGENTS FEEDBACK */
var y = $('#dataTable_feedback >tbody >tr').length;

var j=0;
var content='';
var rech_name='';
var rech_profile='';
for(j=0; j<y;j++){
  
  var rech_contentId = 'rech_content_'+j;
  
  content = CKEDITOR.instances['rech_content_'+j].getData();
  
  rech_name=$('#rech_name_'+j).val();
  if(rech_name=='')
  {       
      $('#rech_name_'+j).addClass(' inpt_error ');
      $('#error_rech_name_'+j+ ' span').html('Please enter Name');
      errorflag=1;
    }
  else
  {
    $('#rech_name_'+j).removeClass(' inpt_error ');
    $('#error_rech_name_'+j+ ' span').html('');
    }
    
  /* rech_profile=$('#rech_profile_'+i).val(); 
  if(rech_profile==''){
        
      $('#rech_profile_'+j).addClass(' inpt_error ');
      $('#error_rech_profile_'+j+ ' span').html('Please enter profile');
      errorflag=1;
    }else{
      $('#rech_profile_'+j).removeClass(' inpt_error ');
    $('#error_rech_profile_'+j+ ' span').html('');
    } */

   if(content==''){
        
      $('#rech_content_'+j).addClass(' inpt_error ');
      $('#error_rech_content_'+j+ ' span').html('Please enter Content');
      errorflag=1;
    }else{
      $('#rech_content_'+j).removeClass(' inpt_error ');
    $('#error_rech_content_'+j+ ' span').html('');
    var field_name='rowInfo_feedback['+j+'][rech_content]';
    //formData.append(field_name, data);
    formData.append(field_name, CKEDITOR.instances['rech_content_'+j].getData());
    } 

}
/* END:: AGENTS FEEDBACK */
    if(page_name==''){
        
      $("#page_name").addClass(' inpt_error ');
      $('#error_page_name span').html('Please select category');
      errorflag=1;
    }else{
      $("#page_name").removeClass(' inpt_error ');
    $('#error_page_name span').html('');
    }

    
    if(service_name=="")
      {
        $("#service_name").addClass('inpt_error');
        $('#error_service_name span').html('(Service Name is required)');       
        errorflag=1;
      }else if(service_name.length<2 || service_name.length>80)
      { 
        $("#service_name").addClass(' inpt_error ');             
        $('#error_service_name span').html('(Service Name should be of 2-80 characters)');          
        errorflag=1;
      }else if((nospecial.test(service_name))){          
        $("#service_name").addClass('inpt_error');          
        $('#error_service_name span').html('(Special character is not allowed in Service Name)');   
        errorflag=1;
        }else {
        $("#service_name").removeClass('inpt_error');
        $('#error_service_name span').html('');

      }


      if(titlew=="")
      {
        $("#titlew").addClass('inpt_error');
        $('#error_titlew span').html('(Title is required)');       
        errorflag=1;
      }else if(titlew.length<2 || titlew.length>100)
      { 
        $("#titlew").addClass(' inpt_error ');             
        $('#error_titlew span').html('(title should be of 2-100 characters)');          
        errorflag=1;
      }/*else if((nospecial.test(titlew))){          
        $("#titlew").addClass('inpt_error');          
        $('#error_titlew span').html('(Special character is not allowed in title)');   
        errorflag=1;
        }*/else {
        $("#titlew").removeClass('inpt_error');
        $('#error_titlew span').html('');

      }

      /* if(h1_tag=="")
      {
        $("#h1_tag").addClass('inpt_error');
        $('#error_h1_tag span').html('(H1 is required)');       
        errorflag=1;
      }else if(h1_tag.length<2 || h1_tag.length>70)
      { 
        $("#h1_tag").addClass(' inpt_error ');             
        $('#error_h1_tag span').html('(H1 should be of 2-70 characters)');          
        errorflag=1;
      }else if((nospecial.test(h1_tag))){          
        $("#h1_tag").addClass('inpt_error');          
        $('#error_h1_tag span').html('(Special character is not allowed in H1)');   
        errorflag=1;
        }else {
        $("#h1_tag").removeClass('inpt_error');
        $('#error_h1_tag span').html('');

      }

      if(meta_title=="")
      {
        $("#meta_title").addClass('inpt_error');
        $('#error_meta_title span').html('(Meta Title is required)');       
        errorflag=1;
      }else if(meta_title.length<2 || meta_title.length>100)
      { 
        $("#meta_title").addClass(' inpt_error ');             
        $('#error_meta_title span').html('(Meta Title should be of 2-100 characters)');          
        errorflag=1;
      }else if((nospecial.test(meta_title))){          
        $("#meta_title").addClass('inpt_error');          
        $('#error_meta_title span').html('(Special character is not allowed in Meta Title)');   
        errorflag=1;
        }else {
        $("#meta_title").removeClass('inpt_error');
        $('#error_meta_title span').html('');

      }

      if(meta_description=="")
      {
        $("#meta_description").addClass('inpt_error');
        $('#error_meta_description span').html('(Meta Description is required)');       
        errorflag=1;
      }else if(meta_description.length<2 || meta_description.length>320)
      { 
        $("#meta_description").addClass(' inpt_error ');             
        $('#error_meta_description span').html('(Meta Description should be of 2-320 characters)');          
        errorflag=1;
      }else if((nospecial.test(meta_description))){          
        $("#meta_description").addClass('inpt_error');          
        $('#error_meta_description span').html('(Quotation marks is not allowed in Meta Description)');   
        errorflag=1;
        }else {
        $("#meta_description").removeClass('inpt_error');
        $('#error_meta_description span').html('');

      }

        if(meta_description2!="")
      {
            if(meta_description2.length<2 || meta_description2.length>320)
          { 
            $("#meta_description2").addClass(' inpt_error ');             
            $('#error_meta_description2 span').html('(Meta Description should be of 2-320 characters)');          
            errorflag=1;
          }else if((nospecial.test(meta_description2))){          
            $("#meta_description2").addClass('inpt_error');          
            $('#error_meta_description2 span').html('(Quotation marks is not allowed in Meta Description)');   
            errorflag=1;
            }else {
            $("#meta_description2").removeClass('inpt_error');
            $('#error_meta_description2 span').html('');

          }
      } 

        if(meta_description3!="")
      {
            if(meta_description3.length<2 || meta_description3.length>320)
          { 
            $("#meta_description3").addClass(' inpt_error ');             
            $('#error_meta_description3 span').html('(Meta Description should be of 2-320 characters)');          
            errorflag=1;
          }else if((nospecial.test(meta_description3))){          
            $("#meta_description3").addClass('inpt_error');          
            $('#error_meta_description3 span').html('(Quotation marks is not allowed in Meta Description)');   
            errorflag=1;
            }else {
            $("#meta_description3").removeClass('inpt_error');
            $('#error_meta_description3 span').html('');

          }
      } 

      if(meta_keywords=="")
      {
        $("#meta_keywords").addClass('inpt_error');
        $('#error_meta_keywords span').html('(Meta keywords is required)');       
        errorflag=1;
      }else if(meta_keywords.length<2)
      { 
        $("#meta_keywords").addClass(' inpt_error ');             
        $('#error_meta_keywords span').html('(Meta keywords must be more than 2 characters)');          
        errorflag=1;
      }else if((nospecial.test(meta_keywords))){          
        $("#meta_keywords").addClass('inpt_error');          
        $('#error_meta_keywords span').html('(Some Special character is not allowed in Meta keywords)');   
        errorflag=1;
        }else {
        $("#meta_keywords").removeClass('inpt_error');
        $('#error_meta_keywords span').html('');

      }

      if(meta_robots!="")
      {
        
      if(meta_robots.length<2 || meta_robots.length>80)
      { 
        $("#meta_robots").addClass(' inpt_error ');             
        $('#error_meta_robots span').html('(Meta Robots should be of 2-80 characters)');          
        errorflag=1;
      }else if((nospecial.test(meta_robots))){          
        $("#meta_robots").addClass('inpt_error');          
        $('#error_meta_robots span').html('(Special character is not allowed in Meta Robots)');   
        errorflag=1;
        }else {
        $("#meta_robots").removeClass('inpt_error');
        $('#error_meta_robots span').html('');
    }
    }

      if(meta_copyright!="")
      {
        if(meta_copyright.length<2 || meta_copyright.length>80)
        { 
          $("#meta_copyright").addClass(' inpt_error ');             
          $('#error_meta_copyright span').html('(Meta Copyright should be of 2-80 characters)');          
          errorflag=1;
        }else if((nospecial.test(meta_copyright))){          
          $("#meta_copyright").addClass('inpt_error');          
          $('#error_meta_copyright span').html('(Special character is not allowed in Meta Copyright)');   
          errorflag=1;
          }else {
          $("#meta_copyright").removeClass('inpt_error');
          $('#error_meta_copyright span').html('');
        }
      }

      if(og_site_name!="")
      {
        if(og_site_name.length<2 || og_site_name.length>80)
        { 
          $("#og_site_name").addClass(' inpt_error ');             
          $('#error_og_site_name span').html('(Og Site Name should be of 2-80 characters)');          
          errorflag=1;
        }else if((nospecial.test(og_site_name))){          
          $("#og_site_name").addClass('inpt_error');          
          $('#error_og_site_name span').html('(Special character is not allowed in Og Site Name)');   
          errorflag=1;
          }else {
          $("#og_site_name").removeClass('inpt_error');
          $('#error_og_site_name span').html('');
      }
    }

      if(og_title!="")
      {
        if(og_title.length<2 || og_title.length>100)
        { 
          $("#og_title").addClass(' inpt_error ');             
          $('#error_og_title span').html('(Og Title should be of 2-100 characters)');          
          errorflag=1;
        }else if((nospecial.test(og_title))){          
          $("#og_title").addClass('inpt_error');          
          $('#error_og_title span').html('(Special character is not allowed in Og Title)');   
          errorflag=1;
          }else {
          $("#og_title").removeClass('inpt_error');
          $('#error_og_title span').html('');
      }
    }

      // if(og_image!="")
      // {
      //   $("#og_image").addClass('inpt_error');
      //   $('#error_og_image span').html('(Og Image is required)');       
      //   errorflag=1;
      // }else {
      //   $("#og_image").removeClass('inpt_error');
      //   $('#error_og_image span').html('');

      // }

      if(og_description!="")
      {
        if(og_description.length<2 || og_description.length>320)
        { 
          $("#og_description").addClass(' inpt_error ');             
          $('#error_og_description span').html('(Og Description should be of 2-320 characters)');          
          errorflag=1;
        }else if((nospecial.test(og_description))){          
          $("#og_description").addClass('inpt_error');          
          $('#error_og_description span').html('(Special character is not allowed in Og Description)');   
          errorflag=1;
          }else {
          $("#og_description").removeClass('inpt_error');
          $('#error_og_description span').html('');
      }
    }

     if(og_description2!="")
      {
        if(og_description2.length<2 || og_description2.length>320)
        { 
          $("#og_description2").addClass(' inpt_error ');             
          $('#error_og_description2 span').html('(Og Description should be of 2-320 characters)');          
          errorflag=1;
        }else if((nospecial.test(og_description2))){          
          $("#og_description2").addClass('inpt_error');          
          $('#error_og_description2 span').html('(Special character is not allowed in Og Description)');   
          errorflag=1;
          }else {
          $("#og_description2").removeClass('inpt_error');
          $('#error_og_description2 span').html('');
      }
    }

     if(og_description3!="")
      {
        if(og_description3.length<2 || og_description3.length>320)
        { 
          $("#og_description3").addClass(' inpt_error ');             
          $('#error_og_description3 span').html('(Og Description should be of 2-320 characters)');          
          errorflag=1;
        }else if((nospecial.test(og_description3))){          
          $("#og_description3").addClass('inpt_error');          
          $('#error_og_description3 span').html('(Special character is not allowed in Og Description)');   
          errorflag=1;
          }else {
          $("#og_description3").removeClass('inpt_error');
          $('#error_og_description3 span').html('');
      }
    }
      // if(og_url=="")
      // {
      //   $("#og_url").addClass('inpt_error');
      //   $('#error_og_url span').html('(Og URL is required)');       
      //   errorflag=1;
      // }else {
      //   $("#og_url").removeClass('inpt_error');
      //   $('#error_og_url span').html('');

      // }

      if(og_type!="")
      {
        if(og_type.length<2 || og_type.length>80)
        { 
          $("#og_type").addClass(' inpt_error ');             
          $('#error_og_type span').html('(Og Type should be of 2-80 characters)');          
          errorflag=1;
        }else if((nospecial.test(og_type))){          
          $("#og_type").addClass('inpt_error');          
          $('#error_og_type span').html('(Special character is not allowed in Og Type)');   
          errorflag=1;
          }else {
          $("#og_type").removeClass('inpt_error');
          $('#error_og_type span').html('');
      }
    }

      // if(canonical=="")
      // {
      //   $("#canonical").addClass('inpt_error');
      //   $('#error_canonical span').html('(Canonical is required)');       
      //   errorflag=1;
      // }else {
      //   $("#canonical").removeClass('inpt_error');
      //   $('#error_canonical span').html('');

      // }

      // if(loc=="")
      // {
      //   $("#loc").addClass('inpt_error');
      //   $('#error_loc span').html('(LOC is required)');       
      //   errorflag=1;
      // }else {
      //   $("#loc").removeClass('inpt_error');
      //   $('#error_loc span').html('');

      // }

      var arr1 = lastmod.split('-');
    var nwDateGet=arr1[2]+'-'+arr1[1]+'-'+arr1[0];
    var nwDateGet = new Date(nwDateGet);
    var today = new Date();
    
      
    if(lastmod!="")
    { 
       if (nwDateGet =="Invalid Date" ) { 
        $("#lastmod").addClass('inpt_error');         
              $('#error_lastmod span').html('(Enter a valid date)');
              errorflag=1;
      }else if ( nwDateGet > today ) { 
        $("#lastmod").addClass('inpt_error');
              $('#error_lastmod span').html('(You cannot enter a date in the future!)');
              errorflag=1;
      }else {
        $("#lastmod").removeClass('inpt_error');
        $('#error_lastmod span').html('');
      }
    } 

  

      // if(changefreq=="")
      // {
      //   $("#changefreq").addClass('inpt_error');
      //   $('#error_changefreq span').html('(Change Frequently is required)');       
      //   errorflag=1;
      // }else {
      //   $("#changefreq").removeClass('inpt_error');
      //   $('#error_changefreq span').html('');

      // }

      if(priority!="")
      {
          if(priority.length<1 || priority.length>5)
        { 
          $("#priority").addClass(' inpt_error ');             
          $('#error_priority span').html('(Priority should be of 2-5 characters)');          
          errorflag=1;
        }else if((nospecial.test(priority))){          
          $("#priority").addClass('inpt_error');          
          $('#error_priority span').html('(Special character is not allowed in Priority)');   
          errorflag=1;
          }else {
          $("#priority").removeClass('inpt_error');
          $('#error_priority span').html('');
      }
    }

    
      if(priority!="")
      {
          if(priority.length<2 || priority.length>50)
        { 
          $("#priority").addClass(' inpt_error ');             
          $('#error_priority span').html('(Priority should be of 2-50 characters)');          
          errorflag=1;
        }else if((nospecial.test(priority))){          
          $("#priority").addClass('inpt_error');          
          $('#error_priority span').html('(Special character is not allowed in Priority)');   
          errorflag=1;
          }else {
          $("#priority").removeClass('inpt_error');
          $('#error_priority span').html('');
      }
    }

     if(schema_data=="")
      {
        $("#schema_data").addClass('inpt_error');
        $('#error_schema_data span').html('(schema Data is required)');       
        errorflag=1;
      }else if(schema_data.length<2)
      { 
        $("#schema_data").addClass(' inpt_error ');             
        $('#error_schema_data span').html('(schema Data must be more than 2 characters)');          
        errorflag=1;
      }else {
        $("#schema_data").removeClass('inpt_error');
        $('#error_schema_data span').html('');
      }
    */

    if(errorflag==0)
  {
    $('.loader_upload_overlay').show();
     $.ajax({        

          url:Base_URL+"franchisee/seo_update",

          type: 'POST',

          data: formData,

          //timeout: 60000, //Set your timeout value in milliseconds or 0 for unlimited

          cache: false,

          contentType: false,

          processData: false,

          success: function (data) {

            $('.loader_upload_overlay').hide();
            //console.log(data);
            data=data.trim();
            var obj = JSON.parse(data);
            

            if(obj.status==200)
            {
              $('.alert-success.seo_div span.success_txt').addClass('noerror');
              $('.alert-success.seo_div span.success_txt').removeClass('error');
              $('.alert-success.seo_div span.success_txt').html(obj.message);
              
              $('.alert-success.seo_div').show();
              $("html, body").animate({ scrollTop: 0 }, "slow");

            }else if(data==400){
              $('.alert-success.seo_div span.success_txt').addClass('error');
              $('.alert-success.seo_div span.success_txt').removeClass('noerror');
              $('.alert-success.seo_div span.success_txt').html(obj.message);

              $('.alert-success.seo_div').show();
              $("html, body").animate({ scrollTop: 0 }, "slow");
              // $('.alert-success.success_div').hide();
              // $('.alert-success.success_div span').html('');
              // $('.alert-success.agent_div').hide();
              

            }

          }

        }); 

      }

});

function resetSEOForm()
{
    
    var titlew=$('#titlew').val('');
    var h1_tag=$('#h1_tag').val('');
  var meta_title=$('#meta_title').val('');
  var meta_description=$('#meta_description').val('');
  var meta_description2=$('#meta_description2').val('');
  var meta_description3=$('#meta_description3').val('');
  var meta_keywords=$('#meta_keywords').val('');
  var meta_robots=$('#meta_robots').val('');
  var meta_copyright=$('#meta_copyright').val('');
  var og_site_name=$('#og_site_name').val('');
  var og_title=$('#og_title').val('');
  var og_image=$('#og_image').val('');
  var og_description=$('#og_description').val('');
  var og_description2=$('#og_description2').val('');
  var og_description3=$('#og_description3').val('');
  var og_url=$('#og_url').val('');
  var og_type=$('#og_type').val('');
  var canonical=$('#canonical').val('');
  var loc=$('#loc').val('');
  var lastmod=$('#lastmod').val('');
  var changefreq=$('#changefreq').val('');
  var priority=$('#priority').val('');
  var schema_data=$("#schema_data").val('');
}

$( document ).ready(function() {
  $( "#reset" ).on('click',function() {
    // alert('hii');
      resetSEOForm();

    });

    $("#lastmod").keyup(function(){
                if ($(this).val().length == 2){
                    $(this).val($(this).val() + "-");
                }else if ($(this).val().length == 5){
                    $(this).val($(this).val() + "-");
                }else if($(this).val().length > 10){
                  var pprt=$(this).val().substr(0, 10);
                  $(this).val(pprt);
                }
            });

    $('#page_name').on('change', function() {
 
   window.location.href=Base_URL+'franchisee/franchiseedefault/'+this.value+'/'+$('#service_name').val();
     
});
});
</script>
</body>
</html>