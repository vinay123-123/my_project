<?php
if($this->session->userdata('SEO_ADMIN_LOGGEDIN')!=1){
    header('Location:' .BASEURL.ADMIN_BASE_URL."login"); 
}
date_default_timezone_set(DEFAULT_TIME_ZONE);
$current_segment='';
$current_segment=$this->uri->segment(3);
$rgtoption=$this->uri->segment(2);
if(isset($SeoDetails['page_name']) && $SeoDetails['page_name']!="") { $page_name=$SeoDetails['page_name']; } else { $page_name=''; }
if(isset($SeoDetails['service_name']) && $SeoDetails['service_name']!="") { $service_name=$SeoDetails['service_name']; } else { $service_name=''; }
if(isset($SeoDetails['title']) && $SeoDetails['title']!="") { $titlew=$SeoDetails['title']; } else { $titlew=''; }
if(isset($SeoDetails['h1_tag']) && $SeoDetails['h1_tag']!="") { $h1_tag=$SeoDetails['h1_tag']; } else { $h1_tag=''; }
if(isset($SeoDetails['meta_title']) && $SeoDetails['meta_title']!="") { $meta_title=$SeoDetails['meta_title']; } else { $meta_title=''; }
if(isset($SeoDetails['meta_description']) && $SeoDetails['meta_description']!="") { $meta_description=$SeoDetails['meta_description']; } else { $meta_description=''; }
if(isset($SeoDetails['meta_keywords']) && $SeoDetails['meta_keywords']!="") { $meta_keywords=$SeoDetails['meta_keywords']; } else { $meta_keywords=''; }
if(isset($SeoDetails['meta_robots']) && $SeoDetails['meta_robots']!="") { $meta_robots=$SeoDetails['meta_robots']; } else { $meta_robots=''; }
if(isset($SeoDetails['meta_copyright']) && $SeoDetails['meta_copyright']!="") { $meta_copyright=$SeoDetails['meta_copyright']; } else { $meta_copyright=''; }
if(isset($SeoDetails['og_site_name']) && $SeoDetails['og_site_name']!="") { $og_site_name=$SeoDetails['og_site_name']; } else { $og_site_name=''; }
if(isset($SeoDetails['og_title']) && $SeoDetails['og_title']!="") { $og_title=$SeoDetails['og_title']; } else { $og_title=''; }
if(isset($SeoDetails['og_image']) && $SeoDetails['og_image']!="") { $og_image=$SeoDetails['og_image']; } else { $og_image=''; }
if(isset($SeoDetails['og_description']) && $SeoDetails['og_description']!="") { $og_description=$SeoDetails['og_description']; } else { $og_description=''; }
if(isset($SeoDetails['og_url']) && $SeoDetails['og_url']!="") { $og_url=$SeoDetails['og_url']; } else { $og_url=''; }
if(isset($SeoDetails['og_type']) && $SeoDetails['og_type']!="") { $og_type=$SeoDetails['og_type']; } else { $og_type=''; }
if(isset($SeoDetails['canonical']) && $SeoDetails['canonical']!="") { $canonical=$SeoDetails['canonical']; } else { $canonical=''; }
if(isset($SeoDetails['loc']) && $SeoDetails['loc']!="") { $loc=$SeoDetails['loc']; } else { $loc=''; }
if(isset($SeoDetails['lastmod']) && $SeoDetails['lastmod']!="") { $lastmod=$SeoDetails['lastmod']; } else { $lastmod=''; }
if(isset($SeoDetails['changefreq']) && $SeoDetails['changefreq']!="") { $changefreq=$SeoDetails['changefreq']; } else { $changefreq=''; }
if(isset($SeoDetails['priority']) && $SeoDetails['priority']!="") { $priority=$SeoDetails['priority']; } else { $priority=''; }
if(isset($SeoDetails['anchor_rel']) && $SeoDetails['anchor_rel']!="") { $anchor_rel=$SeoDetails['anchor_rel']; } else { $anchor_rel=''; }
if(isset($SeoDetails['rowInfo']) && $SeoDetails['rowInfo']!="") { $rowInfo=$SeoDetails['rowInfo']; } else { $rowInfo=''; }
if(isset($SeoDetails['mychk_field']) && $SeoDetails['mychk_field']!="") { $mychk_field=$SeoDetails['mychk_field']; } else { $mychk_field=''; }
if(isset($SeoDetails['extra_fields']) && $SeoDetails['extra_fields']!="") { $extra_fields=$SeoDetails['extra_fields']; } else { $extra_fields=''; }
if(isset($SeoDetails['schema_data']) && $SeoDetails['schema_data']!="") { $schema_data=$SeoDetails['schema_data']; } else { $schema_data=''; }

$CI=&get_instance();
$CI->load->model('Mysqlcontroller');
$getAllOperators=$CI->Mysqlcontroller->getAllOperators();

$operator_array_key=array();
$operator_array_value=array();
foreach($getAllOperators as $operators)
{
  $op_service_name=strtolower($CI->Mysqlcontroller->clean($operators->service_name)); 
  $operator_array_key[$operators->operator_code]=$op_service_name;
  $operator_array_value[$op_service_name]=$operators->operator_code;
}

if(isset($page_name) && $page_name!="") { } else {
	if(isset($searched_page_name) && $searched_page_name!="") 
		{ 
	        $page_name=$searched_page_name; 
	        $_temp_arr=explode('-', $page_name);
			if(isset($_temp_arr[0]) && !empty($_temp_arr[0])){ $_service_type=$_temp_arr[0]; } else { $_service_type=$_temp_arr[0];  }
			if(isset($_temp_arr[1]) && !empty($_temp_arr[1])){ $_op_code=$_temp_arr[1]; } else { $_op_code=$_temp_arr[1];  }
			if(isset($_service_type) && $_service_type!="electricity_circle")
			{
				$page_name=$_service_type."_".$_op_code;
			}
		} 
	}
?>
<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
  <?php $this->load->view('include/head'); ?>
  <style type="text/css">
    .recharge_full_detail_parent{clear: both;}
  </style>
  <link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>dist/css/admin-head/editor.css">

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="loader_upload_overlay" id="loader_upload_overlay" style="display:none;">
    <div class="loader_upload_handle">
        <div class="loader_upload_preload">
            <img src="<?php=base_url();?>dist/img/loader.gif" alt="Please wait" title="Please wait"/>
        </div>
        <div class="upload_waiting_txt">Please wait. Kindly donot press refresh or back button</div>
    </div>
</div>
<div class="wrapper">

  <?php $this->load->view('include/header'); ?>
  
  <!-- Left side column. contains the logo and sidebar -->
 <?php $this->load->view('include/left_sidebar'); ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <section class="content-header">
      <div class="row">
       <div class="col-xs-20 col-md-12 col-xs-12">
        <div class="top-heading">
         <h1><?php if(isset($page_name) && $page_name!=""){echo strtoupper($page_name);}else{ echo strtoupper("Recharge Form"); } ?></h1>
          <ol class="breadcrumb">
                        <li><a href="#"><i class="fa fa-dashboard"></i><?php if(isset($service_name) && !empty($service_name)){echo ucwords($service_name);}else{echo "Recharge";}?></a></li>
                        <li><a href="#"><?php if(isset($page_name) && !empty($page_name)){echo ucwords($page_name);}else{ echo "Recharge Form"; } ?></a></li>
                        
                    </ol>
       </div>

        <div class="alert alert-success seo_div alert-dismissable" style="display: none;">
            
                <i class="fa fa-check"></i>

                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
           
                
                <span class="success_txt"></span>

        </div>
       <!--#################################### SEO Form Start ####################################-->
       <div class="panel panel-default">
         <div class="new-body panel-body">
          <div class="panel-heading"><?php if(isset($service_name) && !empty($service_name)){echo ucwords($service_name);}else{echo "Recharge";}?> - <?php if(isset($page_name) && !empty($page_name)){echo ucwords($page_name);} ?> SEO Form</div>
                 <div class="seo_parent">
                  <form class="form-horizontal" name="recharge_default_seoform" id="recharge_default_seoform" action="" method="POST">
                   <div class="seo_inner">
                    <div id="seoform_section">
                     <div class="row">
                      <div class="col-md-12 page_section">
                       <div class="row my_row">
                           <div class="col-md-3 col-sm-12">
                            
                          </div>
                          <div class="col-md-2 col-sm-12">
                            <label>
                              Select Page
                            </label>
                          </div>
                          
                          <?php if(isset($mobile_prepaid_default) && !empty($mobile_prepaid_default)){ ?>
                            <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value=''>---- Select Page ----</option>
                              <option value="mobile_prepaid-default" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='mobile_prepaid_default'){ echo 'selected';}}else{if(strtolower($current_segment)=='mobile_prepaid-default'){ echo 'selected';}}?>>Mobile Prepaid default</option>
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>
                         <?php }else if(isset($mobile_postpaid_default) && !empty($mobile_postpaid_default)){ ?>
                           <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value>---- Select Page ----</option>
                              <option value="mobile_postpaid-default" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='mobile_postpaid_default'){ echo 'selected';}}else{if(strtolower($current_segment)=='mobile_postpaid-default'){ echo 'selected';}}?>>Mobile Postpaid default</option>
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>
                        <?php }else if(isset($dth_default) && !empty($dth_default)){ ?>
                           <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value>---- Select Page ----</option>
                              <option value="dth-default" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='dth_default'){ echo 'selected';}}else{if(strtolower($current_segment)=='dth-default'){ echo 'selected';}}?>>DTH default</option>
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>
                          <?php }else if(isset($datacard_prepaid_default) && !empty($datacard_prepaid_default)){ ?>
                           <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value>---- Select Page ----</option>
                              <option value="datacard_prepaid-default" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='datacard_prepaid_default'){ echo 'selected';}}else{if(strtolower($current_segment)=='datacard_prepaid-default'){ echo 'selected';}}?>>Datacard Prepaid default</option>
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>
                          <?php }else if(isset($datacard_postpaid_default) && !empty($datacard_postpaid_default)){ ?>
                           <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value>---- Select Page ----</option>
                              <option value="datacard_postpaid-default" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='datacard_postpaid_default'){ echo 'selected';}}else{if(strtolower($current_segment)=='datacard_postpaid-default'){ echo 'selected';}}?>>Datacard Postpaid default</option>
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>
                          <?php }else if(isset($landline_default) && !empty($landline_default)){ ?>
                           <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value>---- Select Page ----</option>
                              <option value="landline-default" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='landline_default'){ echo 'selected';}}else{if(strtolower($current_segment)=='landline-default'){ echo 'selected';}}?>>Landline default</option>
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>
                          <?php }else if(isset($broadband_default) && !empty($broadband_default)){ ?>
                           <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value>---- Select Page ----</option>
                              <option value="broadband-default" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='broadband_default'){ echo 'selected';}}else{if(strtolower($current_segment)=='broadband-default'){ echo 'selected';}}?>>Broadband default</option>
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>
                          <?php }else if(isset($insurance_default) && !empty($insurance_default)){ ?>
                           <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value>---- Select Page ----</option>
                              <option value="insurance-default" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='insurance_default'){ echo 'selected';}}else{if(strtolower($current_segment)=='insurance-default'){ echo 'selected';}}?>>Insurance default</option>
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>
                          <?php }else if(isset($electricity_default) && !empty($electricity_default)){ ?>
                           <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value>---- Select Page ----</option>
                              <option value="electricity-default" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='electricity_default'){ echo 'selected';}}else{if(strtolower($current_segment)=='electricity-default'){ echo 'selected';}}?>>Electricity Default</option>
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>
                          <?php }else if(isset($water_default) && !empty($water_default)){ ?>
                           <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value>---- Select Page ----</option>
                              <option value="water-default" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='water_default'){ echo 'selected';}}else{if(strtolower($current_segment)=='water-default'){ echo 'selected';}}?>>Water Default</option>
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>
                          <?php }else if(isset($gas_default) && !empty($gas_default)){ ?>
                           <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value>---- Select Page ----</option>
                              <option value="gas-default" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='gas_default'){ echo 'selected';}}else{if(strtolower($current_segment)=='gas-default'){ echo 'selected';}}?>>gas Default</option>
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>

                          <?php }else if(isset($fastag_default) && !empty($fastag_default)){ ?>
                           <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value>---- Select Page ----</option>
                              <option value="fastag-default" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='fastag_default'){ echo 'selected';}}else{if(strtolower($current_segment)=='fastag-default'){ echo 'selected';}}?>>Fastag Default</option>
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>

                          <?php }else if(isset($credit_card_default) && !empty($credit_card_default)){ ?>
                           <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value>---- Select Page ----</option>
                              <option value="credit_card-default" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='credit_card_default'){ echo 'selected';}}else{if(strtolower($current_segment)=='credit_card-default'){ echo 'selected';}}?>>Credit Card Default</option>
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>

                          <?php }else if(isset($hospital_default) && !empty($hospital_default)){ ?>
                           <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value>---- Select Page ----</option>
                              <option value="hospital-default" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='hospital_default'){ echo 'selected';}}else{if(strtolower($current_segment)=='hospital-default'){ echo 'selected';}}?>>Hospital Default</option>
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>

                          <?php }else if(isset($lpg_gas_default) && !empty($lpg_gas_default)){ ?>
                           <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value>---- Select Page ----</option>
                              <option value="lpg_gas-default" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='lpg_gas_default'){ echo 'selected';}}else{if(strtolower($current_segment)=='lpg_gas-default'){ echo 'selected';}}?>>LPG Gas Default</option>
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>

                          <?php }else if(isset($loan_default) && !empty($loan_default)){ ?>
                           <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value>---- Select Page ----</option>
                              <option value="loan-default" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='loan_default'){ echo 'selected';}}else{if(strtolower($current_segment)=='loan-default'){ echo 'selected';}}?>>Loan Default</option>
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>

                          <?php }else if(isset($housing_society_default) && !empty($housing_society_default)){ ?>
                           <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value>---- Select Page ----</option>
                              <option value="housing_society-default" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='housing_society_default'){ echo 'selected';}}else{if(strtolower($current_segment)=='housing_society-default'){ echo 'selected';}}?>>Housing Society Default</option>
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>

                          <?php }else if(isset($subscription_default) && !empty($subscription_default)){ ?>
                           <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value>---- Select Page ----</option>
                              <option value="subscription-default" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='subscription_default'){ echo 'selected';}}else{if(strtolower($current_segment)=='subscription-default'){ echo 'selected';}}?>>Subscription Default</option>
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>

                          <?php }else if(isset($cable_default) && !empty($cable_default)){ ?>
                           <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value>---- Select Page ----</option>
                              <option value="cable-default" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='cable_default'){ echo 'selected';}}else{if(strtolower($current_segment)=='cable-default'){ echo 'selected';}}?>>Cable Default</option>
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>

                          <?php }else if(isset($entertainment_default) && !empty($entertainment_default)){ ?>
                           <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value>---- Select Page ----</option>
                              <option value="entertainment-default" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='entertainment_default'){ echo 'selected';}}else{if(strtolower($current_segment)=='entertainment-default'){ echo 'selected';}}?>>Entertainment Default</option>
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>

                          <?php }else if(isset($travel_sub_default) && !empty($travel_sub_default)){ ?>
                           <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value>---- Select Page ----</option>
                              <option value="travel_sub-default" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='travel_sub_default'){ echo 'selected';}}else{if(strtolower($current_segment)=='travel_sub-default'){ echo 'selected';}}?>>Travel Sub Default</option>
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>

                          <?php }else if(isset($municipal_taxes_default) && !empty($municipal_taxes_default)){ ?>
                           <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value>---- Select Page ----</option>
                              <option value="municipal_taxes-default" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='municipal_taxes_default'){ echo 'selected';}}else{if(strtolower($current_segment)=='municipal_taxes-default'){ echo 'selected';}}?>>Municipal Taxes Default</option>
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>

                          <?php }else if(isset($municipal_services_default) && !empty($municipal_services_default)){ ?>
                           <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value>---- Select Page ----</option>
                              <option value="municipal_services-default" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='municipal_services_default'){ echo 'selected';}}else{if(strtolower($current_segment)=='municipal_services-default'){ echo 'selected';}}?>>Municipal Services Default</option>
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>

                        <?php }else if(isset($education_default) && !empty($education_default)){ ?>
                           <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value>---- Select Page ----</option>
                              <option value="education-default" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='education_default'){ echo 'selected';}}else{if(strtolower($current_segment)=='education-default'){ echo 'selected';}}?>>Education Default</option>
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>
                        
                        <?php }else if(isset($electricity_circle_list) && !empty($electricity_circle_list)){ ?> 
						   <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value>---- Select Page ----</option>
                              <?php foreach ($electricity_circle_list as $key => $value) 
							  {
                                $circle_name=$value['state'];
                                $circle_code=$value['code'];                                
                               ?>
                               <option value="<?php='electricity_circle-'.$circle_code; ?>" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)==strtolower('electricity_circle-'.$circle_code)){ echo 'selected';}}else{if(strtolower($current_segment)==strtolower('electricity_circle-'.$circle_code)){ echo 'selected';}} ?> ><?php="Electricity Board -> ".$circle_name; ?></option>
                              <?php } ?>
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>
						  
                        <?php }else if(isset($recharge_list) && !empty($recharge_list)){ ?>
                            <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value>---- Select Page ----</option>
                              <?php foreach ($recharge_list as $key => $value) {
                                $service_type=strtolower($value['service_type']);
                                $operator_code=$value['operator_code'];
                                $service_name=$value['service_name'];
                                $state_code_name=str_replace('-', ' ', $value['state_code_name']);
                                $state_code_name=ucwords(str_replace('_', ' ', $state_code_name));                                
                               ?>
                               <option value="<?php=$service_type.'-'.$operator_code; ?>" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)==strtolower($service_type.'_'.$operator_code)){ echo 'selected';}}else{if(strtolower($current_segment)==strtolower($service_type.'_'.$operator_code)){ echo 'selected';}} ?> ><?php=ucwords(str_replace('_', ' ', $value['service_type']))." -> ".$service_name; if(isset($state_code_name) && $state_code_name!="") { echo " -> ".$state_code_name;} ?></option>
                              <?php } ?>
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>
                         <?php }else{ ?>
                          <div class="col-md-4 col-sm-12">
                            <h3>No Operator Found !</h3>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>
                        <?php } ?>

                          <div class="col-md-3 col-sm-12">
                            
                          </div>
                      </div>
                    </div> 
                   

                 </div>
                 <table class="markup table table-bordered width-50 myTable">
                <tbody>
                 <tr>
                  <td>Service Name</td>
                  <td>
                    
                   <input type="text" class="form-control" id="service_name" name="service_name"  value="recharge"  readonly="">
                   <div id="error_service_name" class="error_code"><span></span></div>
                 </td>
                  </tr>
                  <tr>
                    <td>Title</td>
                     <td>
                      <textarea rows="4" cols="50" class="form-control" id="titlew" name="titlew"><?php if(isset($titlew) && !empty($titlew)) {  echo $SeoDetails['title'];  } else{ echo ""; } ?></textarea>
                   <div id="error_titlew" class="error_code"><span></span></div>
                 </td>
                    </tr>
        <tr>
                    <td>H1 Tag</td>
                     <td>
              <input type="text" class="form-control" id="h1_tag" name="h1_tag"  value="<?php if(isset($h1_tag) && !empty($h1_tag)) {  echo $SeoDetails['h1_tag'];  } else{ echo ""; } ?>" >
              <div id="error_h1_tag" class="error_code"><span></span></div>
           </td>
                </tr> 
                    <tr>
                      <td>Meta Title</td>
                      <td>
                        <textarea rows="4" cols="50" class="form-control" id="meta_title" name="meta_title"><?php if(isset($meta_title) && !empty($meta_title)) {  echo $SeoDetails['meta_title'];  } else{ echo ""; } ?></textarea>
                   
                   <div id="error_meta_title" class="error_code"><span></span></div>
                 </td>
                      </tr>
                      <tr>
                        <td>Meta Description</td>
                         <td>
                          <textarea rows="4" cols="50" class="form-control" id="meta_description" name="meta_description"><?php if(isset($meta_description) && !empty($meta_description)) {  echo $SeoDetails['meta_description'];  } else{ echo ""; } ?> </textarea>
                  
                   <div id="error_meta_description" class="error_code"><span></span></div>
                 </td>
                        </tr>

                         <tr>
                        <td>Meta Keywords</td>
                         <td>
                          <textarea rows="4" cols="50" class="form-control" id="meta_keywords" name="meta_keywords"><?php if(isset($meta_keywords) && !empty($meta_keywords)) {  echo $SeoDetails['meta_keywords'];  } else{ echo ""; } ?></textarea>
                   
                   <div id="error_meta_keywords" class="error_code"><span></span></div>
                 </td>
                        </tr>

                         <tr>
                        <td>Meta Robots</td>
                         <td>
                   <input type="text" class="form-control" id="meta_robots" name="meta_robots" <?php if(isset($meta_robots) && !empty($meta_robots)) {  ?> value="<?php=$SeoDetails['meta_robots'];?>" <?php } else{ ?> value="" <?php } ?>>
                   <div id="error_meta_robots" class="error_code"><span></span></div>
                 </td>
                        </tr>

                         <tr>
                        <td>Meta Copyright</td>
                         <td>
                   <input type="text" class="form-control" id="meta_copyright" name="meta_copyright" <?php if(isset($meta_copyright) && !empty($meta_copyright)) {  ?> value="<?php=$SeoDetails['meta_copyright'];?>" <?php } else{ ?> value="" <?php } ?>>
                   <div id="error_meta_copyright" class="error_code"><span></span></div>
                 </td>
                        </tr>

                         <tr>
                        <td>Og Site Name</td>
                         <td>
                   <input type="text" class="form-control" id="og_site_name" name="og_site_name" <?php if(isset($og_site_name) && !empty($og_site_name)) {  ?> value="<?php=$SeoDetails['og_site_name'];?>" <?php } else{ ?> value="" <?php } ?>>
                   <div id="error_og_site_name" class="error_code"><span></span></div>
                 </td>
                        </tr>

                         <tr>
                        <td>Og Title</td>
                         <td>
                          <textarea rows="4" cols="50" class="form-control" id="og_title" name="og_title"><?php if(isset($og_title) && !empty($og_title)) {  echo $SeoDetails['og_title'];  } else{ echo ""; } ?></textarea>
                   
                   <div id="error_og_title" class="error_code"><span></span></div>
                 </td>
                        </tr>

                          <tr>
                        <td>Additional Fields</td>
                         <td>
           <textarea rows="4" cols="50" class="form-control" name="extra_fields" id="extra_fields"><?php  if(isset($SeoDetails['extra_fields']) && $SeoDetails['extra_fields']!='') { echo $SeoDetails['extra_fields']; }  ?></textarea>
                   <div id="error_extra_fields" class="error_code"><span></span></div>
                 </td>
                        </tr>

                      </tbody>
                    </table>
                    <table class="markup table table-bordered width-50 myTable">
                      
                    <tbody>
                     <tr>
                        <td>Og Image</td>
                         <td>
                   <input type="text" class="form-control" id="og_image" name="og_image" <?php if(isset($og_image) && !empty($og_image)) {  ?> value="<?php=$SeoDetails['og_image'];?>" <?php } else{ ?> value="" <?php } ?>>
                   <div id="error_og_image" class="error_code"><span></span></div>
                 </td>
                        </tr>
                      <tr>
                        <td>Og Description</td>
                         <td>
                          <textarea rows="4" cols="50" class="form-control" id="og_description" name="og_description"><?php if(isset($og_description) && !empty($og_description)) {  echo $SeoDetails['og_description'];  } else{ echo ""; } ?></textarea>
                   
                   <div id="error_og_description" class="error_code"><span></span></div>
                 </td>
                        </tr>
                        <tr>
                        <td>Og URL</td>
                         <td>
                   <input type="text" class="form-control" id="og_url" name="og_url" <?php if(isset($og_url) && !empty($og_url)) {  ?> value="<?php=$SeoDetails['og_url'];?>" <?php } else{ ?> value="" <?php } ?>>
                   <div id="error_og_url" class="error_code"><span></span></div>
                 </td>
                        </tr>
                        <tr>
                        <td>Og Type</td>
                         <td>
                   <input type="text" class="form-control" id="og_type" name="og_type" <?php if(isset($og_type) && !empty($og_type)) {  ?> value="<?php=$SeoDetails['og_type'];?>" <?php } else{ ?> value="" <?php } ?>>
                   <div id="error_og_type" class="error_code"><span></span></div>
                 </td>
                        </tr>
                        <tr>
                        <td>Canonical</td>
                         <td>
                   <input type="text" class="form-control" id="canonical" name="canonical" <?php if(isset($canonical) && !empty($canonical)) {  ?> value="<?php=$SeoDetails['canonical'];?>" <?php } else{ ?> value="" <?php } ?>>
                   <div id="error_canonical" class="error_code"><span></span></div>
                 </td>
                        </tr>
                        <tr>
                        <td>LOC</td>
                         <td>
                   <input type="text" class="form-control" id="loc" name="loc" <?php if(isset($loc) && !empty($loc)) {  ?> value="<?php=$SeoDetails['loc'];?>" <?php } else{ ?> value="" <?php } ?>>
                   <div id="error_loc" class="error_code"><span></span></div>
                 </td>
                        </tr>

                         <tr>
                        <td>Last Modified</td>
                         <td>
                  <input type="text" class="form-control" id="lastmod" name="lastmod" autocomplete="off" placeholder="dd-mm-yyyy" maxlength="10"  onkeydown="validate_number(event);" onkeyup="validate_number(event);" <?php if(isset($lastmod) && !empty($lastmod) && $lastmod!='0000-00-00') {  ?> value="<?php echo date("d-m-Y", strtotime($SeoDetails['lastmod']))?>" <?php } else{ ?> value="<?php echo date("d-m-Y");?>" <?php } ?>>
                   <div id="error_lastmod" class="error_code"><span></span></div>
                 </td>
                        </tr>

                         <tr>
                        <td>Change Frequently</td>
                         <td>
                          <select class="form-control" name="changefreq" id="changefreq">
                              <option value="">---- Select Page ----</option>
                              <option <?php if(isset($changefreq) && !empty($changefreq)) { if(strtolower($changefreq)=='always'){ echo 'selected';}} ?> value="always">Always</option>
                              <option <?php if(isset($changefreq) && !empty($changefreq)) { if(strtolower($changefreq)=='hourly'){ echo 'selected';}} ?> value="hourly">Hourly</option>
                              <option <?php if(isset($changefreq) && !empty($changefreq)) { if(strtolower($changefreq)=='daily'){ echo 'selected';}} ?> value="daily">Daily</option>
                              <option <?php if(isset($changefreq) && !empty($changefreq)) { if(strtolower($changefreq)=='weekly'){ echo 'selected';}} ?> value="weekly">Weekly</option>
                              <option <?php if(isset($changefreq) && !empty($changefreq)) { if(strtolower($changefreq)=='monthly'){ echo 'selected';}} ?> value="monthly">Monthly</option>
                              <option <?php if(isset($changefreq) && !empty($changefreq)) { if(strtolower($changefreq)=='yearly'){ echo 'selected';}} ?> value="yearly">Yearly</option>
                              <option <?php if(isset($changefreq) && !empty($changefreq)) { if(strtolower($changefreq)=='never'){ echo 'selected';}} ?> value="never">Never</option>

                            </select>
                   <div id="error_changefreq" class="error_code"><span></span></div>
                 </td>
                        </tr>
                        <tr>
                        <td>Priority</td>
                         <td>
                   <input type="text" class="form-control" id="priority" name="priority" <?php if(isset($priority) && !empty($priority)) {  ?> value="<?php=$SeoDetails['priority'];?>" <?php } else{ ?> value="" <?php } ?>>
                   <div id="error_priority" class="error_code"><span></span></div>
                 </td>
                        </tr>

                        <tr>
                        <td>Anchor Relation</td>
                         <td>
                   <input type="text" class="form-control" id="anchor_rel" name="anchor_rel" <?php if(isset($anchor_rel) && !empty($anchor_rel)) {  ?> value="<?php=$SeoDetails['anchor_rel'];?>" <?php } else{ ?> value="" <?php } ?>>
                   <div id="error_anchor_rel" class="error_code"><span></span></div>
                 </td>
                        </tr>

                        <tr>
                        <td>Schema</td>
                         <td>
                          <textarea rows="4" cols="50" class="form-control" id="schema_data" name="schema_data"><?php if(isset($schema_data) && !empty($schema_data)) {  echo stripslashes($SeoDetails['schema_data']);  } else{ echo ""; } ?></textarea>
                   <div id="error_schema_data" class="error_code"><span></span></div>
                 </td>
                        </tr>
                        
                        </tbody>
                      </table>
                      <?php /* **************** Begin:: Recharge Full Details Section **************** */ ?>

                      <div class="recharge_full_detail_parent">
                        <div class="recharge_full_detail_inner">
                          <div class="heading_box"><h2>To add a paragraph set Click on Add Button</h2></div>
                          <h6>Check the box if you don't want to set data for full recharge <INPUT type="checkbox" id="mychk" name="mychk"  <?php $mychk_field_new=''; if(isset($mychk_field) && !empty($mychk_field)) {   $mychk_field_new=trim($SeoDetails['mychk_field']); if($mychk_field_new=='true'){ ?> value="<?php=$SeoDetails['mychk_field'];?>" checked=checked <?php }else{ ?> value="false" <?php } }else {  ?> value="false"  <?php $mychk_field_new=" ";  } ?> /></h6>
                          <TABLE id="dataTable"  border="1" class="markup table table-bordered width-100" style="margin-top: 15px;clear: both;">
                            <div class="input_fields_wrap">
                    <button class="add_field_button btn btn-primary">Add More Rows</button>
                    <div class="dynamic_fields" id="dynamic_fields"> 
                      <tbody>
                    <?php                    				
					$mychk_field_new=''; if(isset($mychk_field) && !empty($mychk_field)) {   $mychk_field_new= trim($SeoDetails['mychk_field']); } else {  $mychk_field_new=" ";  }
					if($mychk_field_new=='false')
					{ 
				      if(isset($rowInfo) && $rowInfo!='')
					  { 
					  $rowInfoArray=json_decode($rowInfo,true);
                      $counter=0;
                      if(isset($rowInfoArray) && !empty($rowInfoArray))
					  { 
						foreach($rowInfoArray as $rowval){  
					  ?>                          
                      <tr>                      
						  <td>
							   <select class="form-control" id="rech_htag_<?php echo $counter; ?>" name="rowInfo[<?php echo $counter; ?>][rech_htag]" ><option value="">Select H Tag</option><option value="h1" <?php if(isset($rowInfoArray[$counter]['rech_htag']) && $rowInfoArray[$counter]['rech_htag']=='h1'){ echo "selected"; } ?> >H1</option><option value="h2" <?php if(isset($rowInfoArray[$counter]['rech_htag']) && $rowInfoArray[$counter]['rech_htag']=='h2'){ echo "selected"; } ?> >H2</option><option value="h3" <?php if(isset($rowInfoArray[$counter]['rech_htag']) && $rowInfoArray[$counter]['rech_htag']=='h3'){ echo "selected"; } ?> >H3</option><option value="h4" <?php if(isset($rowInfoArray[$counter]['rech_htag']) && $rowInfoArray[$counter]['rech_htag']=='h4'){ echo "selected"; } ?> >H4</option><option value="h5" <?php if(isset($rowInfoArray[$counter]['rech_htag']) && $rowInfoArray[$counter]['rech_htag']=='h5'){ echo "selected"; } ?> >H5</option><option value="h6" <?php if(isset($rowInfoArray[$counter]['rech_htag']) && $rowInfoArray[$counter]['rech_htag']=='h6'){ echo "selected"; } ?> >H6</option></select><div id="error_rech_htag_<?php echo $counter; ?>" class="error_code"><span></span></div>
							   <input type="text" class="form-control" id="rech_title_<?php echo $counter; ?>" name="rowInfo[<?php echo $counter; ?>][rech_title]" placeholder="Title" <?php if(isset($rowInfoArray[$counter]['rech_title']) && $rowInfoArray[$counter]['rech_title']!=''){ ?> value="<?php=$rowInfoArray[$counter]['rech_title']?>" <?php }else{ ?> value="" <?php } ?>>
							  <div id="error_rech_title_<?php echo $counter; ?>" class="error_code"><span></span></div>
						  </td>
						  <td>
								<textarea class="ckeditor" id="rech_desc_<?php echo $counter; ?>" name="rowInfo[<?php echo $counter; ?>][rech_desc]" placeholder="Description" rows="10" cols="80"><?php if(isset($rowInfoArray[$counter]['rech_desc']) && $rowInfoArray[$counter]['rech_desc']!=''){ echo stripslashes($rowInfoArray[$counter]['rech_desc']); } else {  } ?></textarea>
								<div id="error_rech_desc_<?php echo $counter; ?>" class="error_code"><span></span></div>
						  </td>
						  <td colspan="3"><button class="remove_field btn btn-danger" >Remove</button></td>
                       </tr>                    
                       <?php $counter++;   } ?>                        
                        <?php   } ?>
                        <?php   } ?>
                        <?php   } ?>
                    </tbody>  
                    </div>
                 
                </div>
              </TABLE>
                        </div>
                      </div>
                      <?php /* **************** End:: Recharge Full Details Section **************** */ ?>
                        <div class="row box-footer" style="margin: 0;clear: both;">

          <div class="pull-right seo_update_btn">

  
           
          <button type="submit" class="btn btn-primary" id="ag_submit" name="ag_submit">Update</button>
       

            <button type="reset" class="btn btn-danger" id="reset">Reset </button> 

      

          </div>

      </div>
                      
                    </div>
                    


           </div>
         </form>
         <div class="summary">
          <h1 class="panel-heading">Summary</h1>
           <div class="summary_inner col-md-12">
            
             <ul class="list_summary col-md-6">
               <li><span>Title : </span>It contain primary keyword and brand name, length under 70 chars.It is the very first HTML element that specifies your web page for search engines and to visitors. </li>
         <li><span>H1 : </span>It contain primary keyword and brand name, length under 70 chars.It is the very first HTML element that specifies your web page for search engines and to visitors. </li>
               <li><span>Meta Title : </span>It contain a sub title of your web page.</li>
               <li><span>Meta Description : </span>A Meta Description is an HTML element that summarizes your web page. Search engines typically show the Meta description in search results below your Title tag.</li>
               <li><span>Meta Keywords : </span>The meta keywords tag is where you put all of the keywords you use in your site. Eg:- content=”SEO, Hacker, Google, Search, etc”.It must include location / country, Place your main keywords in headlines, subheadings and anchor texts.</li>
               <li><span>Meta Robots : </span>The Robots Meta tag is an HTML tag that provides instructions to web crawlers on whether to index or noindex a web page.</li>
               <li><span>Meta Copyright : </span>Meta Copyright contain name of the owner. Eg:- content="name of owner" </li>
               <li><span>Og Site Name : </span>Open Graph Meta tags are designed to promote integration between Facebook, LinkedIn, Google and the website URLs that you shared on these platforms. Eg:- content=”SITE NAME” </li>
               <li><span>Og Title : </span>Eg:- content=”TITLE OF YOUR POST OR PAGE”</li>
               <li><span>Og Image : </span>Eg:- content=”LINK TO THE IMAGE FILE”</li>
             </ul>
             <ul class="list_summary col-md-6">
               <li><span>Og Description : </span>Eg:- content=”DESCRIPTION OF PAGE CONTENT”</li>
               <li><span>Og URL : </span>Eg:- content=”PERMALINK”</li>
               <li><span>Og Type : </span>Eg:- content=”article” </li>
               <li><span>Canonical : </span>By implementing the Canonical tag in the code, we are telling search engines that this URL is the main page and avoid indexing other duplicate page URLs.Eg: http://example.com/</li>
               <li><span>LOC : </span>URL of the page. This URL must begin with the protocol (such as http) and end with a trailing slash, if your web server requires it. This value must be less than 2,048 characters.</li>
               <li><span>Last Modified : </span>The date of last modification of the file.</li>
               <li><span>Change Frequently : </span>How frequently the page is likely to change.</li>
               <li><span>Priority : </span>The priority of this URL relative to other URLs on your site. Valid values range from 0.0 to 1.0.The default priority of a page is 0.5</li>
             </ul>
             
           </div>
         </div>
         </div>
       </div>
     </div></section>
  </div>
  <!-- /.content-wrapper -->


 <!-- Begin:: Footer -->
<?php $this->load->view('include/footer'); ?>
<!--/. End:: Footer -->

  
  
</div>
<!-- ./wrapper -->
<?php $this->load->view('include/foot'); ?>



<script type="text/javascript" src="<?php echo base_url(); ?>ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>ckeditor/adapters/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>ckeditor/plugins/colorbutton/plugin.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>ckeditor/plugins/panelbutton/plugin.js"></script>


  <script language="javascript" type="text/javascript">


    $(function(){
    $('#mychk').click(function() {
        if($(this).is(':checked')){
         var mychk_val= $('#mychk').val('true');
            $('.input_fields_wrap,#dataTable').hide();
        }
        else{
           var mychk_val= $('#mychk').val('false');
          $('.input_fields_wrap,#dataTable').show();
        }
            
    });
});

    
    $(document).ready(function() {
        var max_fields      = 5000; //maximum input boxes allowed
        var wrapper         = $("#dataTable >tbody"); //Fields wrapper
        var add_button      = $(".add_field_button"); //Add button ID     

          
        var x = $('#dataTable >tbody >tr').length; //initlal text box count
       // alert(x);
        var mychk_val= $('#mychk').val();
        if(mychk_val=='false'){
          $('.input_fields_wrap,#dataTable').show();
          
          
              $(add_button).click(function(e){ //on add input button click
                e.preventDefault();
                if(x < max_fields){ //max input box allowed
                     //text box increment
                    var chkId = 'chk_' +x;
                    var rech_htagId = 'rech_htag_' +x;
                    var rech_titleId = 'rech_title_' +x;
                    var rech_descId = 'rech_desc_' +x;
                    
                    var rech_htag='';
                    var rech_title='';
                    var rech_desc=''; 
                    

                    $(wrapper).append(' <tr><td><select class="form-control" id="'+rech_htagId+'"  name="rowInfo['+x+'][rech_htag]" ><option value="">Select H Tag</option><option value="h1">H1</option><option value="h2">H2</option><option value="h3">H3</option><option value="h4">H4</option><option value="h5">H5</option><option value="h6">H6</option></select><div id="error_rech_htag_'+x+'" class="error_code"><span></span></div><input type="text" class="form-control" id="'+rech_titleId+'"  name="rowInfo['+x+'][rech_title]" placeholder="Title"  value="'+rech_title+'"><div id="error_rech_title_'+x+'" class="error_code"><span></span></div></td><td><textarea class="ckeditor" id="'+rech_descId+'" name="rowInfo['+x+'][rech_desc]" placeholder="Description" rows="10" cols="80" value="'+rech_desc+'"></textarea><div id="error_rech_desc_'+x+'" class="error_code"><span></span></div></td><td><button class="remove_field btn btn-danger" >Remove</button></td></tr>');//add input box

                  
                   CKEDITOR.replace(rech_descId, { height:200 });
                   // var content = CKEDITOR.instances.rech_descId.getData();
                   // alert(content);
                    
                    x++;
                }
            });
            
            $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
                e.preventDefault(); var test = $(this).parents("tr").remove();x--;
            })

        }else{
          //alert(mychk_val);

            if(x < max_fields){ //max input box allowed
                     //text box increment
                    var chkId = 'chk_' +x;
                    var rech_titleId = 'rech_title_' +x;
                    var rech_descId = 'rech_desc_' +x;
                    $('#rech_title_'+x).val('');
                    $('#rech_desc_'+x).val('');
                    
                    x++;
                }
          $('.input_fields_wrap,#dataTable').hide();
        }
        
    });
    



  </script>

  
<script>
  $("form#recharge_default_seoform").submit(function(e) {

    e.preventDefault(); 


    // var formData = new FormData(this);
    var formData = new FormData($("#recharge_default_seoform")[0]); //It automatically collects all fields from form
    

    var errorflag=0;
    // var nospecial=/^[^*|\":<>[\]{}`\\()';@&$]+$/;
    var nospecial = /['"]/gi;
     var meta_description_nospecial=/['"]/gi;
    var page_name=$('#page_name').val();
    var service_name=$('#service_name').val();
  var titlew=$('#titlew').val();
  var h1_tag=$('#h1_tag').val();
  var meta_title=$('#meta_title').val();
  var meta_description=$('#meta_description').val();
  var meta_keywords=$('#meta_keywords').val();
  var meta_robots=$('#meta_robots').val();
  var meta_copyright=$('#meta_copyright').val();
  var og_site_name=$('#og_site_name').val();
  var og_title=$('#og_title').val();
  var og_image=$('#og_image').val();
  var og_description=$('#og_description').val();
  var og_url=$('#og_url').val();
  var og_type=$('#og_type').val();
  var canonical=$('#canonical').val();
  var loc=$('#loc').val();
  var lastmod=$('#lastmod').val();
  var changefreq=$('#changefreq').val();
  var priority=$('#priority').val();
  var anchor_rel=$('#anchor_rel').val();
  var schema_data=$('#schema_data').val();

var x = $('#dataTable >tbody >tr').length;

var i=0;
var data='';
var rech_title='';
for(i=0; i<x;i++){
  
  var rech_descId = 'rech_desc_'+i;
  
  data = CKEDITOR.instances['rech_desc_'+i].getData();
  
  rech_htag=$('#rech_htag_'+i).val();
  if(rech_htag=='')
  {       
      $('#rech_htag_'+i).addClass(' inpt_error ');
      $('#error_rech_htag_'+i+ ' span').html('Please select H tag');
      errorflag=1;
    }
  else
  {
      $('#rech_htag_'+i).removeClass(' inpt_error ');
    $('#error_rech_htag_'+i+ ' span').html('');
    }
    
  rech_title=$('#rech_title_'+i).val(); 
  if(rech_title==''){
        
      $('#rech_title_'+i).addClass(' inpt_error ');
      $('#error_rech_title_'+i+ ' span').html('Please enter Title');
      errorflag=1;
    }else{
      $('#rech_title_'+i).removeClass(' inpt_error ');
    $('#error_rech_title_'+i+ ' span').html('');
    }

   if(data==''){
        
      $('#rech_desc_'+i).addClass(' inpt_error ');
      $('#error_rech_desc_'+i+ ' span').html('Please enter Description');
      errorflag=1;
    }else{
      $('#rech_desc_'+i).removeClass(' inpt_error ');
    $('#error_rech_desc_'+i+ ' span').html('');
    var field_name='rowInfo['+i+'][rech_desc]';
    //formData.append(field_name, data);
    formData.append(field_name, CKEDITOR.instances['rech_desc_'+i].getData());
    }

  

}


    if(page_name==''){
        
      $("#page_name").addClass(' inpt_error ');
      $('#error_page_name span').html('Please select category');
      errorflag=1;
    }else{
      $("#page_name").removeClass(' inpt_error ');
    $('#error_page_name span').html('');
    }

    
    if(service_name=="")
      {
        $("#service_name").addClass('inpt_error');
        $('#error_service_name span').html('(Service Name is required)');       
        errorflag=1;
      }else if(service_name.length<2 || service_name.length>80)
      { 
        $("#service_name").addClass(' inpt_error ');             
        $('#error_service_name span').html('(Service Name should be of 2-80 characters)');          
        errorflag=1;
      }else if((nospecial.test(service_name))){          
        $("#service_name").addClass('inpt_error');          
        $('#error_service_name span').html('(Special character is not allowed in Service Name)');   
        errorflag=1;
        }else {
        $("#service_name").removeClass('inpt_error');
        $('#error_service_name span').html('');

      }

      if(titlew=="")
      {
        $("#titlew").addClass('inpt_error');
        $('#error_titlew span').html('(Title is required)');       
        errorflag=1;
      }else if(titlew.length<2 || titlew.length>100)
      { 
        $("#titlew").addClass(' inpt_error ');             
        $('#error_titlew span').html('(title should be of 2-100 characters)');          
        errorflag=1;
      }else {
        $("#titlew").removeClass('inpt_error');
        $('#error_titlew span').html('');

      }
    
    /* if(h1_tag=="")
      {
        $("#h1_tag").addClass('inpt_error');
        $('#error_h1_tag span').html('(H1 is required)');       
        errorflag=1;
      }else if(h1_tag.length<2 || h1_tag.length>70)
      { 
        $("#h1_tag").addClass(' inpt_error ');             
        $('#error_h1_tag span').html('(H1 should be of 2-70 characters)');          
        errorflag=1;
      }else if((nospecial.test(h1_tag))){          
        $("#h1_tag").addClass('inpt_error');          
        $('#error_h1_tag span').html('(Special character is not allowed in H1)');   
        errorflag=1;
        }else {
        $("#h1_tag").removeClass('inpt_error');
        $('#error_h1_tag span').html('');

      }

      if(meta_title=="")
      {
        $("#meta_title").addClass('inpt_error');
        $('#error_meta_title span').html('(Meta Title is required)');       
        errorflag=1;
      }else if(meta_title.length<2 || meta_title.length>100)
      { 
        $("#meta_title").addClass(' inpt_error ');             
        $('#error_meta_title span').html('(Meta Title should be of 2-100 characters)');          
        errorflag=1;
      }else {
        $("#meta_title").removeClass('inpt_error');
        $('#error_meta_title span').html('');

      }


      if(meta_description=="")
      {
        $("#meta_description").addClass('inpt_error');
        $('#error_meta_description span').html('(Meta Description is required)');       
        errorflag=1;
      }else if(meta_description.length<2 || meta_description.length>320)
      { 
        $("#meta_description").addClass(' inpt_error ');             
        $('#error_meta_description span').html('(Meta Description should be of 2-320 characters)');          
        errorflag=1;
      }else {
        $("#meta_description").removeClass('inpt_error');
        $('#error_meta_description span').html('');

      }

      if(meta_keywords=="")
      {
        $("#meta_keywords").addClass('inpt_error');
        $('#error_meta_keywords span').html('(Meta keywords is required)');       
        errorflag=1;
      }else if(meta_keywords.length<2)
      { 
        $("#meta_keywords").addClass(' inpt_error ');             
        $('#error_meta_keywords span').html('(Meta keywords must be more than 2 characters)');          
        errorflag=1;
      }else {
        $("#meta_keywords").removeClass('inpt_error');
        $('#error_meta_keywords span').html('');

      }

      if(meta_robots!="")
      {
        
      if(meta_robots.length<2 || meta_robots.length>80)
      { 
        $("#meta_robots").addClass(' inpt_error ');             
        $('#error_meta_robots span').html('(Meta Robots should be of 2-80 characters)');          
        errorflag=1;
      }else if((nospecial.test(meta_robots))){          
        $("#meta_robots").addClass('inpt_error');          
        $('#error_meta_robots span').html('(Special character is not allowed in Meta Robots)');   
        errorflag=1;
        }else {
        $("#meta_robots").removeClass('inpt_error');
        $('#error_meta_robots span').html('');
    }
    }

      if(meta_copyright!="")
      {
        if(meta_copyright.length<2 || meta_copyright.length>80)
        { 
          $("#meta_copyright").addClass(' inpt_error ');             
          $('#error_meta_copyright span').html('(Meta Copyright should be of 2-80 characters)');          
          errorflag=1;
        }else if((nospecial.test(meta_copyright))){          
          $("#meta_copyright").addClass('inpt_error');          
          $('#error_meta_copyright span').html('(Special character is not allowed in Meta Copyright)');   
          errorflag=1;
          }else {
          $("#meta_copyright").removeClass('inpt_error');
          $('#error_meta_copyright span').html('');
        }
      }

      if(og_site_name!="")
      {
        if(og_site_name.length<2 || og_site_name.length>80)
        { 
          $("#og_site_name").addClass(' inpt_error ');             
          $('#error_og_site_name span').html('(Og Site Name should be of 2-80 characters)');          
          errorflag=1;
        }else if((nospecial.test(og_site_name))){          
          $("#og_site_name").addClass('inpt_error');          
          $('#error_og_site_name span').html('(Special character is not allowed in Og Site Name)');   
          errorflag=1;
          }else {
          $("#og_site_name").removeClass('inpt_error');
          $('#error_og_site_name span').html('');
      }
    }

      if(og_title!="")
      {
        if(og_title.length<2 || og_title.length>100)
        { 
          $("#og_title").addClass(' inpt_error ');             
          $('#error_og_title span').html('(Og Title should be of 2-100 characters)');          
          errorflag=1;
        }else {
          $("#og_title").removeClass('inpt_error');
          $('#error_og_title span').html('');
      }
    } */

      // if(og_image!="")
      // {
      //   $("#og_image").addClass('inpt_error');
      //   $('#error_og_image span').html('(Og Image is required)');       
      //   errorflag=1;
      // }else {
      //   $("#og_image").removeClass('inpt_error');
      //   $('#error_og_image span').html('');

      // }

     /* if(og_description!="")
      {
        if(og_description.length<2 || og_description.length>320)
        { 
          $("#og_description").addClass(' inpt_error ');             
          $('#error_og_description span').html('(Og Description should be of 2-320 characters)');          
          errorflag=1;
        }else if((nospecial.test(og_description))){          
          $("#og_description").addClass('inpt_error');          
          $('#error_og_description span').html('(Special character is not allowed in Og Description)');   
          errorflag=1;
          }else {
          $("#og_description").removeClass('inpt_error');
          $('#error_og_description span').html('');
      }
    }

      // if(og_url=="")
      // {
      //   $("#og_url").addClass('inpt_error');
      //   $('#error_og_url span').html('(Og URL is required)');       
      //   errorflag=1;
      // }else {
      //   $("#og_url").removeClass('inpt_error');
      //   $('#error_og_url span').html('');

      // }

      if(og_type!="")
      {
        if(og_type.length<2 || og_type.length>80)
        { 
          $("#og_type").addClass(' inpt_error ');             
          $('#error_og_type span').html('(Og Type should be of 2-80 characters)');          
          errorflag=1;
        }else if((nospecial.test(og_type))){          
          $("#og_type").addClass('inpt_error');          
          $('#error_og_type span').html('(Special character is not allowed in Og Type)');   
          errorflag=1;
          }else {
          $("#og_type").removeClass('inpt_error');
          $('#error_og_type span').html('');
      }
    }

      // if(canonical=="")
      // {
      //   $("#canonical").addClass('inpt_error');
      //   $('#error_canonical span').html('(Canonical is required)');       
      //   errorflag=1;
      // }else {
      //   $("#canonical").removeClass('inpt_error');
      //   $('#error_canonical span').html('');

      // }

      // if(loc=="")
      // {
      //   $("#loc").addClass('inpt_error');
      //   $('#error_loc span').html('(LOC is required)');       
      //   errorflag=1;
      // }else {
      //   $("#loc").removeClass('inpt_error');
      //   $('#error_loc span').html('');

      // }

      var arr1 = lastmod.split('-');
    var nwDateGet=arr1[2]+'-'+arr1[1]+'-'+arr1[0];
    var nwDateGet = new Date(nwDateGet);
    var today = new Date();
    
      
    if(lastmod!="")
    { 
       if (nwDateGet =="Invalid Date" ) { 
        $("#lastmod").addClass('inpt_error');         
              $('#error_lastmod span').html('(Enter a valid date)');
              errorflag=1;
      }else if ( nwDateGet > today ) { 
        $("#lastmod").addClass('inpt_error');
              $('#error_lastmod span').html('(You cannot enter a date in the future!)');
              errorflag=1;
      }else {
        $("#lastmod").removeClass('inpt_error');
        $('#error_lastmod span').html('');
      }
    }  */

  

      // if(changefreq=="")
      // {
      //   $("#changefreq").addClass('inpt_error');
      //   $('#error_changefreq span').html('(Change Frequently is required)');       
      //   errorflag=1;
      // }else {
      //   $("#changefreq").removeClass('inpt_error');
      //   $('#error_changefreq span').html('');

      // }

      /* if(priority!="")
      {
          if(priority.length<2 || priority.length>50)
        { 
          $("#priority").addClass(' inpt_error ');             
          $('#error_priority span').html('(Priority should be of 2-50 characters)');          
          errorflag=1;
        }else if((nospecial.test(priority))){          
          $("#priority").addClass('inpt_error');          
          $('#error_priority span').html('(Special character is not allowed in Priority)');   
          errorflag=1;
          }else {
          $("#priority").removeClass('inpt_error');
          $('#error_priority span').html('');
      }
    }

     if(anchor_rel!="")
      {
      if(anchor_rel.length<2 || anchor_rel.length>70)
      { 
        $("#anchor_rel").addClass(' inpt_error ');             
        $('#error_anchor_rel span').html('(Anchor Relation should be of 2-70 characters)');          
        errorflag=1;
      }else if((nospecial.test(anchor_rel))){          
        $("#anchor_rel").addClass('inpt_error');          
        $('#error_anchor_rel span').html('(Special character is not allowed in Anchor Relation)');   
        errorflag=1;
        }else {
        $("#anchor_rel").removeClass('inpt_error');
        $('#error_anchor_rel span').html('');

      }
    }


     if(schema_data=="")
      {
        $("#schema_data").addClass('inpt_error');
        $('#error_schema_data span').html('(schema Data is required)');       
        errorflag=1;
      }else if(schema_data.length<2)
      { 
        $("#schema_data").addClass(' inpt_error ');             
        $('#error_schema_data span').html('(schema Data must be more than 2 characters)');          
        errorflag=1;
      }else {
        $("#schema_data").removeClass('inpt_error');
        $('#error_schema_data span').html('');
      } */

    // alert(Base_URL+"tarvel/tdefault/seo_update");
    if(errorflag==0)
  {
    $('.loader_upload_overlay').show();
     $.ajax({        

          url:Base_URL+"recharge/seo_update",

          type: 'POST',

          data: formData,

          //timeout: 60000, //Set your timeout value in milliseconds or 0 for unlimited

          cache: false,

          contentType: false,

          processData: false,

          success: function (data) {

            $('.loader_upload_overlay').hide();
            console.log(data);
            data=data.trim();
            var obj = JSON.parse(data);
            

            if(obj.status==200)
            {
              $('.alert-success.seo_div span.success_txt').addClass('noerror');
              $('.alert-success.seo_div span.success_txt').removeClass('error');
              $('.alert-success.seo_div span.success_txt').html(obj.message);
              
              $('.alert-success.seo_div').show();
              $("html, body").animate({ scrollTop: 0 }, "slow");

            }else if(data==400){
              $('.alert-success.seo_div span.success_txt').addClass('error');
              $('.alert-success.seo_div span.success_txt').removeClass('noerror');
              $('.alert-success.seo_div span.success_txt').html(obj.message);

              $('.alert-success.seo_div').show();
              $("html, body").animate({ scrollTop: 0 }, "slow");
              // $('.alert-success.success_div').hide();
              // $('.alert-success.success_div span').html('');
              // $('.alert-success.agent_div').hide();
              

            }

          }

        }); 

      }

});

function resetSEOForm()
{
    
    var titlew=$('#titlew').val('');
  var meta_title=$('#meta_title').val('');
  var meta_description=$('#meta_description').val('');
  var meta_keywords=$('#meta_keywords').val('');
  var meta_robots=$('#meta_robots').val('');
  var meta_copyright=$('#meta_copyright').val('');
  var og_site_name=$('#og_site_name').val('');
  var og_title=$('#og_title').val('');
  var og_image=$('#og_image').val('');
  var og_description=$('#og_description').val('');
  var og_url=$('#og_url').val('');
  var og_type=$('#og_type').val('');
  var canonical=$('#canonical').val('');
  var loc=$('#loc').val('');
  var lastmod=$('#lastmod').val('');
  var changefreq=$('#changefreq').val('');
  var priority=$('#priority').val('');
  var schema_data=$("#schema_data").val('');
}

$( document ).ready(function() {
  $( "#reset" ).on('click',function() {
    // alert('hii');
      resetSEOForm();

    });

    $("#lastmod").keyup(function(){
                if ($(this).val().length == 2){
                    $(this).val($(this).val() + "-");
                }else if ($(this).val().length == 5){
                    $(this).val($(this).val() + "-");
                }else if($(this).val().length > 10){
                  var pprt=$(this).val().substr(0, 10);
                  $(this).val(pprt);
                }
            });

    $('#page_name').on('change', function() {
 
   window.location.href=Base_URL+'recharge/rdefault/'+this.value+'/'+$('#service_name').val();
     
});
});
</script>
</body>
</html>
