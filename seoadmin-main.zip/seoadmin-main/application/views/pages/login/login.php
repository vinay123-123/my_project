
<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
  <?php $this->load->view('include/head'); ?>

</head>
<body class="hold-transition login-page">
<div class="login-box">
   <div class="login-logo">
    <!-- <a href="../../index2.html"><b>Indi</b>TAB</a> -->
    <!-- <img src="<?php //echo base_url(); ?>dist/img/logo.png" class="img-responsive" style="margin: 0 auto;width: 60%;"> -->
    <div class="">ADMIN LOGIN</div>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    

    <form action="#" method="post" id="login_form">
      <div class="form-group has-feedback">
        <input type="email" class="form-control" placeholder="Email" id="lemail" name="lemail">
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
        <div id="error_lemail" class="clearfix form_rules" >
           <span class="error"></span>
        </div>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" placeholder="Password" id="lpassword" name="lpassword">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
        <div id="error_lpassword" class="clearfix form_rules" >
           <span class="error"></span>
        </div>
      </div>

      <div class="row">
        <div id="all_error" class="clearfix form_rules" >
             <span class="error"></span>
        </div>
      </div>
       <div class="row1 login_btn">
        <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
       <!-- /.col -->
      </div>
     
    </form>
    
    

  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->
<?php $this->load->view('include/foot'); ?>

<script type="text/javascript">
  

  $("form#login_form").submit(function(e) {
    e.preventDefault(); 
    //alert('feg');
    var formData = new FormData(this);
    
    var errorflag=0;
    var lemail=$("#lemail").val();
    var lpassword=$("#lpassword").val();
    $("#all_error").hide();             
    $('#all_error span').html('');
    
    if(lemail=="")
  {
    $("#lemail").addClass(' inpt_error ');
    $('#error_lemail span').html('(Email Id is required)');
    errorflag=1;
    
  }
  else if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})+$/.test(lemail))) 
  {
    $("#lemail").addClass(' inpt_error ');
    $('#error_lemail span').html('(Please enter valid Email Id)');    
      errorflag=1;
  }
  else { 

    $('#lemail').removeClass('inpt_error');
    $('#error_lemail span').html('');
   }
  

    if(lpassword=="")
    {
      $("#lpassword").addClass(' inpt_error ');  
      $('#error_lpassword span').html('(Password is required)');  
      errorflag=1;
     
    }else if(lpassword.length<2 || lpassword.length>100)
    { 
      $("#lpassword").addClass(' inpt_error ');             
      $('#error_lpassword span').html('(Password should be of 2-100 length)');          
      errorflag=1;
    }else {
      
      $("#lpassword").removeClass('inpt_error'); 
      $('#error_lpassword span').html('');  
    }

  
    if(errorflag==0)
   {

    
        $.ajax({        
          url:Base_URL+"index.php/Mycontroller/admin_login",
          type: 'POST',
          data: formData,
          //timeout: 60000, //Set your timeout value in milliseconds or 0 for unlimited
          cache: false,
          contentType: false,
          processData: false,
          success: function (data) {

            data=data.trim();
            //console.log(data);
            if(data==200)
            {
              window.location.href=Base_URL+'<?=ADMIN_BASE_URL;?>dashboard';
              console.log(data);
              $("#all_error").hide();
            }
            else {
              $("#all_error").show();             
              $('#all_error span').html('(Please enter correct Email Id and Password !)');
            }
          }
        }); 
      }
});

  </script>
</body>
</html>
