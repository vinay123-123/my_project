

<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
  <?php $this->load->view('include/head'); ?>

</head>
<body class="hold-transition register-page">
<div class="register-box">
  <div class="register-logo">
   <!--  <a href="../../index2.html"><b>Indi</b>TAB</a> -->
    <img src="<?php echo base_url(); ?>dist/img/logo.png" class="img-responsive" style="margin: 0 auto;width: 60%;"> 
  </div>

  <div class="register-box-body">
    <p class="login-box-msg">Register a new membership</p>

    <form action="#" method="post" id="reg_form">
      <div class="form-group has-feedback">
        <input type="text" class="form-control" placeholder="Full name" name="uname" id="uname">
        <span class="glyphicon glyphicon-user form-control-feedback"></span>
        <div id="error_uname" class="clearfix form_rules" >
           <span class="error"></span>
        </div>
      </div>
      <div class="form-group has-feedback">
        <input type="text" class="form-control" placeholder="Mobile No" name="umobile" id="umobile">
        <span class="glyphicon glyphicon-user form-control-feedback"></span>
        <div id="error_umobile" class="clearfix form_rules" >
           <span class="error"></span>
        </div>
      </div>
      <div class="form-group has-feedback">
        <input type="email" class="form-control" placeholder="Email" name="useremail" id="useremail">
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
        <div id="error_useremail" class="clearfix form_rules" >
           <span class="error"></span>
        </div>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" placeholder="Password" name="password" id="password">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
        <div id="error_password" class="clearfix form_rules" >
           <span class="error"></span>
        </div>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" placeholder="Retype password" name="rpassword" id="rpassword">
        <span class="glyphicon glyphicon-log-in form-control-feedback"></span>
        <div id="error_rpassword" class="clearfix form_rules" >
           <span class="error"></span>
        </div>
      </div>
      <div class="form-group has-feedback">
        <select  class="form-control" placeholder="Admin Type" name="type" id="type">
          <option value="">----Select----</option>
          <option value="superadmin">Superadmin</option>
          <option value="admin">Admin</option>
          <option value="executive">Executive</option>
          <option value="agent">Agent</option>
        </select>
        <span class="glyphicon glyphicon-collapse-down form-control-feedback"></span>
        <div id="error_type" class="clearfix form_rules" >
           <span class="error"></span>
        </div>
      </div>
      <div class="row">
        <div class="col-xs-8">
          <!-- <div class="checkbox icheck">
            <label>
              <input type="checkbox"> I agree to the <a href="#">terms</a>
            </label>
          </div> -->
        </div>
        <!-- /.col -->
        <div class="col-xs-4">
          <button type="submit" class="btn btn-primary btn-block btn-flat">Register</button>
        </div>
        <!-- /.col -->
      </div>
    </form>

   

    <a href="<?php echo BASEURL.ADMIN_BASE_URL; ?>login" class="text-center">I already have a membership</a>
  </div>
  <!-- /.form-box -->
</div>
<!-- /.register-box -->

<?php $this->load->view('include/foot'); ?>
<script type="text/javascript">
  

  $("form#reg_form").submit(function(e) {
    e.preventDefault(); 
    //alert('feg');
    var formData = new FormData(this);
    
    var errorflag=0;
    var nospecial=/^[^*|\":<>[\]{}`\\()';@&$]+$/;
    var uname=$("#uname").val();
    uname=uname.trim();
    var umobile=$('#umobile').val();
    var useremail=$("#useremail").val();
    var password=$("#password").val();
    var rpassword=$("#rpassword").val();
    var type=$("#type").val();
    
    


    if(uname=="")
    {
        
      $("#uname").addClass('inpt_error');
      $('#error_uname span').html('(Full Name is required)');       
          
      errorflag=1;
   }
    else if(uname.length<2 || uname.length>50)
    {
          
      $("#uname").addClass(' inpt_error ');             
      $('#error_uname span').html('(Full Name should be of 2-50 characters)');          
      errorflag=1;
    }
    else if(!(nospecial.test(uname))){          
            
        $("#uname").addClass('inpt_error');          
        $('#error_uname span').html('(Special character is not allowed in Full Name)');   
         errorflag=1;
      }
    else {
      
      $("#uname").removeClass('inpt_error');
      $('#error_uname span').html('');
    }


     if(umobile=="")
    {
      $("#umobile").addClass(' inpt_error ');  
      $('#error_umobile span').html('(Mobile No. is required)');  
      errorflag=1;
    }else if(umobile.length<10 || umobile.length>10)
    {
      $('#umobile').addClass(' inpt_error ');
      
      $('#error_umobile span').html('(Please enter valid Mobile No.)');    
        errorflag=1;  
    }
    else if(!(/^\d{10,13}$/.test(umobile))) /* /^\d{10,13}$/ */
    {       
        $('#umobile').addClass(' inpt_error '); 
        
        $('#error_umobile span').html('(Please enter valid Mobile No.)');  
        errorflag=1;  
    }else if(umobile=="0000000000"){
        $('#umobile').addClass(' inpt_error '); 
        
        $('#error_umobile span').html('(Please enter valid Mobile No.)');  
        errorflag=1;
    }else {        
        $("#umobile").removeClass('inpt_error'); 
        $('#error_umobile span').html('');  
    }

    if(useremail=="")
  {
    $("#useremail").addClass(' inpt_error ');
    $('#error_useremail span').html('(Email is required)');
    errorflag=1;
    
  }
  else if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})+$/.test(useremail))) 
  {
    $("#useremail").addClass(' inpt_error ');
    $('#error_useremail span').html('(Please enter valid Email Id)');    
      errorflag=1;
  }
  else { 

    $('#useremail').removeClass('inpt_error');
    $('#error_useremail span').html('');
   }
  

    if(password=="")
    {
      $("#password").addClass(' inpt_error ');  
      $('#error_password span').html('(Password is required)');  
      errorflag=1;
     
    }else if(password.length<2 || password.length>100)
    { 
      $("#password").addClass(' inpt_error ');             
      $('#error_password span').html('(Password should be of 2-100 length)');          
      errorflag=1;
    }else {
      
      $("#password").removeClass('inpt_error'); 
      $('#error_password span').html('');  
    }

    if(rpassword=="")
    {
      $("#rpassword").addClass(' inpt_error ');  
      $('#error_rpassword span').html('(Repeat-Password is required)');  
      errorflag=1;
    }else if(password.length<2 || password.length>100)
    { 
      $("#rpassword").addClass(' inpt_error ');             
      $('#error_rpassword span').html('(Repeat-Password should be of 2-100 length)');          
      errorflag=1;
    }else if(password!=rpassword){
      $("#rpassword").addClass(' inpt_error ');             
      $('#error_rpassword span').html('(Repeat-Password not match with Password)');          
      errorflag=1;
    }else {
      
      $("#rpassword").removeClass('inpt_error'); 
      $('#error_rpassword span').html('');  
    }

    if(type=="")
    {
      $("#type").addClass(' inpt_error ');  
      $('#error_type span').html('(Admin Type is required)');  
      errorflag=1;
    }else {
      
      $("#type").removeClass('inpt_error'); 
      $('#error_type span').html('');  
    }

    if(errorflag==0)
   {

    
        $.ajax({        
          url:Base_URL+"Mycontroller/admin_register",
          type: 'POST',
          data: formData,
          //timeout: 60000, //Set your timeout value in milliseconds or 0 for unlimited
          cache: false,
          contentType: false,
          processData: false,
          success: function (data) {

            data=data.trim();
            //console.log(data);
            if(data==200)
            {
              window.location.href=Base_URL+'<?=ADMIN_BASE_URL;?>login';
            }
            else {
              window.location.href=Base_URL+'<?=ADMIN_BASE_URL;?>';
            }
          }
        }); 
      }
});

  </script>
</body>

</html>
