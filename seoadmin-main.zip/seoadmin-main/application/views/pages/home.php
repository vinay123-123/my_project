<?php 
//print_r($_SESSION);// $this->session->userdata('ADMIN_LOGGEDIN');
if($this->session->userdata('SEO_ADMIN_LOGGEDIN')!=1){
    header('Location:' .BASEURL.ADMIN_BASE_URL."login"); 
}
date_default_timezone_set(DEFAULT_TIME_ZONE);

// print_r($SeoDetails);

$page_name='';
$titlew='';
$meta_title='';
$meta_description='';
$meta_keywords='';
$meta_robots='';
$meta_copyright='';
$og_site_name='';
$og_title='';
$og_image='';
$og_description='';
$og_url='';
$og_type='';
$canonical='';
$loc='';
$lastmod='';
$changefreq='';
$priority='';
$anchor_rel='';
$extra_fields='';
$schema_data='';
$current_segment='';
$current_segment=$this->uri->segment(3);

if(isset($SeoDetails) && !empty($SeoDetails)){

  $page_name=$SeoDetails['page_name'];
  $service_name=$SeoDetails['service_name'];
  $titlew=$SeoDetails['title'];
  $meta_title=$SeoDetails['meta_title'];
  $meta_description=$SeoDetails['meta_description'];
  $meta_keywords=$SeoDetails['meta_keywords'];
  $meta_robots=$SeoDetails['meta_robots'];
  $meta_copyright=$SeoDetails['meta_copyright'];
  $og_site_name=$SeoDetails['og_site_name'];
  $og_title=$SeoDetails['og_title'];
  $og_image=$SeoDetails['og_image'];
  $og_description=$SeoDetails['og_description'];
  $og_url=$SeoDetails['og_url'];
  $og_type=$SeoDetails['og_type'];
  $canonical=$SeoDetails['canonical'];
  $loc=$SeoDetails['loc'];
  $lastmod=date("d-m-Y", strtotime($SeoDetails['lastmod']));
  $changefreq=$SeoDetails['changefreq'];
  $priority=$SeoDetails['priority'];
  $anchor_rel=$SeoDetails['anchor_rel'];
  if(isset($SeoDetails['extra_fields']) && $SeoDetails['extra_fields']!="") { $extra_fields=$SeoDetails['extra_fields']; } else { $extra_fields=''; }

if(isset($SeoDetails['schema_data']) && $SeoDetails['schema_data']!="") { $schema_data=$SeoDetails['schema_data']; } else { $schema_data=''; }
}
?>
<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
  <?php $this->load->view('include/head'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="loader_upload_overlay" id="loader_upload_overlay" style="display:none;">
    <div class="loader_upload_handle">
        <div class="loader_upload_preload">
            <img src="<?=base_url();?>dist/img/loader.gif" alt="Please wait" title="Please wait"/>
        </div>
        <div class="upload_waiting_txt">Please wait. Kindly donot press refresh or back button</div>
    </div>
</div>
<div class="wrapper">

  <?php $this->load->view('include/header'); ?>
  
  <!-- Left side column. contains the logo and sidebar -->
 <?php $this->load->view('include/left_sidebar'); ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <section class="content-header">
      <div class="row">
       <div class="col-xs-20 col-md-12 col-xs-12">
        <div class="top-heading">
         <h1><? if(isset($page_name) && $page_name!=""){echo strtoupper($page_name);}else{ echo strtoupper("Home Form"); } ?></h1>
          <ol class="breadcrumb">
                        <li><a href="#"><i class="fa fa-dashboard"></i><? if(isset($service_name) && !empty($service_name)){echo ucwords($service_name);}else{echo "Home";}?></a></li>
                        <li><a href="#"><? if(isset($page_name) && !empty($page_name)){echo ucwords($page_name);}else{ echo "Home Form"; } ?></a></li>
                        
                    </ol>
       </div>

        <div class="alert alert-success seo_div alert-dismissable" style="display: none;">
            
                <i class="fa fa-check"></i>

                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
           
                
                <span class="success_txt"></span>

        </div>
       <!--#################################### SEO Form Start ####################################-->
       <div class="panel panel-default">
         <div class="new-body panel-body">
          <div class="panel-heading"><? if(isset($service_name) && !empty($service_name)){echo ucwords($service_name);}else{echo "Home";}?> - <? if(isset($page_name) && !empty($page_name)){echo ucwords($page_name);} ?> SEO Form</div>
                 <div class="seo_parent">
                  <form class="form-horizontal" name="tarvel_default_seoform" id="tarvel_default_seoform" action="" method="POST">
                   <div class="seo_inner">
                    <div id="seoform_section">
                     <div class="row">
                      <div class="col-md-12 page_section">
                       <div class="row my_row">
                           <div class="col-md-3 col-sm-12">
                            
                          </div>
                          <div class="col-md-2 col-sm-12">
                            <label>
                              Select Page
                            </label>
                          </div>
                          <div class="col-md-4 col-sm-12">
                            <select class="form-control" name="page_name" id="page_name">
                              <option value>---- Select Page ----</option> 
                              <option  value="home" <?php if(isset($page_name) && !empty($page_name)) { if(strtolower($page_name)=='home'){ echo 'selected';}}else{if(strtolower($current_segment)=='home'){ echo 'selected';}}?>>Home</option>
                              
                            </select>
                            <div id="error_page_name" class="error_code"><span></span></div>
                          </div>   
                          <div class="col-md-3 col-sm-12">
                            
                          </div>
                      </div>
                    </div> 
                   

                 </div>
                 <table class="markup table table-bordered width-50 myTable">
                <tbody>
                 <tr>
                  <td>Service Name</td>
                  <td>
                    
                   <input type="text" class="form-control" id="service_name" name="service_name" <? if(isset($service_name) && !empty($service_name)) {  ?> value="<?=$SeoDetails['service_name'];?>" <? } else { ?> value="home" <? } ?>  readonly="">
                   <div id="error_service_name" class="error_code"><span></span></div>
                 </td>
                  </tr>
                  <tr>
                    <td>Title</td>
                     <td>
                      <textarea rows="4" cols="50" class="form-control" id="titlew" name="titlew"><? if(isset($titlew) && !empty($titlew)) {  echo $SeoDetails['title'];  } else{ echo ""; } ?></textarea>
                   <div id="error_titlew" class="error_code"><span></span></div>
                 </td>
                    </tr>
                    <tr>
                      <td>Meta Title</td>
                      <td>
                        <textarea rows="4" cols="50" class="form-control" id="meta_title" name="meta_title"><? if(isset($meta_title) && !empty($meta_title)) {  echo $SeoDetails['meta_title'];  } else{ echo ""; } ?></textarea>
                   
                   <div id="error_meta_title" class="error_code"><span></span></div>
                 </td>
                      </tr>
                      <tr>
                        <td>Meta Description</td>
                         <td>
                          <textarea rows="4" cols="50" class="form-control" id="meta_description" name="meta_description"><? if(isset($meta_description) && !empty($meta_description)) {  echo $SeoDetails['meta_description'];  } else{ echo ""; } ?> </textarea>
                  
                   <div id="error_meta_description" class="error_code"><span></span></div>
                 </td>
                        </tr>

                         <tr>
                        <td>Meta Keywords</td>
                         <td>
                          <textarea rows="4" cols="50" class="form-control" id="meta_keywords" name="meta_keywords"><? if(isset($meta_keywords) && !empty($meta_keywords)) {  echo $SeoDetails['meta_keywords'];  } else{ echo ""; } ?></textarea>
                   
                   <div id="error_meta_keywords" class="error_code"><span></span></div>
                 </td>
                        </tr>

                         <tr>
                        <td>Meta Robots</td>
                         <td>
                   <input type="text" class="form-control" id="meta_robots" name="meta_robots" <? if(isset($meta_robots) && !empty($meta_robots)) {  ?> value="<?=$SeoDetails['meta_robots'];?>" <? } else{ ?> value="" <? } ?>>
                   <div id="error_meta_robots" class="error_code"><span></span></div>
                 </td>
                        </tr>

                         <tr>
                        <td>Meta Copyright</td>
                         <td>
                   <input type="text" class="form-control" id="meta_copyright" name="meta_copyright" <? if(isset($meta_copyright) && !empty($meta_copyright)) {  ?> value="<?=$SeoDetails['meta_copyright'];?>" <? } else{ ?> value="" <? } ?>>
                   <div id="error_meta_copyright" class="error_code"><span></span></div>
                 </td>
                        </tr>

                         <tr>
                        <td>Og Site Name</td>
                         <td>
                   <input type="text" class="form-control" id="og_site_name" name="og_site_name" <? if(isset($og_site_name) && !empty($og_site_name)) {  ?> value="<?=$SeoDetails['og_site_name'];?>" <? } else{ ?> value="" <? } ?>>
                   <div id="error_og_site_name" class="error_code"><span></span></div>
                 </td>
                        </tr>

                         <tr>
                        <td>Og Title</td>
                         <td>
                          <textarea rows="4" cols="50" class="form-control" id="og_title" name="og_title"><? if(isset($og_title) && !empty($og_title)) {  echo $SeoDetails['og_title'];  } else{ echo ""; } ?></textarea>
                   
                   <div id="error_og_title" class="error_code"><span></span></div>
                 </td>
                        </tr>
                          <tr>
                        <td>Additional Fields</td>
                         <td>
           <textarea rows="4" cols="50" class="form-control" name="extra_fields" id="extra_fields"><?  if(isset($SeoDetails['extra_fields']) && $SeoDetails['extra_fields']!='') { echo $SeoDetails['extra_fields']; }  ?></textarea>
                   <div id="error_extra_fields" class="error_code"><span></span></div>
                 </td>
                        </tr>
                      </tbody>
                    </table>
                    <table class="markup table table-bordered width-50 myTable">
                      
                    <tbody>
                     <tr>
                        <td>Og Image</td>
                         <td>
                   <input type="text" class="form-control" id="og_image" name="og_image" <? if(isset($og_image) && !empty($og_image)) {  ?> value="<?=$SeoDetails['og_image'];?>" <? } else{ ?> value="" <? } ?>>
                   <div id="error_og_image" class="error_code"><span></span></div>
                 </td>
                        </tr>
                      <tr>
                        <td>Og Description</td>
                         <td>
                          <textarea rows="4" cols="50" class="form-control" id="og_description" name="og_description"><? if(isset($og_description) && !empty($og_description)) {  echo $SeoDetails['og_description'];  } else{ echo ""; } ?></textarea>
                   
                   <div id="error_og_description" class="error_code"><span></span></div>
                 </td>
                        </tr>
                        <tr>
                        <td>Og URL</td>
                         <td>
                   <input type="text" class="form-control" id="og_url" name="og_url" <? if(isset($og_url) && !empty($og_url)) {  ?> value="<?=$SeoDetails['og_url'];?>" <? } else{ ?> value="" <? } ?>>
                   <div id="error_og_url" class="error_code"><span></span></div>
                 </td>
                        </tr>
                        <tr>
                        <td>Og Type</td>
                         <td>
                   <input type="text" class="form-control" id="og_type" name="og_type" <? if(isset($og_type) && !empty($og_type)) {  ?> value="<?=$SeoDetails['og_type'];?>" <? } else{ ?> value="" <? } ?>>
                   <div id="error_og_type" class="error_code"><span></span></div>
                 </td>
                        </tr>
                        <tr>
                        <td>Canonical</td>
                         <td>
                   <input type="text" class="form-control" id="canonical" name="canonical" <? if(isset($canonical) && !empty($canonical)) {  ?> value="<?=$SeoDetails['canonical'];?>" <? } else{ ?> value="" <? } ?>>
                   <div id="error_canonical" class="error_code"><span></span></div>
                 </td>
                        </tr>
                        <tr>
                        <td>LOC</td>
                         <td>
                   <input type="text" class="form-control" id="loc" name="loc" <? if(isset($loc) && !empty($loc)) {  ?> value="<?=$SeoDetails['loc'];?>" <? } else{ ?> value="" <? } ?>>
                   <div id="error_loc" class="error_code"><span></span></div>
                 </td>
                        </tr>

                         <tr>
                        <td>Last Modified</td>
                         <td>
                   <input type="text" class="form-control" id="lastmod" name="lastmod" autocomplete="off" placeholder="dd-mm-yyyy" maxlength="10"  onkeydown="validate_number(event);" onkeyup="validate_number(event);" <? if(isset($lastmod) && !empty($lastmod) && $lastmod!='0000-00-00') {  ?> value="<?=date("d-m-Y", strtotime($SeoDetails['lastmod']))?>" <? } else{ ?> value="<?=date("d-m-Y");?>" <?php } ?> >
                   <div id="error_lastmod" class="error_code"><span></span></div>
                 </td>
                        </tr>

                         <tr>
                        <td>Change Frequently</td>
                         <td>
                          <select class="form-control" name="changefreq" id="changefreq">
                              <option value="">---- Select Page ----</option>
                              <option <? if(isset($changefreq) && !empty($changefreq)) { if(strtolower($changefreq)=='always'){ echo 'selected';}} ?> value="always">Always</option>
                              <option <? if(isset($changefreq) && !empty($changefreq)) { if(strtolower($changefreq)=='hourly'){ echo 'selected';}} ?> value="hourly">Hourly</option>
                              <option <? if(isset($changefreq) && !empty($changefreq)) { if(strtolower($changefreq)=='daily'){ echo 'selected';}} ?> value="daily">Daily</option>
                              <option <? if(isset($changefreq) && !empty($changefreq)) { if(strtolower($changefreq)=='weekly'){ echo 'selected';}} ?> value="weekly">Weekly</option>
                              <option <? if(isset($changefreq) && !empty($changefreq)) { if(strtolower($changefreq)=='monthly'){ echo 'selected';}} ?> value="monthly">Monthly</option>
                              <option <? if(isset($changefreq) && !empty($changefreq)) { if(strtolower($changefreq)=='yearly'){ echo 'selected';}} ?> value="yearly">Yearly</option>
                              <option <? if(isset($changefreq) && !empty($changefreq)) { if(strtolower($changefreq)=='never'){ echo 'selected';}} ?> value="never">Never</option>

                            </select>
                   <div id="error_changefreq" class="error_code"><span></span></div>
                 </td>
                        </tr>
                        <tr>
                        <td>Priority</td>
                         <td>
                   <input type="text" class="form-control" id="priority" name="priority" <? if(isset($priority) && !empty($priority)) {  ?> value="<?=$SeoDetails['priority'];?>" <? } else{ ?> value="" <? } ?>>
                   <div id="error_priority" class="error_code"><span></span></div>
                 </td>
                        </tr>

                         <tr>
                        <td>Anchor Relation</td>
                         <td>
                   <input type="text" class="form-control" id="anchor_rel" name="anchor_rel" <? if(isset($anchor_rel) && !empty($anchor_rel)) {  ?> value="<?=$SeoDetails['anchor_rel'];?>" <? } else{ ?> value="" <? } ?>>
                   <div id="error_anchor_rel" class="error_code"><span></span></div>
                 </td>
                        </tr>

                        <tr>
                        <td>Schema</td>
                         <td>
                          <textarea rows="4" cols="50" class="form-control" id="schema_data" name="schema_data"><? if(isset($schema_data) && !empty($schema_data)) {  echo stripslashes($SeoDetails['schema_data']);  } else{ echo ""; } ?></textarea>
                   <div id="error_schema_data" class="error_code"><span></span></div>
                 </td>
                        </tr>
                        
                        </tbody>
                      </table>
                        <div class="row box-footer" style="margin: 0;">

          <div class="pull-right seo_update_btn">

  
           
          <button type="submit" class="btn btn-primary" id="ag_submit" name="ag_submit">Update</button>
       

            <button type="reset" class="btn btn-danger" id="reset">Reset </button> 

      

          </div>

      </div>
                      
                    </div>
                    


           </div>
         </form>
         <div class="summary">
          <h1 class="panel-heading">Summary</h1>
           <div class="summary_inner col-md-12">
            
             <ul class="list_summary col-md-6">
               <li><span>Title : </span>It contain primary keyword and brand name, length under 70 chars.It is the very first HTML element that specifies your web page for search engines and to visitors. </li>
               <li><span>Meta Title : </span>It contain a sub title of your web page.</li>
               <li><span>Meta Description : </span>A Meta Description is an HTML element that summarizes your web page. Search engines typically show the Meta description in search results below your Title tag.</li>
               <li><span>Meta Keywords : </span>The meta keywords tag is where you put all of the keywords you use in your site. Eg:- content=”SEO, Hacker, Google, Search, etc”.It must include location / country, Place your main keywords in headlines, subheadings and anchor texts.</li>
               <li><span>Meta Robots : </span>The Robots Meta tag is an HTML tag that provides instructions to web crawlers on whether to index or noindex a web page.</li>
               <li><span>Meta Copyright : </span>Meta Copyright contain name of the owner. Eg:- content="name of owner" </li>
               <li><span>Og Site Name : </span>Open Graph Meta tags are designed to promote integration between Facebook, LinkedIn, Google and the website URLs that you shared on these platforms. Eg:- content=”SITE NAME” </li>
               <li><span>Og Title : </span>Eg:- content=”TITLE OF YOUR POST OR PAGE”</li>
               <li><span>Og Image : </span>Eg:- content=”LINK TO THE IMAGE FILE”</li>
             </ul>
             <ul class="list_summary col-md-6">
               <li><span>Og Description : </span>Eg:- content=”DESCRIPTION OF PAGE CONTENT”</li>
               <li><span>Og URL : </span>Eg:- content=”PERMALINK”</li>
               <li><span>Og Type : </span>Eg:- content=”article” </li>
               <li><span>Canonical : </span>By implementing the Canonical tag in the code, we are telling search engines that this URL is the main page and avoid indexing other duplicate page URLs.Eg: http://example.com/</li>
               <li><span>LOC : </span>URL of the page. This URL must begin with the protocol (such as http) and end with a trailing slash, if your web server requires it. This value must be less than 2,048 characters.</li>
               <li><span>Last Modified : </span>The date of last modification of the file.</li>
               <li><span>Change Frequently : </span>How frequently the page is likely to change.</li>
               <li><span>Priority : </span>The priority of this URL relative to other URLs on your site. Valid values range from 0.0 to 1.0.The default priority of a page is 0.5</li>
             </ul>
             
           </div>
         </div>
         </div>
       </div>
     </div></section>
  </div>
  <!-- /.content-wrapper -->


 <!-- Begin:: Footer -->
<?php $this->load->view('include/footer'); ?>
<!--/. End:: Footer -->

  
  
</div>
<!-- ./wrapper -->
<?php $this->load->view('include/foot'); ?>
<script>
  $("form#tarvel_default_seoform").submit(function(e) {

    e.preventDefault(); 


    var formData = new FormData(this);
    var errorflag=0;
    // var nospecial=/^[^*|\":<>[\]{}`\\()';@&$]+$/;
    var nospecial = /['"]/gi;
     // var meta_description_nospecial=/^["'&]+$/;
     var meta_description_nospecial=/['"]/gi;
    var page_name=$('#page_name').val();
    var service_name=$('#service_name').val();
  var titlew=$('#titlew').val();
  var meta_title=$('#meta_title').val();
  var meta_description=$('#meta_description').val();
  var meta_keywords=$('#meta_keywords').val();
  var meta_robots=$('#meta_robots').val();
  var meta_copyright=$('#meta_copyright').val();
  var og_site_name=$('#og_site_name').val();
  var og_title=$('#og_title').val();
  var og_image=$('#og_image').val();
  var og_description=$('#og_description').val();
  var og_url=$('#og_url').val();
  var og_type=$('#og_type').val();
  var canonical=$('#canonical').val();
  var loc=$('#loc').val();
  var lastmod=$('#lastmod').val();
  var changefreq=$('#changefreq').val();
  var priority=$('#priority').val();
  var anchor_rel=$('#anchor_rel').val();
  var schema_data=$('#schema_data').val();

    if(page_name==''){
        
      $("#page_name").addClass(' inpt_error ');
      $('#error_page_name span').html('Please select category');
      errorflag=1;
    }else{
      $("#page_name").removeClass(' inpt_error ');
    $('#error_page_name span').html('');
    }

    
    if(service_name=="")
      {
        $("#service_name").addClass('inpt_error');
        $('#error_service_name span').html('(Service Name is required)');       
        errorflag=1;
      }else if(service_name.length<2 || service_name.length>80)
      { 
        $("#service_name").addClass(' inpt_error ');             
        $('#error_service_name span').html('(Service Name should be of 2-80 characters)');          
        errorflag=1;
      }else if((nospecial.test(service_name))){          
        $("#service_name").addClass('inpt_error');          
        $('#error_service_name span').html('(Special character is not allowed in Service Name)');   
        errorflag=1;
        }else {
        $("#service_name").removeClass('inpt_error');
        $('#error_service_name span').html('');

      }

      if(titlew=="")
      {
        $("#titlew").addClass('inpt_error');
        $('#error_titlew span').html('(Title is required)');       
        errorflag=1;
      }else if(titlew.length<2 || titlew.length>100)
      { 
        $("#titlew").addClass(' inpt_error ');             
        $('#error_titlew span').html('(title should be between 2-100 characters)');          
        errorflag=1;
      }/*else if((nospecial.test(titlew))){          
        $("#titlew").addClass('inpt_error');          
        $('#error_titlew span').html('(Special character is not allowed in title)');   
        errorflag=1;
        }*/else {
        $("#titlew").removeClass('inpt_error');
        $('#error_titlew span').html('');

      }

      if(meta_title=="")
      {
        $("#meta_title").addClass('inpt_error');
        $('#error_meta_title span').html('(Meta Title is required)');       
        errorflag=1;
      }else if(meta_title.length<2 || meta_title.length>100)
      { 
        $("#meta_title").addClass(' inpt_error ');             
        $('#error_meta_title span').html('(Meta Title should be of 2-100 characters)');          
        errorflag=1;
      }/*else if((nospecial.test(meta_title))){          
        $("#meta_title").addClass('inpt_error');          
        $('#error_meta_title span').html('(Special character is not allowed in Meta Title)');   
        errorflag=1;
        }*/else {
        $("#meta_title").removeClass('inpt_error');
        $('#error_meta_title span').html('');

      }

      if(meta_description=="")
      {
        $("#meta_description").addClass('inpt_error');
        $('#error_meta_description span').html('(Meta Description is required)');       
        errorflag=1;
      }else if(meta_description.length<2 || meta_description.length>320)
      { 
        $("#meta_description").addClass(' inpt_error ');             
        $('#error_meta_description span').html('(Meta Description should be of 2-320 characters)');          
        errorflag=1;
      }else {
        $("#meta_description").removeClass('inpt_error');
        $('#error_meta_description span').html('');

      }

      if(meta_keywords=="")
      {
        $("#meta_keywords").addClass('inpt_error');
        $('#error_meta_keywords span').html('(Meta keywords is required)');       
        errorflag=1;
      }else if(meta_keywords.length<2)
      { 
        $("#meta_keywords").addClass(' inpt_error ');             
        $('#error_meta_keywords span').html('(Meta keywords must be more than 2 characters)');          
        errorflag=1;
      }/*else if((nospecial.test(meta_keywords))){          
        $("#meta_keywords").addClass('inpt_error');          
        $('#error_meta_keywords span').html('(Some Special character is not allowed in Meta keywords)');   
        errorflag=1;
        }*/else {
        $("#meta_keywords").removeClass('inpt_error');
        $('#error_meta_keywords span').html('');

      }

      if(meta_robots!="")
      {
        
      if(meta_robots.length<2 || meta_robots.length>80)
      { 
        $("#meta_robots").addClass(' inpt_error ');             
        $('#error_meta_robots span').html('(Meta Robots should be of 2-80 characters)');          
        errorflag=1;
      }else if((nospecial.test(meta_robots))){          
        $("#meta_robots").addClass('inpt_error');          
        $('#error_meta_robots span').html('(Special character is not allowed in Meta Robots)');   
        errorflag=1;
        }else {
        $("#meta_robots").removeClass('inpt_error');
        $('#error_meta_robots span').html('');
    }
    }

      if(meta_copyright!="")
      {
        if(meta_copyright.length<2 || meta_copyright.length>80)
        { 
          $("#meta_copyright").addClass(' inpt_error ');             
          $('#error_meta_copyright span').html('(Meta Copyright should be of 2-80 characters)');          
          errorflag=1;
        }else if((nospecial.test(meta_copyright))){          
          $("#meta_copyright").addClass('inpt_error');          
          $('#error_meta_copyright span').html('(Special character is not allowed in Meta Copyright)');   
          errorflag=1;
          }else {
          $("#meta_copyright").removeClass('inpt_error');
          $('#error_meta_copyright span').html('');
        }
      }

      if(og_site_name!="")
      {
        if(og_site_name.length<2 || og_site_name.length>80)
        { 
          $("#og_site_name").addClass(' inpt_error ');             
          $('#error_og_site_name span').html('(Og Site Name should be of 2-80 characters)');          
          errorflag=1;
        }else if((nospecial.test(og_site_name))){          
          $("#og_site_name").addClass('inpt_error');          
          $('#error_og_site_name span').html('(Special character is not allowed in Og Site Name)');   
          errorflag=1;
          }else {
          $("#og_site_name").removeClass('inpt_error');
          $('#error_og_site_name span').html('');
      }
    }

      if(og_title!="")
      {
        if(og_title.length<2 || og_title.length>100)
        { 
          $("#og_title").addClass(' inpt_error ');             
          $('#error_og_title span').html('(Og Title should be of 2-100 characters)');          
          errorflag=1;
        }/*else if((nospecial.test(og_title))){          
          $("#og_title").addClass('inpt_error');          
          $('#error_og_title span').html('(Special character is not allowed in Og Title)');   
          errorflag=1;
          }*/else {
          $("#og_title").removeClass('inpt_error');
          $('#error_og_title span').html('');
      }
    }

      // if(og_image!="")
      // {
      //   $("#og_image").addClass('inpt_error');
      //   $('#error_og_image span').html('(Og Image is required)');       
      //   errorflag=1;
      // }else {
      //   $("#og_image").removeClass('inpt_error');
      //   $('#error_og_image span').html('');

      // }

      if(og_description!="")
      {
        if(og_description.length<2 || og_description.length>320)
        { 
          $("#og_description").addClass(' inpt_error ');             
          $('#error_og_description span').html('(Og Description should be of 2-320 characters)');          
          errorflag=1;
        }else if((nospecial.test(og_description))){          
          $("#og_description").addClass('inpt_error');          
          $('#error_og_description span').html('(Special character is not allowed in Og Description)');   
          errorflag=1;
          }else {
          $("#og_description").removeClass('inpt_error');
          $('#error_og_description span').html('');
      }
    }

      // if(og_url=="")
      // {
      //   $("#og_url").addClass('inpt_error');
      //   $('#error_og_url span').html('(Og URL is required)');       
      //   errorflag=1;
      // }else {
      //   $("#og_url").removeClass('inpt_error');
      //   $('#error_og_url span').html('');

      // }

      if(og_type!="")
      {
        if(og_type.length<2 || og_type.length>80)
        { 
          $("#og_type").addClass(' inpt_error ');             
          $('#error_og_type span').html('(Og Type should be of 2-80 characters)');          
          errorflag=1;
        }else if((nospecial.test(og_type))){          
          $("#og_type").addClass('inpt_error');          
          $('#error_og_type span').html('(Special character is not allowed in Og Type)');   
          errorflag=1;
          }else {
          $("#og_type").removeClass('inpt_error');
          $('#error_og_type span').html('');
      }
    }

      // if(canonical=="")
      // {
      //   $("#canonical").addClass('inpt_error');
      //   $('#error_canonical span').html('(Canonical is required)');       
      //   errorflag=1;
      // }else {
      //   $("#canonical").removeClass('inpt_error');
      //   $('#error_canonical span').html('');

      // }

      // if(loc=="")
      // {
      //   $("#loc").addClass('inpt_error');
      //   $('#error_loc span').html('(LOC is required)');       
      //   errorflag=1;
      // }else {
      //   $("#loc").removeClass('inpt_error');
      //   $('#error_loc span').html('');

      // }

      var arr1 = lastmod.split('-');
    var nwDateGet=arr1[2]+'-'+arr1[1]+'-'+arr1[0];
    var nwDateGet = new Date(nwDateGet);
    var today = new Date();
    
      
    if(lastmod!="")
    { 
       if (nwDateGet =="Invalid Date" ) { 
        $("#lastmod").addClass('inpt_error');         
              $('#error_lastmod span').html('(Enter a valid date)');
              errorflag=1;
      }else if ( nwDateGet > today ) { 
        $("#lastmod").addClass('inpt_error');
              $('#error_lastmod span').html('(You cannot enter a date in the future!)');
              errorflag=1;
      }else {
        $("#lastmod").removeClass('inpt_error');
        $('#error_lastmod span').html('');
      }
    } 

  

      // if(changefreq=="")
      // {
      //   $("#changefreq").addClass('inpt_error');
      //   $('#error_changefreq span').html('(Change Frequently is required)');       
      //   errorflag=1;
      // }else {
      //   $("#changefreq").removeClass('inpt_error');
      //   $('#error_changefreq span').html('');

      // }

      if(priority!="")
      {
          if(priority.length<1 || priority.length>5)
        { 
          $("#priority").addClass(' inpt_error ');             
          $('#error_priority span').html('(Priority should be of 2-5 characters)');          
          errorflag=1;
        }else if((nospecial.test(priority))){          
          $("#priority").addClass('inpt_error');          
          $('#error_priority span').html('(Special character is not allowed in Priority)');   
          errorflag=1;
          }else {
          $("#priority").removeClass('inpt_error');
          $('#error_priority span').html('');
      }
    }

       if(anchor_rel!="")
      {
      if(anchor_rel.length<2 || anchor_rel.length>70)
      { 
        $("#anchor_rel").addClass(' inpt_error ');             
        $('#error_anchor_rel span').html('(Anchor Relation should be of 2-70 characters)');          
        errorflag=1;
      }else if((nospecial.test(anchor_rel))){          
        $("#anchor_rel").addClass('inpt_error');          
        $('#error_anchor_rel span').html('(Special character is not allowed in Anchor Relation)');   
        errorflag=1;
        }else {
        $("#anchor_rel").removeClass('inpt_error');
        $('#error_anchor_rel span').html('');

      }
    }

    if(schema_data=="")
      {
        $("#schema_data").addClass('inpt_error');
        $('#error_schema_data span').html('(schema Data is required)');       
        errorflag=1;
      }else if(schema_data.length<2)
      { 
        $("#schema_data").addClass(' inpt_error ');             
        $('#error_schema_data span').html('(schema Data must be more than 2 characters)');          
        errorflag=1;
      }else {
        $("#schema_data").removeClass('inpt_error');
        $('#error_schema_data span').html('');
      }

    // alert(Base_URL+"tarvel/tdefault/seo_update");
    if(errorflag==0)
  {
    $('.loader_upload_overlay').show();
     $.ajax({        

          url:Base_URL+"home/seo_update",

          type: 'POST',

          data: formData,

          //timeout: 60000, //Set your timeout value in milliseconds or 0 for unlimited

          cache: false,

          contentType: false,

          processData: false,

          success: function (data) {

            $('.loader_upload_overlay').hide();
            //console.log(data);
            data=data.trim();
            var obj = JSON.parse(data);
            

            if(obj.status==200)
            {
              $('.alert-success.seo_div span.success_txt').addClass('noerror');
              $('.alert-success.seo_div span.success_txt').removeClass('error');
              $('.alert-success.seo_div span.success_txt').html(obj.message);
              
              $('.alert-success.seo_div').show();
              $("html, body").animate({ scrollTop: 0 }, "slow");

            }else if(data==400){
              $('.alert-success.seo_div span.success_txt').addClass('error');
              $('.alert-success.seo_div span.success_txt').removeClass('noerror');
              $('.alert-success.seo_div span.success_txt').html(obj.message);

              $('.alert-success.seo_div').show();
              $("html, body").animate({ scrollTop: 0 }, "slow");
              // $('.alert-success.success_div').hide();
              // $('.alert-success.success_div span').html('');
              // $('.alert-success.agent_div').hide();
              

            }

          }

        }); 

      }

});

function resetSEOForm()
{
    
    var titlew=$('#titlew').val('');
  var meta_title=$('#meta_title').val('');
  var meta_description=$('#meta_description').val('');
  var meta_keywords=$('#meta_keywords').val('');
  var meta_robots=$('#meta_robots').val('');
  var meta_copyright=$('#meta_copyright').val('');
  var og_site_name=$('#og_site_name').val('');
  var og_title=$('#og_title').val('');
  var og_image=$('#og_image').val('');
  var og_description=$('#og_description').val('');
  var og_url=$('#og_url').val('');
  var og_type=$('#og_type').val('');
  var canonical=$('#canonical').val('');
  var loc=$('#loc').val('');
  var lastmod=$('#lastmod').val('');
  var changefreq=$('#changefreq').val('');
  var priority=$('#priority').val('');
  var schema_data=$("#schema_data").val('');
}

$( document ).ready(function() {
  $( "#reset" ).on('click',function() {
    // alert('hii');
      resetSEOForm();

    });

    $("#lastmod").keyup(function(){
                if ($(this).val().length == 2){
                    $(this).val($(this).val() + "-");
                }else if ($(this).val().length == 5){
                    $(this).val($(this).val() + "-");
                }else if($(this).val().length > 10){
                  var pprt=$(this).val().substr(0, 10);
                  $(this).val(pprt);
                }
            });

    $('#page_name').on('change', function() {
 
   window.location.href=Base_URL+'home/homedefault/'+this.value+'/'+$('#service_name').val();
     
});
});
</script>
</body>
</html>
