<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Recharge extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		date_default_timezone_set("Asia/Calcutta");
	}

	public function index()
	{
		$this->load->view('pages/recharge/rdefault');
	}
	public function rdefault($page_name = '', $service_name = '')
	{
		$SeoArray = array();
		if (!empty($page_name) && $service_name != '') {
			$service_name = trim($service_name);
			$page_name = trim($page_name);
			$get_page_name = $page_name;

			/* $default_service_array=array("voucher_default","travel_default","egov_default","finance_default","other_default","franchisee_default","mobile_prepaid_default","mobile_postpaid_default","dth_default","datacard_prepaid_default","datacard_postpaid_default","landline_default","broadband_default","insurance_default","electricity_default","water_default","gas_default","fastag_default","credit_card_default","hospital_default","lpg_gas_default","loan_default","housing_society_default","subscription_default","cable_default","entertainment_default","travel_sub_default","municipal_taxes_default","municipal_services_default","education_default"); 
					*/

			$_temp_arr = explode('-', $page_name);
			if (isset($_temp_arr[0]) && !empty($_temp_arr[0])) {
				$_service_type = $_temp_arr[0];
			} else {
				$_service_type = $_temp_arr[0];
			}
			if (isset($_temp_arr[1]) && !empty($_temp_arr[1])) {
				$_op_code = $_temp_arr[1];
			} else {
				$_op_code = $_temp_arr[1];
			}
			if (isset($_service_type) && $_service_type != "electricity_circle") {
				$get_page_name = $_service_type . "_" . $_op_code;
			}
			$tableData = $this->db->where('LCASE(page_name)',strtolower($get_page_name))->where('LCASE(service_name)',strtolower($service_name))->get('tbl_seo_data')->row_array();
			$elArr = ['page_name','service_name','title','h1_tag','meta_title','meta_description','meta_keywords','meta_robots','meta_copyright','og_site_name','og_title','og_image','og_description','og_url','og_type','canonical','loc','lastmod','changefreq','priority','anchor_rel','rowInfo','mychk_field','extra_fields','schema_data'];
			if( $tableData ) foreach ($elArr as $key ) $SeoArray[$key] = ($key != 'rowInfo') ? stripslashes($tableData[$key]) : $tableData[$key];
		}
		$data['SeoDetails'] = $SeoArray;
		if (isset($page_name) && !empty($page_name)) {
			if (strtolower($page_name) == 'mobile_prepaid-default') {
				$data['mobile_prepaid_default'] = $page_name;
			} else if (strtolower($page_name) == 'mobile_postpaid-default') {
				$data['mobile_postpaid_default'] = $page_name;
			} else if (strtolower($page_name) == 'dth-default') {
				$data['dth_default'] = $page_name;
			} else if (strtolower($page_name) == 'datacard_prepaid-default') {
				$data['datacard_prepaid_default'] = $page_name;
			} else if (strtolower($page_name) == 'datacard_postpaid-default') {
				$data['datacard_postpaid_default'] = $page_name;
			} else if (strtolower($page_name) == 'landline-default') {
				$data['landline_default'] = $page_name;
			} else if (strtolower($page_name) == 'broadband-default') {
				$data['broadband_default'] = $page_name;
			} else if (strtolower($page_name) == 'insurance-default') {
				$data['insurance_default'] = $page_name;
			} else if (strtolower($page_name) == 'electricity-default') {
				$data['electricity_default'] = $page_name;
			} else if (strtolower($page_name) == 'water-default') {
				$data['water_default'] = $page_name;
			} else if (strtolower($page_name) == 'gas-default') {
				$data['gas_default'] = $page_name;
			} else if (strtolower($page_name) == 'fastag-default') {
				$data['fastag_default'] = $page_name;
			} else if (strtolower($page_name) == 'credit_card-default') {
				$data['credit_card_default'] = $page_name;
			} else if (strtolower($page_name) == 'hospital-default') {
				$data['hospital_default'] = $page_name;
			} else if (strtolower($page_name) == 'lpg_gas-default') {
				$data['lpg_gas_default'] = $page_name;
			} else if (strtolower($page_name) == 'loan-default') {
				$data['loan_default'] = $page_name;
			} else if (strtolower($page_name) == 'housing_society-default') {
				$data['housing_society_default'] = $page_name;
			} else if (strtolower($page_name) == 'subscription-default') {
				$data['subscription_default'] = $page_name;
			} else if (strtolower($page_name) == 'cable-default') {
				$data['cable_default'] = $page_name;
			} else if (strtolower($page_name) == 'entertainment-default') {
				$data['entertainment_default'] = $page_name;
			} else if (strtolower($page_name) == 'travel_sub-default') {
				$data['travel_sub_default'] = $page_name;
			} else if (strtolower($page_name) == 'municipal_taxes-default') {
				$data['municipal_taxes_default'] = $page_name;
			} else if (strtolower($page_name) == 'municipal_services-default') {
				$data['municipal_services_default'] = $page_name;
			} else if (strtolower($page_name) == 'education-default') {
				$data['education_default'] = $page_name;
			} else {
				$is_electricity_circle = false;
				$this->load->model('Mysqlcontroller');
				$circle_list_array = $this->Mysqlcontroller->get_bbps_circle_list(array("service_type" => "electricity_board"));
				if (isset($circle_list_array) && !empty($circle_list_array)) {
					foreach ($circle_list_array as $circle_key => $circle_value) {
						if (isset($circle_value['code']) && $circle_value['code'] != '') {
							$electricity_circle_code = "electricity_circle-" . $circle_value['code'];
						} else {
							$electricity_circle_code = '';
						}
						if (strtolower($page_name) == strtolower($electricity_circle_code)) {
							$is_electricity_circle = true;
						}
					}
				}

				if (isset($is_electricity_circle) && $is_electricity_circle == true) {
					$data['electricity_circle'] = $page_name;
					$data['electricity_circle_list'] = $circle_list_array;
				} else {
					$service_type = '';
					$temp_arr = explode('-', $page_name);
					if (isset($temp_arr[0]) && !empty($temp_arr[0])) {
						$service_type = $temp_arr[0];
					}

					$sql = "select * from tbl_recharge_operator_list where LCASE(service_type)='" . $service_type . "' ";
					$update_db = $this->load->database('recharge_bill', true);
					$resultResponse = $update_db->query($sql);
					if ($resultResponse->num_rows() > 0) {
						$row_temp = $resultResponse->result_array();
						$data['recharge_list'] = $row_temp;
					}
				}
			}
		} else {
			$temp_page_name = 'mobile_prepaid_default';
			$data['mobile_prepaid_default'] = $temp_page_name;
		}
		if (isset($page_name) && $page_name != "") {
			$data['searched_page_name'] = $page_name;
		}
		$this->load->view('pages/recharge/rdefault', $data);
	}

	public function cmn_rech_catg($catg = '')
	{
		if (strtolower($catg) == 'mobile_prepaid_default') {
			$data['mobile_prepaid_default'] = $catg;
			$this->load->view('pages/recharge/rdefault', $data);
		} else if (strtolower($catg) == 'mobile_postpaid_default') {
			$data['mobile_postpaid_default'] = $catg;
			$this->load->view('pages/recharge/rdefault', $data);
		} else if (strtolower($catg) == 'dth_default') {
			$data['dth_default'] = $catg;
			$this->load->view('pages/recharge/rdefault', $data);
		} else if (strtolower($catg) == 'datacard_prepaid_default') {
			$data['datacard_prepaid_default'] = $catg;
			$this->load->view('pages/recharge/rdefault', $data);
		} else if (strtolower($catg) == 'datacard_postpaid_default') {
			$data['datacard_postpaid_default'] = $catg;
			$this->load->view('pages/recharge/rdefault', $data);
		} else if (strtolower($catg) == 'landline_default') {
			$data['landline_default'] = $catg;
			$this->load->view('pages/recharge/rdefault', $data);
		} else if (strtolower($catg) == 'broadband_default') {
			$data['broadband_default'] = $catg;
			$this->load->view('pages/recharge/rdefault', $data);
		} else if (strtolower($catg) == 'insurance_default') {
			$data['insurance_default'] = $catg;
			$this->load->view('pages/recharge/rdefault', $data);
		} else if (strtolower($catg) == 'electricity_default') {
			$data['electricity_default'] = $catg;
			$this->load->view('pages/recharge/rdefault', $data);
		} else if (strtolower($catg) == 'water_default') {
			$data['water_default'] = $catg;
			$this->load->view('pages/recharge/rdefault', $data);
		} else if (strtolower($catg) == 'gas_default') {
			$data['gas_default'] = $catg;
			$this->load->view('pages/recharge/rdefault', $data);
		} else if (strtolower($catg) == 'fastag_default') {
			$data['fastag_default'] = $catg;
			$this->load->view('pages/recharge/rdefault', $data);
		} else if (strtolower($catg) == 'credit_card_default') {
			$data['credit_card_default'] = $catg;
			$this->load->view('pages/recharge/rdefault', $data);
		} else if (strtolower($catg) == 'hospital_default') {
			$data['hospital_default'] = $catg;
			$this->load->view('pages/recharge/rdefault', $data);
		} else if (strtolower($catg) == 'lpg_gas_default') {
			$data['lpg_gas_default'] = $catg;
			$this->load->view('pages/recharge/rdefault', $data);
		} else if (strtolower($catg) == 'loan_default') {
			$data['loan_default'] = $catg;
			$this->load->view('pages/recharge/rdefault', $data);
		} else if (strtolower($catg) == 'housing_society_default') {
			$data['housing_society_default'] = $catg;
			$this->load->view('pages/recharge/rdefault', $data);
		} else if (strtolower($catg) == 'subscription_default') {
			$data['subscription_default'] = $catg;
			$this->load->view('pages/recharge/rdefault', $data);
		} else if (strtolower($catg) == 'cable_default') {
			$data['cable_default'] = $catg;
			$this->load->view('pages/recharge/rdefault', $data);
		} else if (strtolower($catg) == 'entertainment_default') {
			$data['entertainment_default'] = $catg;
			$this->load->view('pages/recharge/rdefault', $data);
		} else if (strtolower($catg) == 'travel_sub_default') {
			$data['travel_sub_default'] = $catg;
			$this->load->view('pages/recharge/rdefault', $data);
		} else if (strtolower($catg) == 'municipal_taxes_default') {
			$data['municipal_taxes_default'] = $catg;
			$this->load->view('pages/recharge/rdefault', $data);
		} else if (strtolower($catg) == 'municipal_services_default') {
			$data['municipal_services_default'] = $catg;
			$this->load->view('pages/recharge/rdefault', $data);
		} else if (strtolower($catg) == 'education_default') {
			$data['education_default'] = $catg;
			$this->load->view('pages/recharge/rdefault', $data);
		} else {

			$sql = "select * from tbl_recharge_operator_list where LCASE(service_type)='" . $catg . "' ";
			$update_db = $this->load->database('recharge_bill', true);
			$resultResponse = $update_db->query($sql);
			if ($resultResponse->num_rows() > 0) {
				// output data of each row
				$row_temp = $resultResponse->result_array();
				$data['recharge_list'] = $row_temp;
				$this->load->view('pages/recharge/rdefault', $data);
			} else {
				$this->load->view('pages/recharge/rdefault');
			}
		}
	}

	public function electricity_circle($state_code = '')
	{
		$this->load->model('Mysqlcontroller');
		$circle_list_array = $this->Mysqlcontroller->get_bbps_circle_list(array("service_type" => "electricity_board"));
		if (isset($circle_list_array) && !empty($circle_list_array)) {
			$data['electricity_circle_list'] = $circle_list_array;
			$this->load->view('pages/recharge/rdefault', $data);
		} else {
			$this->load->view('pages/recharge/rdefault');
		}
	}

	public function seo_update()
	{
		$page_name_post = $this->input->post('page_name');
		$service_name_post = $this->input->post('service_name');
		$titlew_post = addslashes($this->input->post('titlew'));
		$h1_tag_post = addslashes($this->input->post('h1_tag'));
		$meta_title_post = addslashes($this->input->post('meta_title'));
		$meta_description_post = addslashes($this->input->post('meta_description'));
		$meta_keywords_post = addslashes($this->input->post('meta_keywords'));
		$meta_robots_post = addslashes($this->input->post('meta_robots'));
		$meta_copyright_post = addslashes($this->input->post('meta_copyright'));
		$og_site_name_post = addslashes($this->input->post('og_site_name'));
		$og_title_post = addslashes($this->input->post('og_title'));
		$og_image_post = addslashes($this->input->post('og_image'));
		$og_description_post = addslashes($this->input->post('og_description'));
		$og_url_post = addslashes($this->input->post('og_url'));
		$og_type_post = addslashes($this->input->post('og_type'));
		$canonical_post = addslashes($this->input->post('canonical'));
		$loc_post = addslashes($this->input->post('loc'));
		$lastmod_post = date('Y-m-d', strtotime(addslashes($this->input->post('lastmod'))));
		$changefreq_post = addslashes($this->input->post('changefreq'));
		$priority_post = addslashes($this->input->post('priority'));
		$anchor_rel_post = addslashes($this->input->post('anchor_rel'));
		$extra_fields_post = addslashes($this->input->post('extra_fields'));
		$schema_data_post = addslashes($this->input->post('schema_data'));
		$mychk = addslashes($this->input->post('mychk'));
		$rowInfoJson = "";
		$mychk_field_post = 'false';

		if ($mychk == 'true') {
			$mychk_field_post = 'true';
			$rowInfo = array();
			$rowInfoJson = "";
		} else {
			$mychk_field_post = 'false';
			$rowInfo = array();
			if (!empty($this->input->post('rowInfo'))) {
				$search = array(
					'/\>[^\S ]+/s',     // strip whitespaces after tags, except space
					'/[^\S ]+\</s',     // strip whitespaces before tags, except space
					'/(\s)+/s',         // shorten multiple whitespace sequences
					'/<!--(.|\s)*?-->/' // Remove HTML comments
				);
				$replace = array(
					'>',
					'<',
					'\\1',
					''
				);
				$rowInfo = $this->input->post('rowInfo');
				$arruuu = array();
				foreach ($rowInfo as $ddd => $VVVV) {
					$buffer = $rowInfo[$ddd]['rech_desc'];
					$rowInfo[$ddd]['rech_desc'] = addslashes(preg_replace($search, $replace, $buffer));
				}
				$rowInfoJson = json_encode($rowInfo);
			}
		}

		$get_page_name = $page_name_post;

		$_temp_arr = explode('-', $page_name_post);
		if (isset($_temp_arr[0]) && !empty($_temp_arr[0])) {
			$_service_type = $_temp_arr[0];
		} else {
			$_service_type = $_temp_arr[0];
		}
		if (isset($_temp_arr[1]) && !empty($_temp_arr[1])) {
			$_op_code = $_temp_arr[1];
		} else {
			$_op_code = $_temp_arr[1];
		}
		if (isset($_service_type) && $_service_type != "electricity_circle") {
			$get_page_name = $_service_type . "_" . $_op_code;
		}

		$recordCheck = $this->db->where('LCASE(page_name)', strtolower($get_page_name))->where('LCASE(service_name)', strtolower($service_name_post))->get('tbl_seo_data')->row();
		$recordData = [
			'title' => $titlew_post,
			'h1_tag' => $h1_tag_post,
			'meta_title' => $meta_title_post,
			'meta_description' => $meta_description_post,
			'meta_keywords' => $meta_keywords_post,
			'meta_robots' => $meta_robots_post,
			'meta_copyright' => $meta_copyright_post,
			'og_site_name' => $og_site_name_post,
			'og_title' => $og_title_post,
			'og_image' => $og_image_post,
			'og_description' => $og_description_post,
			'og_url' => $og_url_post,
			'og_type' => $og_type_post,
			'canonical' => $canonical_post,
			'loc' => $loc_post,
			'lastmod' => $lastmod_post,
			'changefreq' => $changefreq_post,
			'priority' => $priority_post,
			'anchor_rel' => $anchor_rel_post,
			'rowInfo' => $rowInfoJson,
			'mychk_field' => $mychk_field_post,
			'extra_fields' => $extra_fields_post,
			'schema_data' => $schema_data_post
		];
		if ($recordCheck) {
			if ($this->db->update('tbl_seo_data', $recordData, ['page_name' => $get_page_name, 'service_name' => $service_name_post])) {
				$RES = ['status' => 200, 'message' => '  Existing Page SEO Data update Successfully '];
			} else $RES = ['status' => 400, 'message' => ' Something Went Wrong in New Page SEO Data!'];
		} else {
			$create_date = date("Y-m-d");
			$recordData['create_date'] = $create_date;
			$recordData['page_name'] = $get_page_name;
			$recordData['service_name'] = $service_name_post;
			if ($this->db->insert('tbl_seo_data', $recordData)) {
				$RES = ['status' => 200, 'message' => '  New Page SEO Data set Successfully.'];
			} else $RES = ['status' => 400, 'message' => ' Something Went Wrong in New Page SEO Data!'];
		}

		$RES['result'] = [];
		// $RES['last_query'] = $this->db->last_query();
		echo json_encode($RES);
		exit();
	}

	public function test()
	{
		$json = file_get_contents(base_url() . "dist/js/try.json");
		$dataArray = array();
		$dataArray = json_decode($json, true);
		echo "<pre>";
		print_r($dataArray);
		$search = array(
			'/\>[^\S ]+/s',     // strip whitespaces after tags, except space
			'/[^\S ]+\</s',     // strip whitespaces before tags, except space
			'/(\s)+/s',         // shorten multiple whitespace sequences
			'/<!--(.|\s)*?-->/' // Remove HTML comments
		);

		$replace = array(
			'>',
			'<',
			'\\1',
			''
		);
		$counter = 0;
		foreach ($dataArray as $val) {
			$buffer = $dataArray[$counter]['rech_desc'];
			echo preg_replace($search, $replace, $buffer);
			$counter++;
		}
	}
}
