<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Question extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
        {
                parent::__construct();
				//$this->load->model('home_model');
				date_default_timezone_set("Asia/Calcutta");
				// require_once('PHPMailer/class.phpmailer.php');
				// require_once('PHPMailer/class.smtp.php');
        }

	public function index()
	{
		$this->load->view('pages/question/qdefault');
	}
		public function qdefault($page_name='',$service_name=''){
			// echo "<pre>";
			// print_r($pageArray['page_flight']);

				$SeoArray=array();
		if(!empty($page_name) && $service_name!=''){

			$page_name=trim($page_name);
			$service_name=trim($service_name);
			$sql="select * from tbl_seo_data where LCASE(page_name)='".strtolower($page_name)."' AND LCASE(service_name)='".strtolower($service_name)."'";

			$result=$this->db->query($sql);

           if ($result->num_rows() > 0) { 
				$rowList = $result->row();
				
				$SeoArray=array(
								"page_name"=>stripslashes($rowList->page_name),
								"service_name"=>stripslashes($rowList->service_name),
								"title"=>stripslashes($rowList->title),
								"h1_tag"=>stripslashes($rowList->h1_tag),
								"meta_title"=>stripslashes($rowList->meta_title),
								"meta_description"=>stripslashes($rowList->meta_description),
								"meta_description2"=>stripslashes($rowList->meta_description2),
								"meta_description3"=>stripslashes($rowList->meta_description3),
								"meta_keywords"=>stripslashes($rowList->meta_keywords),
								"meta_robots"=>stripslashes($rowList->meta_robots),
								"meta_copyright"=>stripslashes($rowList->meta_copyright),
								"og_site_name"=>stripslashes($rowList->og_site_name),
								"og_title"=>stripslashes($rowList->og_title),
								"og_image"=>stripslashes($rowList->og_image),
								"og_description"=>stripslashes($rowList->og_description),
								"og_description2"=>stripslashes($rowList->og_description2),
								"og_description3"=>stripslashes($rowList->og_description3),
								"og_url"=>stripslashes($rowList->og_url),
								"og_type"=>stripslashes($rowList->og_type),
								"canonical"=>stripslashes($rowList->canonical),
								"loc"=>stripslashes($rowList->loc),
								"lastmod"=>stripslashes($rowList->lastmod),
								"changefreq"=>stripslashes($rowList->changefreq),
								"priority"=>stripslashes($rowList->priority),
								"anchor_rel"=>stripslashes($rowList->anchor_rel),
								"extra_fields"=>stripslashes($rowList->extra_fields),
                				"schema_data"=>stripslashes($rowList->schema_data)

								);	
			}
		}
		
		$sql2="select * from level";

		$result2=$this->db->query($sql2);
		  if ($result2->num_rows() > 0) { 
				$level = $result2->result_array();
		  }				
       //print_r($level);die;
			$data['SeoDetails']=$SeoArray;
			$data['levels']=$level;
			$this->load->view('pages/question/qdefault',$data);
    }
			public function flight(){
				// $pageArray=array();
				// $page_flight="flight";
				// $page_flight_result="flight_result";
				// $pageArray=array(
				// 				"page_flight"=>$page_flight,
				// 				"page_flight_result"=>$page_flight_result

				// );
				
				// $service_name="travel";
				// $data['pageArray']=$pageArray;
				// $data['service_name']=$service_name;
				$this->load->view('pages/question/qdefault');
			}
			public function bus(){
				// $page_name="bus";
				// $service_name="travel";
				$this->load->view('pages/question/qdefault');
			}

			public function hotel(){
				// $page_name="hotel";
				// $service_name="travel";
				$this->load->view('pages/question/qdefault');
			}

			public function holiday(){
				// $page_name="holiday";
				// $service_name="travel";
				$this->load->view('pages/question/qdefault');
			}
			
			
	public function seo_update(){
         ini_set('display_errors', 1);

		 //print_r($_POST);die;
		 
			$qname=addslashes($_POST('qname'));
			$choice=addslashes($_POST('choice'));
			$edate=addslashes($_POST('edate'));
			$level=addslashes($_POST('level'));
			$correct_ans=addslashes($_POST('correct_ans'));
			

			$sql_set="select * from question where question='".$qname."'";
			$result_set = $this->db->query($sql_set);
			if ($result_set->num_rows() > 0) {
			   
			   echo "here";die;
			   // output data of each row
				$row_temp = $result_set->result_array();
				foreach($row_temp as $row) {
					
                    $q_id=stripslashes($row["q_id"]);
					$question=stripslashes($row["question"]);
					$level=stripslashes($row["level"]);
					$choices=stripslashes($row["choices"]);
					$correct_ans=stripslashes($row["correct_ans"]);
				}
				
              $update_date=date("Y-m-d");
			    //Update Default discount Plan accordingly
				$query_update="UPDATE `question` SET 
													
													`question`='".$question."',
													`level`='".$level."',
													`choices`='".$choices."',
													`correct_ans`='".$correct_ans."',
													`q_id`='".$q_id."',
													`updated_date`='".$update_date."',
													
													
													 where question='".$qname."' ";
				$result_update = $this->db->query($query_update);

				
				if ($result_update === TRUE ) { 
					$status=200;
					$message="Existing Page SEO Data update Successfully ";
				}else{
					$status=400;
					$message=" Something Went Wrong in update of Existing Page SEO Data!";
				}							

				$seodataArray=array();

				$seodataArrayJs=array(

					'status'=>$status,
					'message'=>$message,
					'result'=>$seodataArray

				);

				echo json_encode($seodataArrayJs);

			}else {
				
				//echo"here";die;
				$create_date=date("Y-m-d");
				
				$date = strtotime("+$edate day", strtotime($create_date));
				$end_date =	date("Y-m-d", $date);
					//Insert SEO accordingly
				$query_seo_ins="INSERT INTO tbl_seo_data SET 
													`q_id`='".$q_id."',
													`question`='".$qname."',
													`level`='".$level."',
													`choices`='".$choice."',
													`correct_ans`='".$correct_ans."'  
													`created_date`='".$create_date."'  
													`end_date`='".$end_date."'  
													";


				$result_seo_ins = $this->db->query($query_seo_ins);
				if($result_seo_ins === TRUE){
					$status=200;
					$message=" New Page SEO Data set Successfully ";
				}else{
					$status=400;
					$message=" Something Went Wrong in New Page SEO Data!";
				}

				$seodataArray=array();
				$seodataArrayJs=array(

					'status'=>$status,
					'message'=>$message,
					'result'=>$seodataArray

				);

				echo json_encode($seodataArrayJs);
			}
	}
	

}

