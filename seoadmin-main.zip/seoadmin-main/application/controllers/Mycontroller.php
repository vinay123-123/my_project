<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Mycontroller extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	function __construct() {
        parent::__construct();
        //date_default_timezone_set(DEFAULT_TIME_ZONE);
    }


	public function index()
	{
		$dataArr=array('status'=>400,'message'=>"Error! Something went wrong. Please try again later.",'result'=>''); 
        echo json_encode($dataArr);
		
	}



public function admin_register(){

	$query_register_ins = "INSERT INTO tbl_admin SET 
													
													useremail = '".$_POST['useremail']."',
													password = '".$_POST['password']."',
													type = '".$_POST['type']."',
													uname = '".addslashes(trim($_POST['uname']))."',
													umobile = '".$_POST['umobile']."'
													";					
			        
			        $result_register_ins = $this->db->query($query_register_ins);
					if ($result_register_ins === TRUE) {
						echo 200;
					}else{
						echo 400;
					}

}

		public function admin_login(){

			$useremail='';
		    $password='';
		     	
		     if($this->input->post('lemail')!="")
			  {
			  $useremail=$this->input->post('lemail');
			  }
			  
			  if($this->input->post('lpassword')!="")
			  {
			  $password=$this->input->post('lpassword');
			  }

			  $sql_get = "SELECT * FROM tbl_seo_admin where useremail='".$useremail."' and password='".$password."' LIMIT 1";
			  $result = $this->db->query($sql_get);

						if ($result->num_rows() > 0) {   
							
							$rowlogin = $result->result_array();

							foreach($rowlogin as $row){
							  $id=$row['id'];
							  $useremail=$row['useremail'];
							  $uname=$row['uname'];
							  $umobile=$row['umobile'];
							  $type=$row['type'];
							}

							// Add user data in session
							$this->session->set_userdata('SEO_ADMIN_ID', $id);
							$this->session->set_userdata('SEO_ADMIN_USER_EMAIL', $useremail);
							$this->session->set_userdata('SEO_ADMIN_USER_NAME', $uname);
							$this->session->set_userdata('SEO_ADMIN_USER_MOBILE',$umobile);
							$this->session->set_userdata('SEO_ADMIN_LOGGEDIN', 1);
							$this->session->set_userdata('SEO_USER_TYPE',$type);
							
							echo $status=200;
							}else {
								echo $status=400;
							}exit;
		}

		public function logout(){

			$this->session->unset_userdata('SEO_ADMIN_USER_EMAIL');
			$this->session->unset_userdata('SEO_ADMIN_USER_NAME');
			$this->session->unset_userdata('SEO_ADMIN_USER_MOBILE');
			$this->session->unset_userdata('SEO_ADMIN_ID');
			$this->session->unset_userdata('SEO_ADMIN_LOGGEDIN');
			$this->session->set_userdata('SEO_USER_TYPE');
			
			$url="https://travelagent.inditab.com/logout";
					$request_timeout = 60; // 60 seconds timeout
					$ch =curl_init();
					curl_setopt($ch, CURLOPT_URL, $url);
					curl_setopt($ch, CURLOPT_TIMEOUT, $request_timeout);
					curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $request_timeout);
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
					$output = curl_exec($ch);
					$curl_error = curl_errno($ch);
					$getserver= curl_getinfo($ch);
					curl_close($ch);
			

		 	header('Location:' .BASEURL.ADMIN_BASE_URL."login");
		}

}


?>