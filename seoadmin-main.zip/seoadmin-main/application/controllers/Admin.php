<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
	//	echo'hii'.BASEURL.'  '.ADMIN_BASE_URL;die;
		$user_type= strtolower($this->session->userdata('SEO_USER_TYPE'));
		if($this->session->userdata('SEO_ADMIN_LOGGEDIN')==1 && ($user_type=='superadmin' || $user_type=='admin'))
		{
		    	redirect(BASEURL.ADMIN_BASE_URL."dashboard"); 
		}
		else {	
				redirect(BASEURL.ADMIN_BASE_URL."login"); 
	    }
		$this->load->view('pages/login/login');
	}

	public function login()
	{    //echo'hello';die;
		$user_type= strtolower($this->session->userdata('SEO_USER_TYPE'));
		if($this->session->userdata('SEO_ADMIN_LOGGEDIN')==1 && ($user_type=='superadmin' || $user_type=='admin'))
		{    //echo'hello';die;
		    	redirect(BASEURL.ADMIN_BASE_URL."dashboard"); 
		}
		else {	
		$this->load->view('pages/login/login');
	    }
		
	}

	public function register()
	{
		$user_type= strtolower($this->session->userdata('SEO_USER_TYPE'));
		if($this->session->userdata('SEO_ADMIN_LOGGEDIN')==1 && ($user_type=='superadmin' || $user_type=='admin'))
		{
		    	redirect(BASEURL.ADMIN_BASE_URL."dashboard"); 
		}
		else {	
		$this->load->view('pages/login/register');
	    }
		
	}

	public function dashboard()
	{
		$user_type= strtolower($this->session->userdata('SEO_USER_TYPE'));
		if($this->session->userdata('SEO_ADMIN_LOGGEDIN')==1 && ($user_type=='superadmin' || $user_type=='admin'))
		{
		    	$this->load->view('welcome');
		}
		else {	
		redirect(BASEURL.ADMIN_BASE_URL."login"); 
	    }
		
	}
	
	
}
