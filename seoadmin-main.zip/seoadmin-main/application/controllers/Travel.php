<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Travel extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
        {
                parent::__construct();
				//$this->load->model('home_model');
				date_default_timezone_set("Asia/Calcutta");
				// require_once('PHPMailer/class.phpmailer.php');
				// require_once('PHPMailer/class.smtp.php');
        }

	public function index()
	{
		$this->load->view('pages/travel/tdefault');
	}
		public function tdefault($page_name='',$service_name=''){
			// echo "<pre>";
			// print_r($pageArray['page_flight']);

				$SeoArray=array();
		if(!empty($page_name) && $service_name!=''){

			$page_name=trim($page_name);
			$service_name=trim($service_name);
			$sql="select * from tbl_seo_data where LCASE(page_name)='".strtolower($page_name)."' AND LCASE(service_name)='".strtolower($service_name)."'";

			$result=$this->db->query($sql);

           if ($result->num_rows() > 0) { 
				$rowList = $result->row();
				
				$SeoArray=array(
								"page_name"=>stripslashes($rowList->page_name),
								"service_name"=>stripslashes($rowList->service_name),
								"title"=>stripslashes($rowList->title),
								"h1_tag"=>stripslashes($rowList->h1_tag),
								"meta_title"=>stripslashes($rowList->meta_title),
								"meta_description"=>stripslashes($rowList->meta_description),
								"meta_description2"=>stripslashes($rowList->meta_description2),
								"meta_description3"=>stripslashes($rowList->meta_description3),
								"meta_keywords"=>stripslashes($rowList->meta_keywords),
								"meta_robots"=>stripslashes($rowList->meta_robots),
								"meta_copyright"=>stripslashes($rowList->meta_copyright),
								"og_site_name"=>stripslashes($rowList->og_site_name),
								"og_title"=>stripslashes($rowList->og_title),
								"og_image"=>stripslashes($rowList->og_image),
								"og_description"=>stripslashes($rowList->og_description),
								"og_description2"=>stripslashes($rowList->og_description2),
								"og_description3"=>stripslashes($rowList->og_description3),
								"og_url"=>stripslashes($rowList->og_url),
								"og_type"=>stripslashes($rowList->og_type),
								"canonical"=>stripslashes($rowList->canonical),
								"loc"=>stripslashes($rowList->loc),
								"lastmod"=>stripslashes($rowList->lastmod),
								"changefreq"=>stripslashes($rowList->changefreq),
								"priority"=>stripslashes($rowList->priority),
								"anchor_rel"=>stripslashes($rowList->anchor_rel),
								"extra_fields"=>stripslashes($rowList->extra_fields),
                				"schema_data"=>stripslashes($rowList->schema_data)

								);
				

			}
		}

			$data['SeoDetails']=$SeoArray;
			$this->load->view('pages/travel/tdefault',$data);
    }
			public function flight(){
				// $pageArray=array();
				// $page_flight="flight";
				// $page_flight_result="flight_result";
				// $pageArray=array(
				// 				"page_flight"=>$page_flight,
				// 				"page_flight_result"=>$page_flight_result

				// );
				
				// $service_name="travel";
				// $data['pageArray']=$pageArray;
				// $data['service_name']=$service_name;
				$this->load->view('pages/travel/tdefault');
			}
			public function bus(){
				// $page_name="bus";
				// $service_name="travel";
				$this->load->view('pages/travel/tdefault');
			}

			public function hotel(){
				// $page_name="hotel";
				// $service_name="travel";
				$this->load->view('pages/travel/tdefault');
			}

			public function holiday(){
				// $page_name="holiday";
				// $service_name="travel";
				$this->load->view('pages/travel/tdefault');
			}
	public function seo_update(){

			$page_name_post=addslashes($this->input->post('page_name'));
			$service_name_post=addslashes($this->input->post('service_name'));
			$titlew_post=addslashes($this->input->post('titlew'));
			$h1_tag_post=addslashes($this->input->post('h1_tag'));
			$meta_title_post=addslashes($this->input->post('meta_title'));
			$meta_description_post=addslashes($this->input->post('meta_description'));
			$meta_description_post2=addslashes($this->input->post('meta_description2'));
			$meta_description_post3=addslashes($this->input->post('meta_description3'));
			$meta_keywords_post=addslashes($this->input->post('meta_keywords'));
			$meta_robots_post=addslashes($this->input->post('meta_robots'));
			$meta_copyright_post=addslashes($this->input->post('meta_copyright'));
			$og_site_name_post=addslashes($this->input->post('og_site_name'));
			$og_title_post=addslashes($this->input->post('og_title'));
			$og_image_post=addslashes($this->input->post('og_image'));
			$og_description_post=addslashes($this->input->post('og_description'));
			$og_description_post2=addslashes($this->input->post('og_description2'));
			$og_description_post3=addslashes($this->input->post('og_description3'));
			$og_url_post=addslashes($this->input->post('og_url'));
			$og_type_post=addslashes($this->input->post('og_type'));
			$canonical_post=addslashes($this->input->post('canonical'));
			$loc_post=addslashes($this->input->post('loc'));
			$lastmod_post=date('Y-m-d',strtotime($this->input->post('lastmod')));
			$changefreq_post=addslashes($this->input->post('changefreq'));
			$priority_post=addslashes($this->input->post('priority'));
			$anchor_rel_post=addslashes($this->input->post('anchor_rel'));
			$extra_fields_post=addslashes($this->input->post('extra_fields'));
     		$schema_data_post=addslashes($this->input->post('schema_data'));


			$sql_set="select * from tbl_seo_data where page_name='".$page_name_post."' AND service_name='".$service_name_post."' ";
			$result_set = $this->db->query($sql_set);
			if ($result_set->num_rows() > 0) {
			    // output data of each row
				$row_temp = $result_set->result_array();
				foreach($row_temp as $row) {

					$page_name=stripslashes($row["page_name"]);
					$service_name=stripslashes($row["service_name"]);
					$titlew=stripslashes($row["title"]);
					$h1_tag=stripslashes($row["h1_tag"]);
					$meta_title=stripslashes($row["meta_title"]);
					$meta_description=stripslashes($row["meta_description"]);
					$meta_description2=stripslashes($row["meta_description2"]);
					$meta_description3=stripslashes($row["meta_description3"]);
					$meta_keywords=stripslashes($row["meta_keywords"]);
					$meta_robots=stripslashes($row["meta_robots"]);
					$meta_copyright=stripslashes($row["meta_copyright"]);
					$og_site_name=stripslashes($row["og_site_name"]);
					$og_title=stripslashes($row["og_title"]);
					$og_image=stripslashes($row["og_image"]);
					$og_description=stripslashes($row["og_description"]);
					$og_description2=stripslashes($row["og_description2"]);
					$og_description3=stripslashes($row["og_description3"]);
					$og_url=stripslashes($row["og_url"]);
					$og_type=stripslashes($row["og_type"]);
					$canonical=stripslashes($row["canonical"]);
					$loc=stripslashes($row["loc"]);
					$lastmod=stripslashes($row["lastmod"]);
					$changefreq=stripslashes($row["changefreq"]);
					$priority=stripslashes($row["priority"]);
					$anchor_rel=stripslashes($row['anchor_rel']);
					$extra_fields=stripslashes($row['extra_fields']);
          			$schema_data=stripslashes($row['schema_data']);
				}

			    //Update Default discount Plan accordingly
				$query_update="UPDATE `tbl_seo_data` SET 
													
													`title`='".$titlew_post."',
													`h1_tag`='".$h1_tag_post."',
													`meta_title`='".$meta_title_post."',
													`meta_description`='".$meta_description_post."',
													`meta_description2`='".$meta_description_post2."',
													`meta_description3`='".$meta_description_post3."',
													`meta_keywords`='".$meta_keywords_post."',
													`meta_robots`='".$meta_robots_post."',
													`meta_copyright`='".$meta_copyright_post."',
													`og_site_name`='".$og_site_name_post."',
													`og_title`='".$og_title_post."',
													`og_image`='".$og_image_post."',
													`og_description`='".$og_description_post."',
													`og_description2`='".$og_description_post2."',
													`og_description3`='".$og_description_post3."',
													`og_url`='".$og_url_post."',
													`og_type`='".$og_type_post."',
													`canonical`='".$canonical_post."',
													`loc`='".$loc_post."',
													`lastmod`='".$lastmod_post."',
													`changefreq`='".$changefreq_post."',
													`priority`='".$priority_post."',
													`anchor_rel`='".$anchor_rel_post."',
													`extra_fields`='".$extra_fields_post."',
                      								`schema_data`='".$schema_data_post."'

													 where page_name='".$page_name."' AND service_name='".$service_name."' ";
				$result_update = $this->db->query($query_update);

				
				if ($result_update === TRUE ) { 
					$status=200;
					$message="Existing Page SEO Data update Successfully ";
				}else{
					$status=400;
					$message=" Something Went Wrong in update of Existing Page SEO Data!";
				}							

				$seodataArray=array();

				$seodataArrayJs=array(

					'status'=>$status,
					'message'=>$message,
					'result'=>$seodataArray

				);

				echo json_encode($seodataArrayJs);

			}else {
				$create_date=date("Y-m-d");
					//Insert SEO accordingly
				$query_seo_ins="INSERT INTO tbl_seo_data SET 
													`create_date`='".$create_date."',
													`page_name`='".$page_name_post."',
													`service_name`='".$service_name_post."',
													`title`='".$titlew_post."',
													`h1_tag`='".$h1_tag_post."',
													`meta_title`='".$meta_title_post."',
													`meta_description`='".$meta_description_post."',
													`meta_description2`='".$meta_description_post2."',
													`meta_description3`='".$meta_description_post3."',
													`meta_keywords`='".$meta_keywords_post."',
													`meta_robots`='".$meta_robots_post."',
													`meta_copyright`='".$meta_copyright_post."',
													`og_site_name`='".$og_site_name_post."',
													`og_title`='".$og_title_post."',
													`og_image`='".$og_image_post."',
													`og_description`='".$og_description_post."',
													`og_description2`='".$og_description_post2."',
													`og_description3`='".$og_description_post3."',
													`og_url`='".$og_url_post."',
													`og_type`='".$og_type_post."',
													`canonical`='".$canonical_post."',
													`loc`='".$loc_post."',
													`lastmod`='".$lastmod_post."',
													`changefreq`='".$changefreq_post."',
													`priority`='".$priority_post."',
													`anchor_rel`='".$anchor_rel_post."',
													`extra_fields`='".$extra_fields_post."',
                          							`schema_data`='".$schema_data_post."' ";


				$result_seo_ins = $this->db->query($query_seo_ins);
				if($result_seo_ins === TRUE){
					$status=200;
					$message=" New Page SEO Data set Successfully ";
				}else{
					$status=400;
					$message=" Something Went Wrong in New Page SEO Data!";
				}

				$seodataArray=array();
				$seodataArrayJs=array(

					'status'=>$status,
					'message'=>$message,
					'result'=>$seodataArray

				);

				echo json_encode($seodataArrayJs);
			}
	}
	

}

