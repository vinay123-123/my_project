<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Mysqlcontroller extends CI_Model {
	
	public function __construct(){          
			$this->load->database();   
			date_default_timezone_set("Asia/Calcutta");
      }
	  
	public function timeFormat($ts)
    {
    $date = new DateTime("@$ts");
    $finalDate=$date->format('M d-Y H:i');
    return $finalDate;
    }
	
	public function clean($string) {
	   $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.
	   $string = str_replace('/', '-', $string); // Replaces all / with hyphens.
	   return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
	}
	
	public function get_client_ip() {
		$ipaddress = '';
		if (getenv('HTTP_CLIENT_IP'))
			{ $ipaddress = getenv('HTTP_CLIENT_IP'); }
		else if(getenv('HTTP_X_FORWARDED_FOR'))
			{ $ipaddress = getenv('HTTP_X_FORWARDED_FOR'); }
		else if(getenv('HTTP_X_FORWARDED'))
			{ $ipaddress = getenv('HTTP_X_FORWARDED'); }
		else if(getenv('HTTP_FORWARDED_FOR'))
			{ $ipaddress = getenv('HTTP_FORWARDED_FOR'); }
		else if(getenv('HTTP_FORWARDED'))
			{ $ipaddress = getenv('HTTP_FORWARDED'); }
		else if(getenv('REMOTE_ADDR'))
			{ $ipaddress = getenv('REMOTE_ADDR'); }
		else if (isset($_SERVER['HTTP_CLIENT_IP']))
			{ $ipaddress = $_SERVER['HTTP_CLIENT_IP']; }
		else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
			{ $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR']; }
		else if(isset($_SERVER['HTTP_X_FORWARDED']))
			{ $ipaddress = $_SERVER['HTTP_X_FORWARDED']; }
		else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
			{ $ipaddress = $_SERVER['HTTP_FORWARDED_FOR']; }
		else if(isset($_SERVER['HTTP_FORWARDED']))
			{ $ipaddress = $_SERVER['HTTP_FORWARDED']; }
		else if(isset($_SERVER['REMOTE_ADDR']))
			{ $ipaddress = $_SERVER['REMOTE_ADDR']; }
		else
			{ $ipaddress = 'UNKNOWN'; }
		$ipaddress = trim($ipaddress); /* Just to be safe */
		if (filter_var($ipaddress,FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)!== false) 
			{
				return $ipaddress;
			}
		else if($ipaddress=="::1")	
			{
				return $ipaddress;
			}
		else {
				return $ipaddress;
			}    
	}

   public function getAllCoupons()
    {
    	$currentDate=date("Y-m-d");	
        $sql="SELECT * FROM tbl_recharge_coupons_list where status='Active' and `end_date` >= '".$currentDate."'";
        $recharge_bill_db=$this->load->database('recharge_bill',true);
		$result=$recharge_bill_db->query($sql);
		if ($result->num_rows() > 0 ) {   
					
					$row = $result->result_object();
				 return $row;	
				}
				else {
			        
			        return false;  
			        }      
    } 
    public function getAllOperators()
    {

    	$currentDate=date("Y-m-d");	
        $sql="SELECT service_name,operator_code FROM tbl_recharge_operator_list";
        $recharge_bill_db=$this->load->database('recharge_bill',true);
		$result=$recharge_bill_db->query($sql);
		if ($result->num_rows() > 0 ) {   
					
					$row = $result->result_object();
				 return $row;	
				}
				else {
			        
			        return false;  
			        }      
    }

     public function getAllCircleList()
    {
    	$currentDate=date("Y-m-d");	
        $sql="SELECT state,code FROM tbl_recharge_circle_list";
        $recharge_bill_db=$this->load->database('recharge_bill',true);
		$result=$recharge_bill_db->query($sql);
		if ($result->num_rows() > 0 ) {   
					
					$row = $result->result_object();
				 return $row;	
				}
				else {
			        
			        return false;  
			        }  
        	
             
    }

    public function get_bbps_circle_list($params=array())
    {
		if(isset($params['service_type']) && $params['service_type']!='') { $service_type=trim(strtolower($params['service_type'])); } else { $service_type=''; }
		/* Start:: Get All States List */
		$update_db=$this->load->database('recharge_bill',true);   
		$update_db->select('oplist_id as op_list_id,service_type,bbps_biller_json');
		$update_db->from("tbl_recharge_operator_list");
		$update_db->where('service_type',$service_type);
		$query = $update_db->get();
		$operators_list = ($query->num_rows() > 0)?$query->result_array():false;
		
		$circle_list_array=array();
		if(isset($operators_list) && !empty($operators_list))
		{
			$op_loop_counter=0;
			foreach($operators_list as $all_op_arr)
			{				
				if(isset($all_op_arr['op_list_id'])) { $operator_code=$all_op_arr['op_list_id']; } else { $operator_code=''; }		
				
				if(isset($all_op_arr['service_type']) && $all_op_arr['service_type']==$service_type)
				{
					$bbps_biller_arr=array();					
					if(isset($all_op_arr['bbps_biller_json']) && $all_op_arr['bbps_biller_json']!="")
					{
						$bbps_biller_arr=json_decode($all_op_arr['bbps_biller_json'],true);
						if(isset($bbps_biller_arr) && !empty($bbps_biller_arr))
						{
						if(isset($operator_code) && $operator_code!="")
						{
							if(isset($bbps_biller_arr['flowType']) && strtoupper($bbps_biller_arr['flowType'])=='BBPS') 
							{
							if(isset($bbps_biller_arr['status']) && strtoupper($bbps_biller_arr['status'])=='ACTIVE') 
							{													
							$is_payment_method_int=false; $maxLimit=0;$minLimit=0;
							if(isset($bbps_biller_arr['paymentChannelsAllowed']) && !empty($bbps_biller_arr['paymentChannelsAllowed']))
							{
								foreach($bbps_biller_arr['paymentChannelsAllowed'] as $bbps_biller_pay_chanel)
								{
									if(isset($bbps_biller_pay_chanel['paymentMode']) && strtoupper($bbps_biller_pay_chanel['paymentMode'])=="INT")
									{
										$is_payment_method_int=true;
										if(isset($bbps_biller_pay_chanel['maxLimit']))
										{
											$maxLimit=$bbps_biller_pay_chanel['maxLimit'];
										}
										if(isset($bbps_biller_pay_chanel['minLimit']))
										{
											$minLimit=$bbps_biller_pay_chanel['minLimit'];
										}
										break;
									}
								}
							}
							if(isset($is_payment_method_int) && $is_payment_method_int==true)
							{
								if(isset($bbps_biller_arr['state']) && trim($bbps_biller_arr['state'])!="")
								{
									$s_key=strtolower(preg_replace('/ /', '_', $bbps_biller_arr['state']));
									$circle_list_array[$s_key]=array(
																		"state"=>ucwords($bbps_biller_arr['state']),
																		"code"=>trim(strtolower(preg_replace('/ /', '-', $bbps_biller_arr['state']))),
																	  );
								}
							}
							}
							}
						}
						}						
					}					
				}                				
			 $op_loop_counter++;				
			}
		}
		/* END:: Get All States List */
		return $circle_list_array;
	} 	



	
	
}
