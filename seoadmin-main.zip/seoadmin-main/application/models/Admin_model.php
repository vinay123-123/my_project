<?php
  class Admin_model extends CI_Model {       
      public function __construct(){          
			$this->load->database();   
			date_default_timezone_set("Asia/Calcutta");
			require_once('PHPMailer/class.phpmailer.php');
			require_once('PHPMailer/class.smtp.php');     
      }
	  
	 
	 		 public function gst_status_update($chstatus,$oid){
	 		 	
	 		 	if($chstatus=='ok'){
                  $chstatus_new='ready_for_gst_submission';
               }else{
                  $chstatus_new='gst_filled_failed';
               }
              

	 		 	 $sql="update tbl_gst_list SET document_status ='".$chstatus_new."',gst_form_filled_reason1='".$chstatus."' where order_id='".$oid."'";
	 		 	// echo  $sql;die();
	 		 	 $update_db=$this->load->database('finance',true);
	 		 	return $result=$update_db->query($sql);
	 		 }

	 		 public function gst_log_update($chstatus,$order_id){

	 		
             $gst_form_filled_reason1=$chstatus;
             $time_of_upload=date("Y-m-d h:i:s");
             $uname=$this->session->userdata('ADMIN_USER_NAME');
             
             $sql_log="select gst_log_data,html_update_count from tbl_gst_list where order_id='".$order_id."' ";
             $update_db=$this->load->database('finance',true);
             $result_log=$update_db->query($sql_log);
             $row_log=$result_log->row();
             $html_log=$row_log->gst_log_data;
              $html_update_count=$row_log->html_update_count;
              $c=$html_update_count+1;
              if($chstatus=='ok'){
                  $chstatus_new='ready_for_gst_submission';
               }else{
                  $chstatus_new='gst_filled_failed';
               }

           $html_log.= '<div class="cm_logp">
                            <div class="row">
                                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-12 cm_log">
                                    <div class="log_divp">
                                      <div class="log_no">'.$c.'</div>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 cm_log">
                                    <div class="log_divp">
                                      <div class="log_title">Order Id :</div>
                                      <div class="log_data">'.$order_id.'</div>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 cm_log">
                                  <div class="log_divp">
                                    <div class="log_title">Document Status :</div>
                                    <div class="log_data">'.$chstatus_new.'</div>
                                  </div>
                                </div>
                                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 cm_log">
                                  <div class="log_divp">
                                    <div class="log_title">Date Updated:</div>
                                    <div class="log_data">'.$time_of_upload.'</div>
                                  </div>
                                </div>
                                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 cm_log">
                                  <div class="log_divp">
                                    <div class="log_title">Updated By :</div>
                                    <div class="log_data">'.$uname.'</div>
                                  </div>
                                </div>
                            </div>
                            <div class="row log_reason1">
                                  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 cm_log log_title ">Details :</div>
                                  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 cm_log log_title ">Reason :</div>
                                  <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 cm_log">'.$gst_form_filled_reason1.'</div>
                                  
                            </div>';
                          
                            $html_log.='
                       </div>

                        ';
           
                $sql_statment_aspending="update tbl_gst_list SET gst_log_data ='".$html_log."',html_update_count ='".$c."' where order_id='".$order_id."' ";
                $update_db=$this->load->database('finance',true);
           $ResultResponse_aspending=$update_db->query($sql_statment_aspending);
           		return $ResultResponse_aspending;
	 		 }
}